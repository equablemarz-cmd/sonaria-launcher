"""
TickTracker core logic - pure Python/numpy, no Windows calls, so it can be tested
anywhere. ticktracker.py wraps this with screen capture and the badge.

Pieces:
  locate_bar / read_fill  - find the CoS HEALTH bar in a screenshot and read it
                            to sub-pixel precision
  StepDetector            - turns the 60Hz fill readings into heal/damage events
  SimpleClock             - the timing-only regen clock the app uses now

  Kept for the ailment-aware version, NOT used by the basic app at the moment:
  TickModel               - the natural-regen clock, made ailment-aware
  IconBook                - ailment icons the player taught it (F7 bleed, F8 burn);
                            needs OpenCV, which is not bundled
"""
from __future__ import annotations

import math
from collections import deque

import numpy as np

TICK_PERIOD = 15.0          # CoS natural regen; the real gap is learned (15.0s, longer on a busy server)
FULL = 0.996                # bar this full = ticks can't show
MAX_KNOWN_SIZES = 16

# Colours (RGB) for the timer text
WHITE = (255, 255, 255)
BLEED_RED = (255, 64, 64)
BURN_ORANGE = (255, 150, 30)


# --------------------------------------------------------------------------
# Health bar reading
#
# Measured from the real CoS HUD (2558x1369 window):
#   * filled part: a green gradient, (136,217,43) at the top row to (95,187,48) at
#     the bottom, with a 2px dark-teal rim (26,112,83). 24 rows tall there.
#   * a "HEALTH" label is drawn on the left of the bar in brighter/darker greens.
#   * EMPTY part: NOT a solid colour - a see-through dark tint over the game world,
#     so its colour depends on what's behind it. It can't be recognised by colour.
#   * the whole bar is 18.58x as wide as the green is tall (446px vs 24px).
# So: find the green fill by its colour, gradient and height, and get the full
# width from the bar's fixed proportions (refined by the track's grey end-cap, and
# by ever seeing the bar full).
# --------------------------------------------------------------------------
BAR_RATIO = 18.58           # full inner width / green height
TEAL = np.array([26.0, 112.0, 83.0])


def _greens_slow(img):
    """(bright, core) masks - the reference version, written as plain arithmetic.
    bright = the fill gradient / label fill; core also counts the label's dark
    outline. The teal rim is deliberately NOT included: dark water or foliage seen
    through the empty track can look teal."""
    a = img.astype(np.float32)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    # Judged by the balance between red, green and blue rather than exact values, so
    # it still matches if the capture comes out a bit brighter, darker or washed out
    # (HDR, colour profiles). Fill: (136,217,43)..(95,187,48) -> r/g .51-.63, b/g .20-.26
    bright = (g > 120) & (r > 0.36 * g) & (r < 0.84 * g) & (b < 0.48 * g)
    # the label's dark outline, (48,133,18)/(25,112,11): very little red and blue.
    # Anything seen THROUGH the empty track is mixed with its grey tint, so it
    # always has far more blue than this and can't match.
    label = (g > 70) & (r < 0.56 * g) & (b < 0.345 * g)
    return bright, bright | label


def _build_green_tables():
    """Look-up tables giving exactly the same answers as _greens_slow, without first
    turning the whole screenshot into decimals (several times faster on big screens
    and weak laptops). Each table is one of _greens_slow's own tests, worked out
    once with the same arithmetic for every possible (green, other colour) pair."""
    g = np.arange(256, dtype=np.float32)[:, None]      # green value
    o = np.arange(256, dtype=np.float32)[None, :]      # the red (or blue) value
    br_r = (g > 120) & (o > 0.36 * g) & (o < 0.84 * g)
    br_b = o < 0.48 * g
    lab_r = (g > 70) & (o < 0.56 * g)
    lab_b = o < 0.345 * g
    return tuple(t.reshape(-1).copy() for t in (br_r, br_b, lab_r, lab_b))   # index = green*256 + other


_BR_R, _BR_B, _LAB_R, _LAB_B = _build_green_tables()


def _greens(img):
    """(bright, core) masks - see _greens_slow for what they mean. Same answers,
    read from look-up tables."""
    if img.dtype != np.uint8:
        return _greens_slow(img)
    g = img[..., 1].astype(np.uint16) << 8
    ir = g | img[..., 0]
    ib = g | img[..., 2]
    bright = _BR_R[ir] & _BR_B[ib]
    label = _LAB_R[ir] & _LAB_B[ib]
    return bright, bright | label


def _fill_gradient(top, bottom):
    """How much the fill darkens from its top rows to its bottom rows - the health bar's
    signature. top and bottom are small patches of the picture (rows x columns x RGB).

    Normally that is read from the green: (136,217,43) at the top to (95,187,48) at the
    bottom. With Windows HDR switched on, screen captures come back far brighter and the
    fill's green is pinned at 255 from top to bottom (measured: (211,255,0) to
    (153,255,78)), so there is no green gradient left to see. The red still falls just
    the same, so when the green is pinned the red is used instead."""
    t = top.reshape(-1, 3).astype(np.int16)
    b = bottom.reshape(-1, 3).astype(np.int16)
    g_top, g_bot = float(np.median(t[:, 1])), float(np.median(b[:, 1]))
    if g_top >= 250 and g_bot >= 250:
        return float(np.median(t[:, 0])) - float(np.median(b[:, 0]))
    return g_top - g_bot


def _longest_run(row_mask):
    """(start, end) of the longest True run in a 1D bool array, or (0,-1)."""
    if not row_mask.any():
        return 0, -1
    m = np.concatenate(([0], row_mask.view(np.int8), [0]))
    d = np.diff(m)
    starts = np.nonzero(d == 1)[0]
    ends = np.nonzero(d == -1)[0] - 1
    i = int(np.argmax(ends - starts))
    return int(starts[i]), int(ends[i])


def find_cap(img, y0, y1, x0, x_guess, span):
    """
    The empty track ends in a rounded grey cap that is nearly solid, whatever is
    behind the bar. Look for it within `span` columns of x_guess. Returns the bar's
    last column, or None if the cap can't be made out against this background.
    """
    hgt = y1 - y0 + 1
    q = max(1, hgt // 4)
    a = img[y0 + q: y1 - q + 1].astype(np.int16)
    w = img.shape[1]
    cand = []
    for x in range(max(x0 + 8, x_guess - span), min(w - 3, x_guess + span + 1)):
        c = a[:, x]
        m = c.mean(axis=1)
        grey = (c.max(axis=1) - c.min(axis=1) < 18) & (m > 68) & (m < 118) & (c[:, 2] >= c[:, 0] - 2)
        if grey.mean() < 0.6:
            continue
        nxt = a[:, x + 1:x + 3].reshape(-1, 3).mean(axis=0)
        prev = a[:, max(0, x - 6):x - 3].reshape(-1, 3)
        # outside the bar the picture changes sharply; a few columns inside it is still track
        if np.abs(nxt - c.mean(axis=0)).max() > 22 and prev.size and np.abs(prev.mean(axis=0) - nxt).max() > 15:
            cand.append(x)
    if not cand:
        return None
    return min(cand, key=lambda x: abs(x - x_guess))


def locate_bar(img, width=None):
    """
    Find the health bar inside img. Returns (y0, y1, x0, x1): the rows of the green
    fill and the columns of the WHOLE bar (filled + empty), or None.
    width: the bar's full width in pixels if it has been measured before at this
    window size; otherwise it is worked out from the bar's proportions.
    """
    h, w, _ = img.shape
    bright, anyg = _greens(img)       # (anyg = fill + label; no rim)
    rows = []
    for y in np.nonzero(bright.sum(axis=1) >= 6)[0].tolist():   # only rows with some fill-green
        s, e = _longest_run(anyg[y])
        if e - s + 1 >= 8 and bright[y, s:e + 1].mean() > 0.25:
            rows.append((y, s, e))
    if not rows:
        return None
    groups, cur = [], [rows[0]]
    for prev, r in zip(rows, rows[1:]):
        # same right-hand end on neighbouring rows (the left end can be broken up by
        # the "HEALTH" label, so it isn't used to group rows)
        if r[0] - prev[0] <= 2 and abs(r[2] - prev[2]) <= 3:
            cur.append(r)
        else:
            groups.append(cur)
            cur = [r]
    groups.append(cur)
    cands = []
    for gr in groups:
        n = len(gr)
        if not 8 <= n <= 90:
            continue
        ys = [r[0] for r in gr]
        x_s = int(np.percentile([r[1] for r in gr], 20))
        x_e = int(np.median([r[2] for r in gr]))
        # the fill's signature: brighter green at the top than at the bottom
        cols = slice(x_s + 2, max(x_s + 3, min(x_e - 1, x_s + 2 + 4 * n)))
        if _fill_gradient(img[ys[0]:ys[0] + 3, cols], img[ys[-1] - 2:ys[-1] + 1, cols]) < 8:
            continue
        cands.append((n * (x_e - x_s), ys[0], ys[-1], x_s, x_e))
    cands += _bars_under_number(img, groups)
    if not cands:
        return None
    # Biggest first - but a candidate whose grey end-cap sits exactly where the bar's
    # proportions say it should is the health bar, whatever else on screen is green.
    cands.sort(reverse=True)
    fallback = None
    for cand in cands[:6]:
        geo, capped = _bar_geometry(img, bright, cand, width)
        if geo is None:
            continue
        if capped:
            return geo
        if fallback is None:
            fallback = geo
    return fallback


def _bars_under_number(img, groups):
    """
    The game can draw the health number ("3036 (61%)") across the middle of the bar,
    nearly as tall as the bar itself. That cuts the green on every row it touches, so
    those rows end where the digits start and only a few clean rows are left hugging
    the top and the bottom of the fill - too few to be taken for a bar on their own.

    This pairs them back up: a thin band of rows above and a thin band below that end
    at the same place and start at the same place, with every row in between starting
    at that same left edge and white digits in the gap. Returns candidates in the same
    form locate_bar uses: (area, first row, last row, left, right).
    """
    out = []
    w = img.shape[1]
    # each band's left edge and usual right end, worked out once
    left = [min(r[1] for r in g) for g in groups]
    right = [sorted(r[2] for r in g)[len(g) // 2] for g in groups]
    for i, a in enumerate(groups):
        if not 2 <= len(a) <= 30:
            continue
        a_s, a_e = left[i], right[i]
        for j in range(i + 2, min(len(groups), i + 12)):
            c = groups[j]
            y_top, y_bot = a[0][0], c[-1][0]
            n = y_bot - y_top + 1
            if n > 90:
                break
            if n < 8 or not 2 <= len(c) <= 30:
                continue
            if abs(right[j] - a_e) > 3 or abs(left[j] - a_s) > 6:
                continue
            span = [r for g in groups[i:j + 1] for r in g]
            if len(span) < 0.9 * n:
                continue                      # rows with no green at all in between: not one bar
            if any(abs(r[1] - a_s) > 6 or r[2] > a_e + 3 for r in span):
                continue
            gap = img[a[-1][0] + 1:c[0][0], a_s:min(w, a_e + 5 * n)]
            if gap.size == 0 or int((gap.min(axis=2) > 225).sum()) < max(6, n):
                continue                      # nothing white in the gap: it isn't the number
            x_s = int(np.percentile([r[1] for r in span], 20))
            x_e = int(np.median([r[2] for r in a] + [r[2] for r in c]))
            cols = slice(x_s + 2, max(x_s + 3, min(x_e - 1, x_s + 2 + 4 * n)))
            if _fill_gradient(img[y_top:y_top + 3, cols], img[y_bot - 2:y_bot + 1, cols]) < 8:
                continue
            out.append((n * (x_e - x_s), y_top, y_bot, x_s, x_e))
    return out


def _bar_geometry(img, bright, cand, width):
    """(y0, y1, x0, x1) for one candidate from locate_bar, and whether its grey end-cap
    was found where the bar's proportions put it. (None, False) if it runs off the picture."""
    h, w, _ = img.shape
    _, y0, y1, x_s, x_e = cand
    hgt = y1 - y0 + 1
    # inner left end: the first column that is bright fill (skips the teal rim)
    mid = slice(y0 + hgt // 4, y1 - hgt // 4 + 1)
    colb = bright[mid, x_s:x_e + 1].mean(axis=0) > 0.5
    x0 = x_s + int(np.argmax(colb))
    # exact green height: count bright rows in the plain columns left of the label
    lo, hi = max(0, y0 - 4), min(h, y1 + 5)
    c0 = x0 + max(3, hgt // 6)                      # past the rounded corner, before the label
    cnt = bright[lo:hi, c0:c0 + max(3, hgt // 5)].sum(axis=0)
    if cnt.size and np.median(cnt) >= 8:
        tall = int(np.median(cnt))
        first = lo + int(np.argmax(bright[lo:hi, c0 + 1]))
        y0, y1, hgt = first, first + tall - 1, tall
    capped = bool(width)
    if width:
        x1 = x0 + int(width) - 1
    else:
        full_w = int(round(BAR_RATIO * hgt))
        x1 = x0 + full_w - 1
        cap = find_cap(img, y0, y1, x0, x1, max(3, int(full_w * 0.07)))
        if cap is not None:
            x1 = cap
            capped = True
    x1 = max(x1, x_e + 2)            # a full bar is its green plus the 2px rim
    if x1 >= w:
        return None, False           # the bar runs off the grabbed region
    return (y0, y1, x0, x1), capped


def read_fill(img, geo):
    """
    Fraction 0..1 of the bar that is filled, or None if the bar isn't there (menu,
    something covering it). Works whatever is behind the see-through empty part:
    a column counts as filled when nearly all of its rows are health-green.
    The edge column is read to a fraction of a pixel from how far its colour sits
    between the teal rim and the empty track next to it.
    """
    y0, y1, x0, x1 = geo
    if y0 < 0 or x0 < 0 or y1 >= img.shape[0] or x1 >= img.shape[1]:
        return None
    hgt = y1 - y0 + 1
    q = max(1, hgt // 5)
    rows = img[y0 + q: y1 - q + 1, x0: min(img.shape[1], x1 + 5)]
    W = x1 - x0 + 1
    if rows.shape[0] < 3 or W < 20:
        return None
    bright, core = _greens(rows)
    mid = core.mean(axis=0) >= 0.8
    # The game can draw the health number across the middle of the bar, covering these
    # rows. The few rows hugging the top and the bottom of the fill are never covered,
    # so a column also counts as filled when those are green. Without a number on the
    # bar this adds nothing: wherever they are green, the middle is too.
    e = max(2, hgt // 8)
    xe = min(img.shape[1], x1 + 5)
    hug_rows = np.concatenate((img[y0: y0 + e, x0: xe], img[y1 - e + 1: y1 + 1, x0: xe]))
    hug = _greens(hug_rows)[1].sum(axis=0) >= 2 * e - 2
    filled = mid | hug
    # the bar must start green, with the fill's top-to-bottom gradient
    if not filled[:3].all():
        return None
    if _fill_gradient(rows[:2, :3], rows[-2:, :3]) < 5 or bright[:, :3].mean() < 0.5:
        return None
    f = filled[:W]
    cg = np.concatenate(([0], np.cumsum(f)))
    score = cg + ((~f).sum() - (np.arange(f.size + 1) - cg))     # filled left of i, empty right
    edge = int(np.argmax(score))                                 # first column that isn't fill
    if cg[edge] < 0.92 * edge:
        return None                                              # holes in the green: not the bar
    inner = W - 2                                                # the fill's own 2px teal rim
    if edge >= inner:
        return 1.0
    px = float(edge)
    if edge > 0 and not mid[edge - 1]:
        # The fill ends underneath the number, so its end was read off the hugging rows.
        # Those stop a pixel or two short because the fill's corners are rounded: add back
        # the same amount the corner takes off at the left-hand end. No sub-pixel here.
        inset = 0
        while inset < min(hgt // 3, hug.size) and not hug[inset]:
            inset += 1
        return float(np.clip((px + inset) / inner, 0.0, 1.0))
    # sub-pixel: after the fill comes its teal rim - one solid column, then one that is
    # a blend of rim and empty track. How teal that second column is = the fraction.
    if edge + 3 < rows.shape[1]:
        track = rows[:, edge + 3].astype(np.float32)
        col = rows[:, edge + 1].astype(np.float32)
        d = TEAL[None, :] - track
        den = (d * d).sum(axis=1)
        ok = den > 900
        if ok.sum() >= max(2, rows.shape[0] // 3):
            t = ((col - track) * d).sum(axis=1)[ok] / den[ok]
            px += float(np.clip(np.median(t), 0.0, 1.0))
    return float(np.clip(px / inner, 0.0, 1.0))


# --------------------------------------------------------------------------
# Heal / damage events from the fill readings
# --------------------------------------------------------------------------
class StepDetector:
    """
    Watches the bar level. When it moves and then settles, emits one event:
    (t_start, delta, before, after). t_start is the first frame that moved, which
    is when the server's heal/hit arrived - that's what the clock syncs to.
    Movements of the same direction within MERGE seconds are joined, so a bar
    that animates in two steps still counts as one heal.
    """
    SETTLE = 0.10
    MERGE = 0.30

    def __init__(self, eps=0.0009):
        self.eps = eps
        self.level = None
        self.moving = False
        self.t0 = 0.0
        self.last_val = 0.0
        self.last_move = 0.0
        self.pending = None       # finished event waiting to see if it continues

    def reset(self):
        self.__init__(self.eps)

    def feed(self, t, f):
        out = []
        if self.level is None:
            self.level = f
            return out
        if not self.moving:
            if abs(f - self.level) > self.eps:
                d = f - self.level
                if self.pending and t - self.pending[4] <= self.MERGE \
                        and math.copysign(1, d) == math.copysign(1, self.pending[1]):
                    # the same heal/hit still animating
                    self.t0 = self.pending[0]
                    self.level = self.pending[2]
                    self.pending = None
                else:
                    self.t0 = t
                self.moving = True
                self.last_val = f
                self.last_move = t
        else:
            if abs(f - self.last_val) > self.eps * 0.5:
                self.last_val = f
                self.last_move = t
            elif t - self.last_move >= self.SETTLE:
                d = f - self.level
                ev = (self.t0, d, self.level, f, self.last_move)
                self.level = f
                self.moving = False
                if abs(d) > self.eps:
                    if self.pending:
                        out.append(self.pending[:4])
                    self.pending = ev
        if self.pending and not self.moving and t - self.pending[4] > self.MERGE:
            out.append(self.pending[:4])
            self.pending = None
        return out


# --------------------------------------------------------------------------
# The regen clock
# --------------------------------------------------------------------------
class TickModel:
    """
    Natural regen in CoS lands on a steady server rhythm (~15s). The model:

      * learns this creature's tick SIZE (its fingerprint) and the real gap
      * a heal counts as a tick when it lands on the beat; one that also has the
        right size moves the clock fully, an odd-sized one only nudges it
        ("trust the clock")
      * off-beat heals (healers, plushies, food) are ignored unless the rhythm
        has clearly moved
      * a beat that passes with the bar not full, no hit hiding it and no heal =
        regen is BLOCKED (bleed, deep wounds, 10+ burn). While blocked the clock
        keeps running, and the first correctly-sized heal afterwards resyncs it
        straight away - this is what stops the drift after bleeding
      * ailment icons (when taught) give the expected tick size up front:
        bleed = 0, burn = smaller (10%/stack), and DoT drains every 3s are allowed
        to eat part of a tick without it being thrown out
    """

    def __init__(self, period=TICK_PERIOD, known_sizes=(), px=1 / 400, restart=None):
        try:
            self.period = float(period)
        except (TypeError, ValueError):
            self.period = TICK_PERIOD
        if not 14.0 <= self.period <= 17.5:      # a damaged settings file can't break the clock
            self.period = TICK_PERIOD
        # a gap learned in earlier sessions counts as good evidence up front
        self.intervals = [self.period] * 3 if abs(self.period - TICK_PERIOD) > 1e-6 else []
        self.known = [float(k) for k in known_sizes
                      if isinstance(k, (int, float)) and 0.0005 < k < 0.6][-MAX_KNOWN_SIZES:]
        # Does CoS restart the regen timer when bleed ends, or keep the old beat?
        # Learned from what happens after each bleed (needs the bleed icon taught).
        restart = restart or {}
        if not isinstance(restart, dict):
            restart = {}
        offs = restart.get("offsets", [])
        self.restart_offsets = [float(o) for o in (offs if isinstance(offs, list) else [])
                                if isinstance(o, (int, float)) and -7.0 <= o <= 3.0][-8:]
        keep = restart.get("keep", 0)
        self.keep_beat_votes = min(8, max(0, int(keep))) if isinstance(keep, (int, float)) else 0
        self.px = px                      # one bar pixel as a fill fraction
        self.full_reset()
        self.log = deque(maxlen=600)
        self.icons_taught = frozenset()   # which ailment icons the player has taught

    # ---- state ----
    def full_reset(self):
        """New creature / back to menu: forget everything creature-specific."""
        self.anchor = None                # time of a beat
        self.confirmed = False
        self.base = None                  # plain natural tick size for this creature
        self.base_hist = []
        self.cur = None                   # current tick size (resting/mud can change it)
        self.burn_size = None             # last tick size seen while burning
        self.pending_sizes = []           # on-beat odd sizes waiting to become 'cur'
        self.cands = deque()              # unexplained heals (t, size)
        self.drops = deque()              # recent damage (t, size)
        self.last_real = None             # last heal that fitted perfectly
        self.blocked = False
        self.block_src = None             # 'icon' or 'inferred'
        self.misses = 0
        self.relock_until = 0.0
        self.checked_beat = None
        self.fill = None
        self.fill_hist = deque()          # (t, fill) last ~2s
        self.ailments = frozenset()
        self.last_event = None
        self.block_end = None             # when the bleed icon went away
        self.pre_bleed_anchor = None      # the beat grid before any restart guess
        self.bleed_since = None           # when the bleed icon appeared

    def note(self, t, msg):
        self.log.append(f"{t:10.2f}  {msg}")

    # ---- beat helpers ----
    def _nearest(self, t):
        k = round((t - self.anchor) / self.period)
        beat = self.anchor + k * self.period
        return beat, t - beat, k

    def _tol(self, k):
        """How far from the beat a tick may land. Grows with beats since a real
        tick (period error adds up), smaller once the gap is well learned."""
        base = 0.40 if len(self.intervals) >= 3 else 0.75
        if not self.confirmed:
            base += 0.35
        return min(1.6, base + 0.03 * max(0, abs(k) - 1))

    def next_beat(self, t):
        if self.anchor is None:
            return None
        # k >= 1: the anchor is never a 'next' tick (after bleed it can sit just
        # ahead of now as a placeholder for the restarted regen timer)
        k = max(1, math.floor((t - self.anchor) / self.period) + 1)
        return self.anchor + k * self.period

    def seconds_left(self, t):
        nb = self.next_beat(t)
        return None if nb is None else nb - t

    # ---- size expectations ----
    def _eps(self, size):
        return max(1.05 * self.px, 0.10 * size)

    def _dot_active(self, t):
        """Burn/poison/corrosion drain the bar every ~3s. True if that's going on."""
        ds = [d for d in self.drops if t - d[0] <= 10.0 and d[1] < 0.03]
        if len(ds) < 3:
            return False
        gaps = [b[0] - a[0] for a, b in zip(ds, ds[1:])]
        good = sum(1 for g in gaps if 2.4 <= g <= 3.6 or 5.0 <= g <= 7.0)
        return good >= 2

    def _dot_size(self, t):
        ds = [d[1] for d in self.drops if t - d[0] <= 10.0 and d[1] < 0.03]
        return float(np.median(ds)) if ds else 0.0

    def restarts_after_bleed(self):
        # needs a clear lead, so one unlucky tick can't flip it
        return len(self.restart_offsets) >= self.keep_beat_votes + 2

    def restart_info(self):
        return {"offsets": [round(o, 3) for o in self.restart_offsets[-8:]],
                "keep": self.keep_beat_votes}

    def _after_bleed_evidence(self, t):
        """First real tick after bleed: did it land on the OLD beat (CoS keeps the
        rhythm) or ~one period after the bleed ended (CoS restarts the timer)?
        Judged from where the tick actually landed, not from what we believed."""
        if self.block_end is None:
            return
        te, old = self.block_end, self.pre_bleed_anchor
        self.block_end = self.pre_bleed_anchor = None
        if old is None:
            return
        o = t - te
        if o > self.period + 2.5:
            return                       # too late to tell what happened
        k = round((t - old) / self.period)
        e_old = abs(t - (old + k * self.period))
        rel = float(np.median(self.restart_offsets)) if self.restart_offsets else 0.0
        e_restart = abs(o - self.period - rel)
        if e_old <= 0.5 and e_old <= e_restart:
            self.keep_beat_votes = min(8, self.keep_beat_votes + 1)
            self.note(t, "after bleed: tick kept the old beat")
        elif 0.6 * self.period <= o and e_restart < e_old:
            # stored relative to the period, so it carries over between creatures
            self.restart_offsets = (self.restart_offsets + [o - self.period])[-8:]
            self.keep_beat_votes = max(0, self.keep_beat_votes - 1)
            self.note(t, f"after bleed: regen timer restarted ({o:.2f}s after bleed ended)")

    def regen_blocked(self):
        return "bleed" in self.ailments or self.blocked

    def expected_size(self):
        """Predicted size of the next natural tick (fill fraction), or None."""
        if self.base is None:
            return None
        if self.regen_blocked():
            return 0.0
        if "burn" in self.ailments:
            return self.burn_size if self.burn_size is not None else None
        return self.cur if self.cur is not None else self.base

    def _fits(self, t, d, after):
        """Does a heal of size d look like a natural tick right now?"""
        if self.base is None:
            return True
        sizes = {self.base}
        if self.cur is not None:
            sizes.add(self.cur)
        if "burn" in self.ailments and self.burn_size is not None:
            sizes.add(self.burn_size)
        slack_lo = 0.0
        if self._dot_active(t) or self.ailments & {"burn"}:
            slack_lo = self._dot_size(t) * 1.3 + 0.5 * self.px
        for s in sizes:
            e = self._eps(s)
            lo, hi = s - e - slack_lo, s + e
            if after >= FULL:
                lo = 0.0                  # capped at full HP
            if lo <= d <= hi:
                return True
        if "burn" in self.ailments:      # unknown burn stacks: 10%/stack smaller
            if 0.04 * self.base <= d <= self.base + self._eps(self.base):
                return True
        return False

    def _tight(self, d):
        """Strict fingerprint test used when re-syncing off the beat."""
        if self.base is None:
            return False
        for s in {self.base, self.cur or self.base}:
            if abs(d - s) <= max(0.75 * self.px, 0.06 * s):
                return True
        return False

    # ---- learning ----
    def _learn_interval(self, t):
        if self.last_real is None:
            return
        gap = t - self.last_real
        m = round(gap / self.period)
        if 1 <= m <= 3:
            g = gap / m
            lim = 0.8 if len(self.intervals) >= 3 else 1.4
            if 14.0 <= g <= 17.5 and abs(g - self.period) <= lim:
                self.intervals = (self.intervals + [g])[-12:]
                self.period = float(np.median(self.intervals))

    def _learn_size(self, d, after):
        if after >= FULL:
            return                         # capped tick, not its real size
        if "burn" in self.ailments:
            self.burn_size = d
            return
        if self._dot_active(self.last_event or 0):
            return
        if self.base is None or abs(d - self.base) <= self._eps(self.base):
            # a plain natural tick: refine this creature's fingerprint
            self.base_hist = (self.base_hist + [d])[-7:]
            # mean, not median: on a whole-pixel bar a 3.4px tick reads 3,4,3,3,4...
            self.base = float(np.mean(self.base_hist))
            self.cur = self.base
            if len(self.base_hist) >= 2:
                self._remember_size(self.base)
        else:
            # boosted/reduced tick (resting, mud...): track it without touching base
            self.cur = d if self.cur is None else 0.6 * self.cur + 0.4 * d

    def _remember_size(self, s):
        for i, k in enumerate(self.known):
            if abs(k - s) <= max(0.75 * self.px, 0.06 * k):
                self.known[i] = (k + s) / 2
                return
        self.known = (self.known + [s])[-MAX_KNOWN_SIZES:]

    # ---- main inputs ----
    def set_ailments(self, t, ailments):
        ailments = frozenset(ailments)
        if ailments == self.ailments:
            return
        gone = self.ailments - ailments
        new = ailments - self.ailments
        self.ailments = ailments
        self.note(t, f"ailments now {sorted(ailments) or 'none'} (+{sorted(new)} -{sorted(gone)})")
        if "bleed" in new:
            self.bleed_since = t
            self.blocked, self.block_src = True, "icon"
        if "bleed" in gone or ("burn" in gone and self.blocked):
            # regen comes back: first proper tick after this re-syncs the clock
            self.relock_until = t + 2 * self.period + 1.5
            if self.block_src == "icon":
                self.block_src = "inferred"
        if "burn" in gone:
            self.burn_size = None          # next burn may have different stacks
        # a bleed icon that only flickered on for a moment is not treated as a bleed
        real_bleed = self.bleed_since is None or t - self.bleed_since >= 1.0
        if "bleed" in gone and real_bleed:
            self.block_end = t
            self.pre_bleed_anchor = self.anchor
            if self.restarts_after_bleed() and self.anchor is not None:
                off = float(np.median(self.restart_offsets)) + self.period
                # the anchor itself is not a real tick here, only the beat after it is
                self.anchor = t + off - self.period
                self.checked_beat = None
                self.note(t, f"bleed gone -> regen timer restarts, next tick in ~{off:.1f}s")

    def on_hurt(self, t, size):
        self.drops.append((t, size))
        while self.drops and t - self.drops[0][0] > 20:
            self.drops.popleft()

    def manual_sync(self, t):
        self.anchor = t
        self.confirmed = True
        self.blocked = False
        self.misses = 0
        self.checked_beat = None
        self.note(t, "manual resync (F6 / double-click)")

    def on_rise(self, t, d, before, after):
        """A heal of size d started at time t. Returns how it was classified."""
        self.last_event = t
        if self.anchor is None:
            return self._bootstrap(t, d, after)
        beat, e, k = self._nearest(t)
        tol = self._tol(k)
        fits = self._fits(t, d, after)

        if not self.confirmed and not (k >= 1 and abs(e) <= tol and fits):
            # only a first guess so far, and this heal doesn't agree with it -
            # real evidence (two matching ticks a gap apart) beats the guess
            self._add_cand(t, d)
            if self._pair_lock(t, d, after, strict=True):
                return "locked"

        if k >= 1 and abs(e) <= tol:
            if fits:
                self._after_bleed_evidence(t)
                self._learn_interval(t)
                self.anchor = t
                self.last_real = t
                self._learn_size(d, after)
                self.pending_sizes = []
                was = "blocked" if self.blocked else ""
                self.confirmed = True
                self.blocked = False
                self.block_src = None if "bleed" not in self.ailments else "icon"
                self.misses = 0
                self.relock_until = 0.0
                self.note(t, f"TICK  +{d*100:.2f}%  off by {e:+.2f}s {was}")
                return "natural"
            # on the beat but odd size: tick + a heal at the same time, or the
            # tick size changed (resting, mud, burn we can't see). Nudge only.
            self.anchor = beat + 0.3 * e
            if after < FULL and d > 0.3 * self.px:
                self.pending_sizes = (self.pending_sizes + [d])[-3:]
                ps = self.pending_sizes
                if len(ps) >= 2 and abs(ps[-1] - ps[-2]) <= self._eps(ps[-1]):
                    self.cur = (ps[-1] + ps[-2]) / 2
                    self.pending_sizes = []
                    self.anchor = t
                    self.last_real = t
                    self.blocked = False
                    self.note(t, f"tick size changed -> {self.cur*100:.2f}% (resting/mud/ailment)")
                    return "natural"
            self.note(t, f"on-beat heal, odd size +{d*100:.2f}% (nudged {0.3*e:+.2f}s)")
            return "nudge"

        # ---- off the beat ----
        if (self.blocked or t <= self.relock_until or not self.confirmed) and self._tight(d):
            self.note(t, f"RESYNC after block/drift: +{d*100:.2f}% landed {e:+.2f}s off the old beat")
            if self.block_end is None and "bleed" not in self.ailments and self.misses <= 2:
                self._learn_interval(t)        # plain drift: the gap itself is good data
            self._after_bleed_evidence(t)
            self.anchor = t
            self.last_real = t
            self.blocked = False
            self.block_src = None
            self.misses = 0
            self.confirmed = True
            self.relock_until = 0.0
            return "relocked"

        # rhythm moved? two fingerprint-sized heals a clean period apart
        self._add_cand(t, d)
        if self._tight(d):
            for (tc, dc) in list(self.cands)[:-1]:
                gap = t - tc
                m = round(gap / self.period)
                if 1 <= m <= 3 and abs(gap - m * self.period) <= 0.30 and self._tight(dc):
                    self.note(t, f"RELOCK: two ticks {gap:.2f}s apart off the old beat")
                    if m == 1:
                        self.intervals = (self.intervals + [gap])[-12:]
                        self.period = float(np.median(self.intervals))
                    self.anchor = t
                    self.last_real = t
                    self.confirmed = True
                    self.blocked = False
                    return "relocked"
        if self._triple_lock(t, d):
            return "relocked"
        self.note(t, f"ignored heal +{d*100:.2f}% ({e:+.2f}s off beat)")
        return "ignored"

    def _add_cand(self, t, d):
        if not self.cands or self.cands[-1] != (t, d):
            self.cands.append((t, d))
        while self.cands and t - self.cands[0][0] > 55:
            self.cands.popleft()

    def _clear_block(self):
        self.blocked = False
        self.block_src = "icon" if "bleed" in self.ailments else None
        self.misses = 0
        self.checked_beat = None
        self.pending_sizes = []
        self.relock_until = 0.0

    def _pair_lock(self, t, d, after, strict=False):
        """Two same-size heals one tick-gap apart = this creature's natural ticks.
        Used to lock on at the start, and to replace a first guess that was wrong."""
        for (tc, dc) in reversed(list(self.cands)[:-1]):     # nearest first: prefer one clean gap
            gap = t - tc
            m = round(gap / self.period)
            if not 1 <= m <= (1 if strict else 3):
                continue                 # strict: replacing a guess needs back-to-back ticks
            same = abs(d - dc) <= max(1.05 * self.px, 0.12 * max(d, dc))
            ok_gap = (abs(gap / m - self.period) <= 0.5) if len(self.intervals) >= 3 \
                else (14.3 <= gap / m <= 16.8)
            if same and ok_gap:
                self.anchor = t
                self.base = self.cur = (d + dc) / 2 if after < FULL else dc
                self.base_hist = [dc, d]
                if m == 1:   # a gap of 2-3 beats could hide a bleed - don't learn from it
                    self.intervals = (self.intervals + [gap])[-12:]
                    self.period = float(np.median(self.intervals))
                self.last_real = t
                self.confirmed = m == 1
                self._clear_block()
                self._remember_size(self.base)
                self.note(t, f"LOCK  two ticks {gap:.2f}s apart, size {self.base*100:.2f}%")
                return True
        return False

    def _triple_lock(self, t, d):
        """Three same-size heals on their own steady rhythm that don't match what we
        locked onto = we had the wrong rhythm or the wrong tick size. Switch to them."""
        cs = [c for c in list(self.cands)[:-1]
              if abs(c[1] - d) <= max(1.05 * self.px, 0.10 * max(d, c[1]))]
        for i, (tb, db) in enumerate(cs):
            if abs((t - tb) - self.period) > 0.35:
                continue
            for (ta, da) in cs[:i]:
                if abs((tb - ta) - self.period) <= 0.35:
                    self.base = self.cur = float(np.mean([da, db, d]))
                    self.base_hist = [da, db, d]
                    self.anchor = t
                    self.last_real = t
                    self.confirmed = True
                    self._clear_block()
                    self._remember_size(self.base)
                    self.note(t, f"RELOCK onto a new steady rhythm, size {self.base*100:.2f}%")
                    return True
        return False

    def _bootstrap(self, t, d, after):
        self._add_cand(t, d)
        if self._pair_lock(t, d, after):
            return "locked"
        for ks in self.known:
            if abs(d - ks) <= max(0.75 * self.px, 0.06 * ks):
                self.anchor = t
                self.base = self.cur = ks
                self.last_real = t
                self.confirmed = False
                self.relock_until = t + 2 * self.period + 1.5
                self.note(t, f"first guess: +{d*100:.2f}% matches a creature seen before")
                return "tentative"
        self.note(t, f"heal +{d*100:.2f}% (still learning)")
        return "searching"

    def on_sample(self, t, fill):
        """Called every frame with the bar level. Detects beats that were missed."""
        self.fill = fill
        self.fill_hist.append((t, fill))
        while self.fill_hist and t - self.fill_hist[0][0] > 3.0:
            self.fill_hist.popleft()
        if self.anchor is None:
            return
        # judge each beat once, a little after it
        beat, e, k = self._nearest(t)
        if k < 1:
            return
        tol = self._tol(k)
        if e < tol + 1.0 or self.checked_beat is not None and abs(self.checked_beat - beat) < 1:
            return
        self.checked_beat = beat
        if self.last_event is not None and abs(self.last_event - beat) <= tol + 0.05 \
                and self.anchor >= beat - tol:
            return                                    # a tick landed for this beat
        full = any(f >= FULL for (tt, f) in self.fill_hist if abs(tt - beat) <= 0.6)
        hurt = any(abs(dt - beat) <= 0.4 for (dt, _) in self.drops)
        if full:
            return                                    # full HP - ticks can't show
        if hurt:
            self.note(t, "beat hidden by a hit")
            return
        self.misses += 1
        if not self.blocked:
            self.blocked = True
            self.block_src = "icon" if "bleed" in self.ailments else "inferred"
            self.note(t, "no tick on the beat -> regen blocked (bleed?)")


# --------------------------------------------------------------------------
# The simple clock: timing only, tick size never matters
# --------------------------------------------------------------------------
# Limits on the gap between two natural ticks. Regen is a 15-second timer on the game's
# server: a busy server can make it run late, but it can never run early. Anything
# shorter than this was measured from heals that weren't natural ticks (or from
# something that only looked like a health bar), not from the game.
GAP_MIN, GAP_MAX = 14.85, 16.60         # one measured gap (a little slack for network jitter)
PERIOD_MIN, PERIOD_MAX = 14.95, 16.50   # the learned gap the countdown runs on


class SimpleClock:
    """
    Natural regen lands on a steady ~15s rhythm, but its SIZE changes all the time
    (mud, Healing Pulse, resting, burn...). So this clock ignores size completely:

      * the first heal it sees starts the countdown straight away
      * a heal that lands on the beat is a tick: the clock re-syncs to it and the
        real gap between ticks is learned from it
      * a heal that lands off the beat (healer, food...) is ignored once the rhythm
        has been confirmed by a tick landing on the countdown
      * while it is only a first guess, the newest heal restarts the countdown
      * if expected ticks stop arriving (bleed, or the rhythm moved), the countdown
        keeps running; two heals one tick-gap apart re-lock it to the new rhythm

    The gap between ticks:

      * is measured across the whole run of ticks seen so far (first to last, not
        one gap at a time), so it is accurate to a few hundredths of a second and
        the countdown stays right through minutes at full health or tabbed out
      * can only ever be a value the game could really produce (PERIOD_MIN..MAX)
      * is never trusted over what the game is doing now: until this session's own
        ticks have backed it up, a heal one real tick-gap after the last tick counts
        as a tick whatever gap was expected, and the gap is corrected from it
    """

    def __init__(self, period=TICK_PERIOD, known_sizes=(), px=1 / 400, restart=None):
        try:
            self.period = float(period)
        except (TypeError, ValueError):
            self.period = TICK_PERIOD
        if not PERIOD_MIN <= self.period <= PERIOD_MAX:    # a gap the game can't produce
            self.period = TICK_PERIOD
        # A gap remembered from an earlier session is only where the countdown starts
        # from. It is not evidence: this session's ticks have to back it up.
        self.intervals = []           # single gaps measured this session (for the report)
        self.trusted = False          # True once this session's own ticks have backed the gap up
        self.px = px
        self.log = deque(maxlen=600)
        self.sink = None              # optional: called with each line added to the log
        # (kept so the rest of the app and the tests can treat both clocks alike)
        self.known, self.base, self.cur = [], None, None
        self.ailments, self.icons_taught, self.block_src = frozenset(), frozenset(), None
        self.full_reset()

    def full_reset(self):
        self.anchor = None            # time of the last tick (or first heal)
        self.confirmed = False        # True once a heal has landed on the beat
        self.misses = 0               # expected ticks that never showed up
        self.blocked = False
        self.last_tick = None
        self.last_rise = None
        self.checked_beat = None
        self.drops = deque()
        self.fill_hist = deque()
        self.alts = deque()           # times of heals that didn't fit the countdown
        self.misses_since_alt = 0
        self.last_sample = None       # when the bar was last read
        self.blind = deque()          # (from, to) stretches when the bar was out of sight
        # (time, beat number) of each tick in the rhythm being followed. The gap is
        # measured across these. A new rhythm (new creature, re-lock) starts it again;
        # the gap learned so far is kept, since that belongs to the server.
        self.chain = deque(maxlen=24)
        self.late = deque(maxlen=3)   # how far off the gap each of the last ticks said it was

    def _new_chain(self, t):
        self.chain.clear()
        self.late.clear()
        self.chain.append((t, 0))

    def note(self, t, msg):
        self.log.append(f"{t:10.2f}  {msg}")
        if self.sink is not None:
            try:
                self.sink(msg)
            except Exception:
                pass

    def settled(self):
        """True when the rhythm being followed backs the gap up: at least three ticks
        in one unbroken run, three or more tick-gaps from first to last."""
        c = self.chain
        return len(c) >= 3 and c[-1][1] - c[0][1] >= 3

    def _learn(self):
        """Work the gap out from the whole run of ticks: the gap between every pair of
        them, taking the middle value with pairs that are further apart counting for
        more (two ticks ten gaps apart pin the gap down ten times better than two
        neighbours). Far steadier than any single gap, and a stray heal that got
        counted as a tick can't drag it off."""
        c = list(self.chain)
        pairs = sorted(((tb - ta) / (nb - na), nb - na)
                       for i, (ta, na) in enumerate(c) for (tb, nb) in c[i + 1:] if nb > na)
        if not pairs:
            return
        half, run, est = sum(w for _, w in pairs) / 2.0, 0.0, pairs[-1][0]
        for slope, w in pairs:
            run += w
            if run >= half:
                est = slope
                break
        if GAP_MIN <= est <= GAP_MAX:
            self.period = min(PERIOD_MAX, max(PERIOD_MIN, est))

    def _nearest(self, t):
        k = round((t - self.anchor) / self.period)
        return self.anchor + k * self.period, t - (self.anchor + k * self.period), k

    def _slack(self, k):
        """How far from the countdown a real tick could land, k tick-gaps after the last
        one seen. Every tick-gap that goes by unseen (full health, tabbed out) adds a
        little doubt, and how much depends on how well the gap has been measured: a
        gap taken from two neighbouring ticks can be a tenth of a second out, one
        measured across a dozen ticks only a hundredth."""
        base = 0.50 if self.trusted else 0.90                  # looser until the real gap is learned
        span = self.chain[-1][1] - self.chain[0][1] if self.chain else 0
        per = min(0.12, max(0.02, 0.12 / span)) if span else 0.12
        return base + per * max(0, abs(k) - 1)

    def _tol(self, k):
        return min(1.6, self._slack(k))

    def _stale(self, k):
        """So long since a tick was seen that the countdown is more likely wrong than
        right (the doubt has grown to well over twice what a tick is allowed)."""
        return self._slack(k) > 4.0

    def next_beat(self, t):
        if self.anchor is None:
            return None
        k = max(1, math.floor((t - self.anchor) / self.period) + 1)
        return self.anchor + k * self.period

    def seconds_left(self, t):
        nb = self.next_beat(t)
        return None if nb is None else nb - t

    def manual_sync(self, t):
        self.anchor, self.confirmed, self.misses, self.blocked = t, True, 0, False
        self.last_tick, self.checked_beat = None, None
        self.chain.clear()            # a key press isn't exact enough to measure the gap from
        self.late.clear()
        self.note(t, "manual resync (F6 / double-click)")

    def _start(self, t, d, why):
        if self.anchor is not None:
            self.alts.append(self.anchor)          # keep the old rhythm as a fallback
        self.anchor, self.confirmed, self.misses, self.blocked = t, False, 0, False
        self.last_tick, self.checked_beat = t, None
        self.misses_since_alt = 0
        self._new_chain(t)
        self.note(t, f"START  heal +{d*100:.2f}% -> counting from here ({why})")

    def _tick(self, t, d, e, what, k=None):
        """A natural tick at t. k = how many tick-gaps after the last one it is."""
        if k is None:
            k = round((t - self.last_tick) / self.period) if self.last_tick is not None else 0
        # How many tick-gaps a hop can span and still be counted correctly depends on
        # how well the gap is known: barely at all on a first guess, further once this
        # rhythm has measured it, a long way once it is trusted.
        reach = 40 if self.trusted else 12 if len(self.chain) >= 2 else 3
        if self.last_tick is not None and self.chain and 1 <= k <= reach:
            gap = (t - self.last_tick) / k
            self.intervals = (self.intervals + [gap])[-12:]
            self.chain.append((t, self.chain[-1][1] + k))
            # Three ticks running all later (or all earlier) than the gap says, by more
            # than jitter: the server's rhythm itself has changed (it got busier, or
            # quieter). Measure the gap from those ticks alone, not the old run.
            self.late.append(gap - self.period)
            if len(self.late) == 3 and min(abs(x) for x in self.late) > 0.15 \
                    and (min(self.late) > 0 or max(self.late) < 0):
                while len(self.chain) > 4:
                    self.chain.popleft()
                self.late.clear()
            self._learn()
            if self.settled():
                self.trusted = True
        else:
            self._new_chain(t)
        self.anchor, self.last_tick = t, t
        self.confirmed, self.misses, self.blocked = True, 0, False
        self.checked_beat = None
        self.alts.clear()
        self.misses_since_alt = 0
        self.note(t, f"{what}  +{d*100:.2f}%  ({e:+.2f}s from the countdown, tick gap {self.period:.2f}s)")

    def on_rise(self, t, d, before, after):
        self.last_rise = t
        while self.alts and t - self.alts[0] > 3.2 * self.period:
            self.alts.popleft()
        if self.anchor is None:
            self._start(t, d, "first heal seen")
            return "locked"
        beat, e, k = self._nearest(t)
        if k >= 1 and abs(e) <= self._tol(k):
            self._tick(t, d, e, "TICK  ")
            return "natural"
        # Not on the countdown - but exactly one real tick-gap after the last tick? Then
        # the gap the countdown was running on is what's wrong, not the heal. (Only while
        # that gap hasn't been backed up by this session's own ticks.)
        if not self.trusted and self.last_tick is not None and GAP_MIN <= t - self.last_tick <= GAP_MAX:
            self._tick(t, d, e, "TICK (one tick-gap after the last; gap corrected)", k=1)
            return "natural"
        # Off the countdown. Does it sit one tick-gap after an earlier unexplained heal?
        # Then THAT is the real rhythm (only trusted if the current one isn't proven solid).
        if not self.confirmed or self.misses >= 1:
            # (a trusted gap gives way too, once the countdown has missed twice running:
            # the server's own rhythm can change, e.g. when it gets busier)
            loose = not self.trusted or self.misses >= 2
            best = None                           # (how far from the expected gap, heal, tick-gaps)
            for a in self.alts:
                g = t - a
                if abs(g - self.period) <= 0.45 or (loose and GAP_MIN <= g <= GAP_MAX):
                    m = 1
                elif abs(g - 2 * self.period) <= 0.45:
                    m = 2
                else:
                    continue
                off = abs(g - m * self.period)
                if best is None or off < best[0]:
                    best = (off, a, m)
            if best is not None:
                off, a, m = best
                if off > 0.45:
                    self.trusted = False          # the gap was wrong: learn it again
                # a new rhythm: measure its gap from these two heals onwards
                self.last_tick = a
                self._new_chain(a)
                self._tick(t, d, t - (a + m * self.period), "TICK (rhythm found from an earlier heal)", k=m)
                return "relocked"
        if not self.confirmed:
            self._start(t, d, "the first guess hadn't been confirmed")
            return "relocked"
        if self._stale(k):
            # e.g. minutes at full health straight after spawning: the gap was never
            # measured well enough to carry the countdown this far. Count from this heal.
            self._start(t, d, "no tick seen for so long that the old countdown was only a guess")
            return "relocked"
        self.alts.append(t)
        while len(self.alts) > 4:
            self.alts.popleft()
        self.note(t, f"ignored heal +{d*100:.2f}% ({e:+.2f}s off the rhythm)")
        return "ignored"

    def on_hurt(self, t, size):
        self.drops.append((t, size))
        while self.drops and t - self.drops[0][0] > 20:
            self.drops.popleft()

    def on_sample(self, t, fill):
        """Every frame: notices when an expected tick never arrived."""
        if self.last_sample is not None and t - self.last_sample > 0.5:
            self.blind.append((self.last_sample, t))      # couldn't see the bar for this stretch
        self.last_sample = t
        while self.blind and t - self.blind[0][1] > 20:
            self.blind.popleft()
        self.fill_hist.append((t, fill))
        while self.fill_hist and t - self.fill_hist[0][0] > 4.0:
            self.fill_hist.popleft()
        if self.anchor is None:
            return
        beat, e, k = self._nearest(t)
        if k < 1:
            return
        tol = self._tol(k)
        if e < tol + 1.0 or (self.checked_beat is not None and abs(self.checked_beat - beat) < 1):
            return
        self.checked_beat = beat
        if self.last_rise is not None and abs(self.last_rise - beat) <= tol + 0.05:
            return                                        # a heal did land on it
        if any(lo < beat + tol and hi > beat - tol for (lo, hi) in self.blind):
            return                                        # the bar was out of sight around then (tabbed
                                                          # out, hidden) - can't call that tick missed
        if any(f >= FULL for (tt, f) in self.fill_hist if abs(tt - beat) <= 0.6):
            return                                        # full health: ticks can't show
        if any(abs(dt - beat) <= 0.4 for (dt, _) in self.drops):
            self.note(t, "expected tick may have been hidden by a hit")
            return
        self.misses += 1
        self.blocked = True
        self.note(t, "expected tick never came (bleed?)")
        # the countdown keeps missing while a heal that didn't fit it is waiting:
        # that heal was probably the real tick - count from it instead
        if self.alts:
            self.misses_since_alt += 1
            if self.misses_since_alt >= 2:
                a = self.alts[-1]
                self.alts.clear()
                self.anchor, self.confirmed, self.misses, self.blocked = a, False, 0, False
                self.last_tick, self.checked_beat, self.misses_since_alt = a, None, 0
                self._new_chain(a)
                self.note(t, "countdown kept missing -> now counting from the last heal that didn't fit")

    # no-ops, so this clock can stand in for the full model
    def set_ailments(self, t, ailments):
        pass

    def restart_info(self):
        return {}

    def restarts_after_bleed(self):
        return False


# --------------------------------------------------------------------------
# The grid clock (4.3): the regen timer never moves, so follow the whole rhythm
# --------------------------------------------------------------------------
# In CoS the natural regen timer is a fixed 15-second clock that starts when the
# creature spawns and never moves: bleed only makes the ticks heal nothing, it doesn't
# restart anything. So the ticks sit on a fixed grid, and the job is to find that grid
# among all the other heals (Healing Pulse, mud, food, healers...) and stay on it.
#
# SimpleClock above counted from whichever heal it last accepted. One stray heal that
# happened to land near the countdown moved the whole countdown to itself, and the
# first heal after spawning owned the countdown until something disagreed. This clock
# keeps every rhythm the heals could belong to side by side and shows the one with the
# most ticks backing it up:
#
#   * every heal starts a possible rhythm of its own, and also counts for any rhythm it
#     lands on
#   * a rhythm's time-of-tick comes from the middle of its last several ticks, not from
#     the newest one, so a stray heal near the countdown can't drag it
#   * a rhythm that three ticks have landed on is only given up for another one that is
#     clearly better backed, never for a single heal
#   * ticks that don't show (bleed, full health, a hit at the same moment, tabbed out)
#     cost a rhythm very little: the countdown just carries on through them
TOL_PROVEN = 0.30            # how far from its rhythm a tick may land (three or more ticks seen)
TOL_NEW = 0.45               # ...while the rhythm has only one or two ticks behind it
PAIR_NEAR = (14.90, 15.40)   # gap per tick allowed when two heals are 2-3 tick-gaps apart
MAX_TRACKS = 10
PHASE_WINDOW = 5             # ticks whose middle sets the time-of-tick
NEWEST_WINS = False          # while nothing is backed up yet: keep counting from the first heal until its
                             # own tick fails to show (measured: wrong less often than jumping to each new heal)
GHOST_SECONDS = 900.0        # how long a rhythm is remembered after the health bar was lost


class _Rhythm:
    """One possible tick rhythm: the heals that landed on it, and the line through them."""
    __slots__ = ("pts", "period", "phase", "bonus", "missed", "checked", "manual", "errs", "fixed",
                 "e_grid", "e_last", "hist")

    def __init__(self, t, period, bonus=0, manual=False):
        self.pts = [(t, 0)]           # (time, beat number) of each heal on this rhythm
        self.period = period
        self.phase = t                # time of beat 0 on the fitted line
        self.bonus = bonus            # extra backing: manual sync, or a rhythm seen before the bar was lost
        self.missed = 0               # beats in a row where a tick should have shown and didn't
        self.checked = 0              # last beat number judged for a miss
        self.manual = manual          # first point is a key press, not a heal
        self.errs = deque(maxlen=3)   # how far off the last ticks landed, before refitting
        self.fixed = False            # True once its gap has been measured from its own ticks
        # How well each way of predicting the next tick has done on this rhythm so far:
        # from the middle of the last several ticks (right when the server's timer is
        # steady and what varies is how late each tick shows up), or from just the last
        # one (right when the server's timer itself wanders).
        self.e_grid = deque(maxlen=8)
        self.e_last = deque(maxlen=8)
        # its last beats where a tick could have shown: True = a heal landed, False = none did
        self.hist = deque([True], maxlen=16)

    @property
    def hits(self):
        return len(self.pts)

    @property
    def weight(self):
        return len(self.pts) + self.bonus

    @property
    def last_n(self):
        return self.pts[-1][1]

    @property
    def span(self):
        return self.pts[-1][1] - self.pts[0][1]

    def at(self, n):
        return self.phase + self.period * n

    def gaps(self):
        """What its missing ticks count against it. Ticks go missing in runs (a bleed
        heals nothing for as long as it lasts), so a run costs the same however long it
        is; a rhythm that isn't real misses again and again between its lucky heals."""
        cost, run = 0, 0
        for ok in self.hist:
            if ok:
                cost, run = cost + min(2, run), 0
            else:
                run += 1
        return cost + min(2, run)

    def fit(self):
        c = self.pts[-24:]
        # A heal that lands on the rhythm after several beats with none (bleed, full
        # health, tabbed out) may be a stray that got lucky. It doesn't get a say in the
        # gap until the next tick has landed after it.
        g = c[:-1] if len(c) >= 3 and c[-1][1] - c[-2][1] >= 3 else c
        if len(g) >= 2:
            # the gap: middle value of the gap between every pair of ticks. Pairs further
            # apart count for more (they pin the gap down better), but only up to a point,
            # so one far-off heal can't outvote all the others.
            pairs = sorted(((tb - ta) / (nb - na), min(nb - na, 4))
                           for i, (ta, na) in enumerate(g) for (tb, nb) in g[i + 1:] if nb > na)
            half, run, est = sum(w for _, w in pairs) / 2.0, 0.0, pairs[-1][0]
            for slope, w in pairs:
                run += w
                if run >= half:
                    est = slope
                    break
            if GAP_MIN <= est <= GAP_MAX:
                self.period = min(PERIOD_MAX, max(PERIOD_MIN, est))
                self.fixed = True
        # the time-of-tick: middle of where the last few ticks say beat 0 was
        win = PHASE_WINDOW
        if len(self.e_grid) >= 5:
            g = sorted(abs(x) for x in self.e_grid)[len(self.e_grid) // 2]
            l = sorted(abs(x) for x in self.e_last)[len(self.e_last) // 2]
            if l < 0.75 * g:
                win = 1
        self.phase = self._middle(win)
        if win > 2 and len(c) >= 3:
            # Two ticks running that agree with each other but not with the ones before:
            # the server's timer slipped a little (a lag spike). Follow them.
            (ta, na), (tb, nb) = c[-2], c[-1]
            oa, ob = ta - self.period * na, tb - self.period * nb
            if nb - na <= 2 and abs(oa - ob) <= 0.10 and abs(0.5 * (oa + ob) - self.phase) > 0.12:
                self.phase = 0.5 * (oa + ob)

    def _middle(self, win):
        offs = sorted(t - self.period * n for (t, n) in self.pts[-win:])
        m = len(offs)
        return offs[m // 2] if m % 2 else 0.5 * (offs[m // 2 - 1] + offs[m // 2])


class GridClock:
    """The clock the app uses from 4.3. Same doors as SimpleClock (on_rise, on_hurt,
    on_sample, seconds_left, manual_sync, full_reset), so the app treats them alike."""

    def __init__(self, period=TICK_PERIOD, known_sizes=(), px=1 / 400, restart=None):
        try:
            self.period = float(period)
        except (TypeError, ValueError):
            self.period = TICK_PERIOD
        if not PERIOD_MIN <= self.period <= PERIOD_MAX:    # a gap the game can't produce
            self.period = TICK_PERIOD
        self.trusted = False          # True once this session's own ticks have measured the gap
        self.px = px
        self.log = deque(maxlen=600)
        self.sink = None
        self.known, self.base, self.cur = [], None, None
        self.ailments, self.icons_taught, self.block_src = frozenset(), frozenset(), None
        self.ghost = None             # (rhythm, bar level, when) from before the health bar was lost
        self.tracks, self.best = [], None
        self.full_reset()

    # ---- what the rest of the app looks at ----
    @property
    def anchor(self):
        return None if self.best is None else self.best.at(self.best.last_n)

    @property
    def confirmed(self):
        return self.best is not None and self.best.weight >= 2

    @property
    def misses(self):
        return 0 if self.best is None else self.best.missed

    @property
    def blocked(self):
        return self.best is not None and self.best.missed > 0

    @property
    def intervals(self):
        if self.best is None:
            return []
        p = self.best.pts[-13:]
        return [(tb - ta) / (nb - na) for (ta, na), (tb, nb) in zip(p, p[1:]) if nb > na]

    def note(self, t, msg):
        self.log.append(f"{t:10.2f}  {msg}")
        if self.sink is not None:
            try:
                self.sink(msg)
            except Exception:
                pass

    def full_reset(self):
        """Health bar lost (menu / new creature): forget the rhythms. The best one is kept
        as a 'ghost': if the next heals land on it, it was the same creature after all."""
        b = self.best
        if b is not None and b.hits >= 3 and not b.manual:
            level = self.fill_hist[-1][1] if getattr(self, "fill_hist", None) else None
            when = self.fill_hist[-1][0] if level is not None else b.pts[-1][0]
            self.ghost = (b, level, when)
        self.tracks, self.best = [], None
        self.drops = deque()
        self.fill_hist = deque()
        self.last_sample = None
        self.blind = deque()
        self.last_check = 0.0
        self.fresh = True             # no reading taken yet since the reset

    # ---- helpers ----
    def _tol(self, r, k):
        """How far from rhythm r a real tick could land, k beats after its last one. Each
        beat that goes by unseen adds a little doubt, less the better its gap is measured."""
        base = TOL_PROVEN if r.hits >= 3 else (0.60 if r.manual and r.hits < 3 else TOL_NEW)
        if r.span:
            per = min(0.12, max(0.015, 0.12 / r.span))
        else:
            per = 0.04 if self.trusted else 0.12
        return base + per * max(0, k - 1)

    def _stale(self, r, t):
        """So long since r's last tick that its countdown is more likely wrong than right."""
        k = (t - r.at(r.last_n)) / r.period
        return self._tol(r, int(k) + 1) > 4.0

    def _score(self, r, t):
        if self._stale(r, t):
            return 0.0
        s = min(r.weight, 6) - r.gaps()
        if r.fixed and r.hits == 2 and abs(r.period - (self.period if self.trusted else 15.03)) <= 0.13:
            s += 0.5                  # two heals a normal tick-gap apart: likelier ticks than strays
        return s

    def _on_ghost(self, t):
        g = self.ghost
        if g is None:
            return False
        r, _, when = g
        if t - when > GHOST_SECONDS:
            self.ghost = None
            return False
        k = round((t - r.at(r.last_n)) / r.period)
        if k < 1:
            return False
        res = t - r.at(r.last_n + k)
        return abs(res) <= min(1.2, 0.35 + min(0.12, max(0.015, 0.12 / max(1, r.span))) * k)

    def _pick_up_ghost(self, t, fill):
        """The health bar is back. If it reads what it read when it went (give or take
        the ticks since), it's the same creature after a menu: carry on with its rhythm
        straight away. A new creature spawns on full health and starts fresh."""
        r, level, when = self.ghost
        gone = t - when
        if level is None or gone > 180.0 or fill >= FULL or level >= FULL:
            return
        if abs(fill - level) > 0.02 + 0.08 * (gone / TICK_PERIOD):
            return
        self.ghost = None
        r.bonus = -(r.hits - 2)                  # on trial until its next tick lands
        r.missed = 0
        r.checked = r.last_n + int((t - r.at(r.last_n)) / r.period)
        self.tracks, self.best = [r], r
        self.note(t, f"health bar back at the level it left ({gone:.0f}s ago): same creature, countdown carries on")

    def _try(self, r, t):
        """Does a heal at t land on rhythm r? Returns (beat number, how far off) or None."""
        if r.hits == 1 and not r.fixed and not r.manual and not self.trusted:
            # Only one heal so far and the gap isn't measured yet: any gap the game could
            # really produce will do, and it sets this rhythm's gap.
            gap = t - r.pts[0][0]
            for k, (lo, hi) in ((1, (GAP_MIN, GAP_MAX)), (2, PAIR_NEAR), (3, PAIR_NEAR)):
                if lo <= gap / k <= hi:
                    return k, gap - k * r.period
            return None
        k = round((t - r.at(r.last_n)) / r.period)
        n = r.last_n + k
        res = t - r.at(n)
        if k >= 1 and abs(res) <= min(1.6, self._tol(r, k)):
            return n, res
        return None

    def _pick(self, t, why=""):
        """Show the best-backed rhythm. One that three ticks have landed on only gives
        way to another that is clearly better backed."""
        if not self.tracks:
            self.best = None
            return False
        cur = self.best if self.best in self.tracks else None
        top = max(self.tracks, key=lambda r: (self._score(r, t), r.pts[-1][0]))
        if cur is None:
            self.best = top
            return True
        if top is cur:
            return False
        s_top, s_cur = self._score(top, t), self._score(cur, t)
        if s_top >= s_cur + 2 or (cur.weight < 3 and s_top > s_cur) \
                or (top.hits >= 3 and top.missed == 0 and s_top >= 3 and cur.missed >= 2) \
                or (cur.weight < 2 and top.weight < 2 and s_top >= s_cur and NEWEST_WINS):
            self.best = top
            self.note(t, f"countdown moved to a better-backed rhythm ({top.hits} tick(s), "
                         f"gap {top.period:.2f}s; the old one had {cur.hits}, missed {cur.missed}){why}")
            return True
        return False

    def _tidy(self, t):
        keep = []
        for r in self.tracks:
            if r is self.best:
                keep.append(r)
                continue
            age = t - r.pts[-1][0]
            if r.hits == 1 and age > 3.3 * PERIOD_MAX:
                continue                      # nothing ever paired up with it
            if r.missed >= 4 and r.hits < 3:
                continue
            if r.hits >= 3 and min(r.weight, 6) - r.gaps() <= -2 and r.missed >= 3:
                continue                      # lucky heals now and then, never a steady run: not a rhythm
            if self._stale(r, t):
                continue
            keep.append(r)
        # the same rhythm found twice (started from two of its own ticks): keep the longer
        keep.sort(key=lambda r: -r.hits)
        out = []
        for r in keep:
            dup = False
            for o in out:
                if o.hits >= 2 and abs(o.period - r.period) <= 0.25 and all(
                        abs(tt - o.at(round((tt - o.phase) / o.period))) <= 0.12 for (tt, _) in r.pts):
                    dup = True
                    if r is self.best:
                        self.best = o
                    o.bonus = max(o.bonus, r.bonus)
                    break
            if not dup:
                out.append(r)
        if len(out) > MAX_TRACKS:
            out.sort(key=lambda r: (r is not self.best, -self._score(r, t), -r.pts[-1][0]))
            out = out[:MAX_TRACKS]
        self.tracks = out

    def _learn(self, r):
        """A well-measured rhythm teaches the app the server's real gap."""
        if r.hits >= 3 and r.span >= 3 and r.fixed:
            self.period = r.period
            self.trusted = True

    # ---- inputs ----
    def manual_sync(self, t):
        """F6 / double-click: 'I just ticked'. Start afresh from the key press; the real
        ticks that follow take over the exact timing."""
        r = _Rhythm(t, self.period, bonus=3, manual=True)
        self.tracks, self.best, self.ghost = [r], r, None
        self.fresh = False
        self.note(t, "manual resync (F6 / double-click)")

    def on_hurt(self, t, size, before=None):
        self.drops.append((t, size, before))
        while self.drops and t - self.drops[0][0] > 20:
            self.drops.popleft()

    def _glitch(self, t, d, after):
        """A dip that came straight back to exactly where it was (something passed over
        the bar for a moment - the mouse pointer, an effect) is not a hit plus a heal."""
        for (td, size, before) in self.drops:
            if before is not None and 0 <= t - td <= 1.5 \
                    and abs(after - before) <= 0.6 * self.px and abs(d - size) <= 0.6 * self.px:
                return True
        return False

    def on_rise(self, t, d, before, after):
        if self._glitch(t, d, after):
            self.note(t, f"ignored +{d*100:.2f}%: the bar dipped and came straight back (something passed over it)")
            return "ignored"
        was = self.best
        on_best, best_res = False, 0.0
        for r in self.tracks:
            hit = self._try(r, t)
            if hit is None:
                # a second heal on a beat that already has one: keep whichever is closer
                if r.hits >= 3 and round((t - r.at(r.last_n)) / r.period) == 0:
                    tl, nl = r.pts[-1]
                    if abs(t - r.at(nl)) < abs(tl - r.at(nl)) and not (r.manual and r.hits == 1):
                        r.pts[-1] = (t, nl)
                        r.fit()
                continue
            n, res = hit
            if r.hits >= 3:
                # score both ways of predicting this tick (see _Rhythm)
                tp, np_ = r.pts[-1]
                r.e_grid.append(t - (r._middle(PHASE_WINDOW) + r.period * n))
                r.e_last.append(t - (tp + r.period * (n - np_)))
            r.pts.append((t, n))
            r.errs.append(res)
            # Three ticks running all later (or all earlier) than the rhythm says, by more
            # than jitter: the server's gap itself changed (it got busier, or quieter).
            # Measure from those ticks alone.
            if len(r.errs) == 3 and min(abs(x) for x in r.errs) > 0.12 \
                    and (min(r.errs) > 0 or max(r.errs) < 0) and r.hits > 4:
                r.pts = r.pts[-4:]
                r.errs.clear()
            if r.manual and r.hits >= 3:
                r.pts.pop(0)                     # real ticks have taken over from the key press
                r.manual = False
            del r.pts[:-40]
            r.fit()
            r.missed = 0
            r.hist.append(True)
            if r.bonus < 0:
                r.bonus = 0                      # (a rhythm picked back up after a menu has proved itself again)
            r.checked = max(r.checked, n)
            if r is was:
                on_best, best_res = True, res
        # every heal is also the possible start of a rhythm of its own
        seed = _Rhythm(t, self.period, bonus=1 if self._on_ghost(t) else 0)
        if seed.bonus:
            self.note(t, "this heal landed on the rhythm from before the health bar was lost")
        self.tracks.append(seed)
        self._tidy(t)
        first = was is None
        changed = self._pick(t)
        b = self.best
        self._learn(b)
        if b.hits >= 3 and b.bonus >= 0:
            self.ghost = None
        if first:
            self.note(t, f"START  heal +{d*100:.2f}% -> counting from here (first heal seen)")
            return "locked"
        if b is was and on_best:
            self.note(t, f"TICK    +{d*100:.2f}%  ({best_res:+.2f}s from the countdown, tick gap {b.period:.3f}s, "
                         f"{b.hits} ticks on this rhythm)")
            return "natural"
        if changed:
            return "relocked"
        e = t - b.at(round((t - b.phase) / b.period))
        self.note(t, f"heal +{d*100:.2f}% off the rhythm ({e:+.2f}s) - not counted as a tick")
        return "ignored"

    def on_sample(self, t, fill):
        """Every frame: notices when a rhythm's expected tick never arrived."""
        if self.last_sample is not None and t - self.last_sample > 0.5:
            self.blind.append((self.last_sample, t))      # couldn't see the bar for this stretch
        self.last_sample = t
        while self.blind and t - self.blind[0][1] > 25:
            self.blind.popleft()
        self.fill_hist.append((t, fill))
        while self.fill_hist and t - self.fill_hist[0][0] > 5.0:
            self.fill_hist.popleft()
        if not self.tracks and self.ghost is not None and self.fresh:
            self._pick_up_ghost(t, fill)
        self.fresh = False
        if not self.tracks or t - self.last_check < 0.1:
            return
        self.last_check = t
        changed = False
        for r in self.tracks:
            unfixed = r.hits == 1 and not r.fixed and not r.manual and not self.trusted
            n = r.last_n + int((t - r.at(r.last_n)) / r.period)
            if n <= max(r.last_n, r.checked):
                continue
            beat = r.at(n)
            tol = min(1.6, self._tol(r, n - r.last_n))
            late = 0.0
            if t - beat < tol + late + 1.0:
                continue
            r.checked = n
            lo, hi = beat - tol, beat + tol + late
            if any(a < hi and b > lo for (a, b) in self.blind):
                continue                                      # bar out of sight then: can't call it missed
            if any(f >= FULL for (tt, f) in self.fill_hist if lo - 0.3 <= tt <= hi + 0.3):
                continue                                      # full health: ticks can't show
            if any(lo - 0.1 <= dt <= hi + 0.1 for (dt, _, _) in self.drops):
                continue                                      # a hit at that moment could have hidden it
            r.missed += 1
            r.hist.append(False)
            changed = True
            if r is self.best and r.missed == 1:
                self.note(t, "expected tick never showed (bleed, or regen blocked) - countdown carries on")
        if changed:
            self._tidy(t)
            self._pick(t, "; its expected ticks stopped coming")

    def next_beat(self, t):
        r = self.best
        if r is None:
            return None
        n = max(r.last_n + 1, math.floor((t - r.phase) / r.period) + 1) if not r.manual or r.hits > 1 \
            else math.floor((t - r.phase) / r.period) + 1
        nb = r.at(n)
        while nb <= t:
            n += 1
            nb = r.at(n)
        return nb

    def seconds_left(self, t):
        nb = self.next_beat(t)
        return None if nb is None else nb - t

    # no-ops, so this clock can stand in for the full model
    def set_ailments(self, t, ailments):
        pass

    def restart_info(self):
        return {}

    def restarts_after_bleed(self):
        return False


# --------------------------------------------------------------------------
# Ailment icons
# --------------------------------------------------------------------------
class IconBook:
    """
    Icons the player taught TickTracker by hovering them and pressing a key.
    Templates are stored as small RGB arrays; matching uses OpenCV's normalised
    cross-correlation inside a band of the screen around where they were taught.
    """
    NAMES = ("bleed", "burn")
    THRESH = 0.78

    def __init__(self):
        self.templates = {n: [] for n in self.NAMES}   # list of (array, window_h)
        self.band = None                                # (cy_rel, half_rel)
        self.xband = None                               # (left_rel, right_rel) or None = full width
        self.hits = {n: deque(maxlen=3) for n in self.NAMES}
        self.scores = {n: 0.0 for n in self.NAMES}

    def taught(self):
        return [n for n in self.NAMES if self.templates[n]]

    X_MARGIN = 0.30   # icons slide sideways as ailments come and go - search this far each way

    def add(self, name, patch, window_h, cy_rel, half_rel, cx_rel=None):
        self.templates[name] = (self.templates[name] + [(patch, window_h)])[-4:]
        if cx_rel is not None:
            lo, hi = max(0.0, cx_rel - self.X_MARGIN), min(1.0, cx_rel + self.X_MARGIN)
            self.xband = [lo, hi] if self.xband is None else [min(lo, self.xband[0]), max(hi, self.xband[1])]
        if self.band is None:
            self.band = [cy_rel, half_rel]
        else:  # widen the band to cover every taught spot
            top = min(self.band[0] - self.band[1], cy_rel - half_rel)
            bot = max(self.band[0] + self.band[1], cy_rel + half_rel)
            self.band = [(top + bot) / 2, (bot - top) / 2]

    def clear(self):
        self.__init__()

    def band_rect(self, rect):
        """Screen region to grab for icon matching, or None."""
        if self.band is None or not self.taught():
            return None
        left, top, w, h = rect
        cy, half = self.band
        y0 = max(0, int((cy - half) * h))
        y1 = min(h, int((cy + half) * h))
        if y1 - y0 < 8:
            return None
        x0, x1 = 0, w
        if self.xband is not None:
            x0, x1 = int(self.xband[0] * w), int(self.xband[1] * w)
            if x1 - x0 < 60:
                x0, x1 = 0, w
        return {"left": left + x0, "top": top + y0, "width": x1 - x0, "height": y1 - y0}

    def match(self, band_img, window_h, cv2):
        """Updates which ailments are showing. Returns frozenset of present names."""
        present = set()
        hay = np.ascontiguousarray(band_img[..., ::-1])   # RGB -> BGR for cv2
        small = None
        if min(hay.shape[:2]) >= 24:
            small = cv2.cvtColor(cv2.resize(hay, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA),
                                 cv2.COLOR_BGR2GRAY)
        for n in self.NAMES:
            best = 0.0
            for patch, th in reversed(self.templates[n]):      # newest sample first
                if best >= self.THRESH + 0.10:
                    break                                       # already a clear match
                tpl = np.ascontiguousarray(patch[..., ::-1])
                if th and abs(window_h - th) > 2:
                    sc = window_h / th
                    nw = max(6, int(round(tpl.shape[1] * sc)))
                    nh = max(6, int(round(tpl.shape[0] * sc)))
                    tpl = cv2.resize(tpl, (nw, nh), interpolation=cv2.INTER_AREA)
                if tpl.shape[0] > hay.shape[0] or tpl.shape[1] > hay.shape[1]:
                    continue
                best = max(best, self._score(hay, small, tpl, cv2))
            self.scores[n] = best
            self.hits[n].append(best >= self.THRESH)
            if sum(self.hits[n]) >= 2:
                present.add(n)
        return frozenset(present)

    @staticmethod
    def _score(hay, small, tpl, cv2):
        """Best match score of tpl in hay. Searches a half-size grey copy first (far
        cheaper), then checks the best few spots exactly, in colour, at full size."""
        th, tw = tpl.shape[:2]
        if small is None or min(th, tw) < 12:
            return float(cv2.matchTemplate(hay, tpl, cv2.TM_CCOEFF_NORMED).max())
        ts = cv2.cvtColor(cv2.resize(tpl, (max(3, tw // 2), max(3, th // 2)),
                                     interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
        if ts.shape[0] > small.shape[0] or ts.shape[1] > small.shape[1]:
            return float(cv2.matchTemplate(hay, tpl, cv2.TM_CCOEFF_NORMED).max())
        res = cv2.matchTemplate(small, ts, cv2.TM_CCOEFF_NORMED)
        best = 0.0
        for _ in range(8):      # other round icons look alike in grey - check several spots
            _, val, _, (lx, ly) = cv2.minMaxLoc(res)
            if val < 0.40:
                break
            x0, y0 = max(0, 2 * lx - 4), max(0, 2 * ly - 4)
            crop = hay[y0:y0 + th + 8, x0:x0 + tw + 8]
            if crop.shape[0] >= th and crop.shape[1] >= tw:
                best = max(best, float(cv2.matchTemplate(crop, tpl, cv2.TM_CCOEFF_NORMED).max()))
            res[max(0, ly - 3):ly + 4, max(0, lx - 3):lx + 4] = -1.0
        return best


def patch_is_icon_like(patch):
    """Reject flat patches (hovered empty space) - NCC can't match those."""
    return float(patch.astype(np.float32).std()) >= 10.0


def text_colour(model):
    """Timer text colour. The ailment blocking regen most wins: bleed red > burn orange."""
    ail = model.ailments
    if "bleed" in ail:
        return BLEED_RED
    if model.blocked and model.block_src == "inferred" and "burn" not in ail \
            and "bleed" not in model.icons_taught:
        return BLEED_RED          # regen stopped, bleed icon not taught: almost always bleed
    if "burn" in ail:
        return BURN_ORANGE
    return WHITE


def heal_text(model):
    """'+4.7%' style next-tick size, or '' if not known yet."""
    exp = model.expected_size()
    if exp is None:
        if "burn" in model.ailments and model.base is not None:
            return f"<{model.base*100:.1f}%"
        return ""
    v = exp * 100
    if v <= 0.0:
        return "+0%"
    return f"+{v:.1f}%" if v < 10 else f"+{v:.0f}%"
