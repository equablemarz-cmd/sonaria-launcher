"""
TickTracker combat alert.

While you are tabbed out of Roblox, this looks for Creatures of Sonaria's combat timer -
the top-right leave button turning red with a countdown on it - and tells the badge to
show its alert until you are back in the game.

How it looks (4.1.7):
  - Roblox's top-right corner can be seen on the screen (e.g. you clicked into Discord on
    another monitor): it reads the screen there, a plain copy of the pixels, the same way
    TickTracker reads the health bar.
  - Roblox is completely hidden behind other windows: it asks Windows for a picture of the
    Roblox window (PrintWindow, the way OBS's window capture works). That makes Roblox
    draw itself again, which can flash white - harmless while you can't see it, but up to
    4.1.6 it was also done while Roblox was in plain view, which made the game flash.
  - partly covered with the corner hidden: it skips that look rather than risk a flash.
It never reads or changes the game's memory, never sends keys or clicks, and the picture
stays in this program (one small crop is kept on this PC for the debug report, nothing is
uploaded).

Only numpy is needed, so everything here can be tried without Windows (see find_combat).
"""
from __future__ import annotations

import sys
import threading
import time

import numpy as np

IS_WIN = sys.platform == "win32"

CHECK_SECONDS = 0.5           # how often the Roblox window is looked at while tabbed out
HITS_NEEDED = 2               # the combat timer must show on this many looks in a row
REGION = 0.36                 # the leave button lives in the top-right corner: this share of the window


# --------------------------------------------------------------------------
# Spotting the combat timer in a picture of the Roblox window
# --------------------------------------------------------------------------
def top_right(img):
    """The top-right corner of the window picture, where the leave button sits."""
    h, w = img.shape[:2]
    return img[: max(1, int(h * REGION)), w - max(1, int(w * REGION)):]


def find_combat(img):
    """
    True if the leave button is showing its combat state: a flat red door
    (CoS draws it in exactly one red, 244/13/52) with the white, black-outlined
    countdown over it, sitting on a slate button.

    img = the whole Roblox window as a height x width x 3 array of RGB bytes.
    Returns (found, details) - details is a short text for the log / debug report.
    """
    h, w = img.shape[:2]
    if h < 200 or w < 200:
        return False, "window too small"
    reg = top_right(img)
    r = reg[..., 0].astype(np.int16)
    g = reg[..., 1].astype(np.int16)
    b = reg[..., 2].astype(np.int16)
    red = (r > 205) & (g < 55) & (b > 15) & (b < 95)
    total = int(red.sum())
    if total < 40:
        return False, f"no red ({total}px)"

    # Group the red into blobs on a coarse grid and keep the biggest one, so a stray
    # red pixel somewhere else in the corner can't stretch the box.
    cell = max(4, h // 160)
    gh, gw = red.shape[0] // cell, red.shape[1] // cell
    if gh < 2 or gw < 2:
        return False, "corner too small"
    grid = red[: gh * cell, : gw * cell].reshape(gh, cell, gw, cell).sum(axis=(1, 3))
    filled = grid >= max(2, cell * cell // 8)
    seen = np.zeros_like(filled)
    best, best_px = None, 0
    for sy, sx in zip(*np.nonzero(filled)):
        if seen[sy, sx]:
            continue
        stack, cells, px = [(sy, sx)], [], 0
        seen[sy, sx] = True
        while stack:
            y, x = stack.pop()
            cells.append((y, x))
            px += int(grid[y, x])
            for ny, nx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1),
                           (y - 1, x - 1), (y - 1, x + 1), (y + 1, x - 1), (y + 1, x + 1)):
                if 0 <= ny < gh and 0 <= nx < gw and filled[ny, nx] and not seen[ny, nx]:
                    seen[ny, nx] = True
                    stack.append((ny, nx))
        if px > best_px:
            best, best_px = cells, px
    if best is None:
        return False, "red is scattered"
    ys = [c[0] for c in best]
    xs = [c[1] for c in best]
    cy0, cy1, cx0, cx1 = min(ys), max(ys), min(xs), max(xs)
    # The countdown is drawn across the middle of the door, which can cut its red into a
    # top piece and a bottom piece. Take in any red directly above or below the biggest piece.
    reach = int(np.ceil(1.3 * (cx1 - cx0 + 1)))
    ya, yb = max(0, cy0 - reach), min(gh, cy1 + reach + 1)
    xa, xb = max(0, cx0 - 1), min(gw, cx1 + 2)
    near_y, near_x = np.nonzero(filled[ya:yb, xa:xb])
    if len(near_y):
        cy0, cy1 = min(cy0, ya + int(near_y.min())), max(cy1, ya + int(near_y.max()))
        cx0, cx1 = min(cx0, xa + int(near_x.min())), max(cx1, xa + int(near_x.max()))
    y0, y1 = cy0 * cell, (cy1 + 1) * cell
    x0, x1 = cx0 * cell, (cx1 + 1) * cell
    bh, bw = y1 - y0, x1 - x0
    box_red = red[y0:y1, x0:x1]
    n_red = int(box_red.sum())
    info = f"red blob {bw}x{bh}px at {x0},{y0} of corner, {n_red}px red"

    # the door is a little taller than wide and a few percent of the window's height
    if not 0.012 * h <= bh <= 0.14 * h:
        return False, info + " - wrong size"
    if not 0.35 <= bw / bh <= 1.25:
        return False, info + " - wrong shape"
    if n_red < 0.12 * bw * bh:
        return False, info + " - too thin"

    # the countdown sits on top of it: pure white digits with a near-black outline
    rr, gg, bb = r[y0:y1, x0:x1], g[y0:y1, x0:x1], b[y0:y1, x0:x1]
    white = (rr > 225) & (gg > 225) & (bb > 225)
    black = (rr < 50) & (gg < 50) & (bb < 55)
    if white.sum() < 0.05 * bw * bh or black.sum() < 0.04 * bw * bh:
        return False, info + " - no countdown on it"

    # and it is on a slate button, not something red out in the world
    py, px_ = bh // 2, bw
    Y0, Y1 = max(0, y0 - py), min(reg.shape[0], y1 + py)
    X0, X1 = max(0, x0 - px_), min(reg.shape[1], x1 + px_)
    R2, G2, B2 = r[Y0:Y1, X0:X1], g[Y0:Y1, X0:X1], b[Y0:Y1, X0:X1]
    slate = (np.abs(R2 - G2) < 22) & (B2 - G2 > 2) & (B2 - G2 < 30) & (G2 > 40) & (G2 < 125)
    if slate.mean() < 0.12:
        return False, info + " - not on a button"
    return True, info + " - combat timer"


# --------------------------------------------------------------------------
# Windows: finding the Roblox window and taking its picture
# --------------------------------------------------------------------------
if IS_WIN:
    import ctypes
    import os
    from ctypes import wintypes

    _u32 = ctypes.WinDLL("user32", use_last_error=True)
    _g32 = ctypes.WinDLL("gdi32", use_last_error=True)
    _H = ctypes.c_void_p

    _ENUM = ctypes.WINFUNCTYPE(wintypes.BOOL, _H, wintypes.LPARAM)
    _u32.EnumWindows.argtypes = [_ENUM, wintypes.LPARAM]
    _u32.EnumWindows.restype = wintypes.BOOL
    _u32.IsWindowVisible.argtypes = [_H]
    _u32.IsWindowVisible.restype = wintypes.BOOL
    _u32.IsIconic.argtypes = [_H]
    _u32.IsIconic.restype = wintypes.BOOL
    _u32.GetWindowTextW.argtypes = [_H, ctypes.c_wchar_p, ctypes.c_int]
    _u32.GetWindowTextW.restype = ctypes.c_int
    _u32.GetWindowThreadProcessId.argtypes = [_H, ctypes.POINTER(wintypes.DWORD)]
    _u32.GetWindowThreadProcessId.restype = wintypes.DWORD
    _u32.GetClientRect.argtypes = [_H, ctypes.POINTER(wintypes.RECT)]
    _u32.GetClientRect.restype = wintypes.BOOL
    _u32.GetDC.argtypes = [_H]
    _u32.GetDC.restype = _H
    _u32.ReleaseDC.argtypes = [_H, _H]
    _u32.ReleaseDC.restype = ctypes.c_int
    _u32.PrintWindow.argtypes = [_H, _H, ctypes.c_uint]
    _u32.PrintWindow.restype = wintypes.BOOL
    _g32.CreateCompatibleDC.argtypes = [_H]
    _g32.CreateCompatibleDC.restype = _H
    _g32.CreateCompatibleBitmap.argtypes = [_H, ctypes.c_int, ctypes.c_int]
    _g32.CreateCompatibleBitmap.restype = _H
    _g32.SelectObject.argtypes = [_H, _H]
    _g32.SelectObject.restype = _H
    _g32.DeleteObject.argtypes = [_H]
    _g32.DeleteObject.restype = wintypes.BOOL
    _g32.DeleteDC.argtypes = [_H]
    _g32.DeleteDC.restype = wintypes.BOOL
    _g32.GetDIBits.argtypes = [_H, _H, ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p,
                               ctypes.c_uint]
    _g32.GetDIBits.restype = ctypes.c_int
    _g32.BitBlt.argtypes = [_H, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, _H,
                            ctypes.c_int, ctypes.c_int, wintypes.DWORD]
    _g32.BitBlt.restype = wintypes.BOOL
    _u32.ClientToScreen.argtypes = [_H, ctypes.POINTER(wintypes.POINT)]
    _u32.ClientToScreen.restype = wintypes.BOOL
    _u32.WindowFromPoint.argtypes = [wintypes.POINT]
    _u32.WindowFromPoint.restype = _H
    _u32.GetAncestor.argtypes = [_H, ctypes.c_uint]
    _u32.GetAncestor.restype = _H
    _u32.GetWindowLongW.argtypes = [_H, ctypes.c_int]
    _u32.GetWindowLongW.restype = ctypes.c_long
    _SRCCOPY = 0x00CC0020
    _GA_ROOT = 2
    _OVERLAY = 0x00000008 | 0x00080000          # WS_EX_TOPMOST | WS_EX_LAYERED

    class _BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
                    ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD),
                    ("biCompression", wintypes.DWORD), ("biSizeImage", wintypes.DWORD),
                    ("biXPelsPerMeter", wintypes.LONG), ("biYPelsPerMeter", wintypes.LONG),
                    ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD)]

    def find_roblox_window():
        """The Roblox game window (its title is exactly "Roblox"), or None. Only the
        window's title and whether it is visible are read."""
        found = []
        me = os.getpid()

        def each(hwnd, _):
            try:
                if not _u32.IsWindowVisible(hwnd):
                    return True
                buf = ctypes.create_unicode_buffer(64)
                _u32.GetWindowTextW(hwnd, buf, 64)
                if buf.value != "Roblox":
                    return True
                pid = wintypes.DWORD()
                _u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                if pid.value != me:
                    found.append(hwnd)
                    return False                  # first match is enough
            except Exception:
                pass
            return True

        _u32.EnumWindows(_ENUM(each), 0)
        return found[0] if found else None

    def client_on_screen(hwnd):
        """(left, top, width, height) of the window's game area on the screen, or None."""
        rect = wintypes.RECT()
        if not hwnd or _u32.IsIconic(hwnd) or not _u32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        pt = wintypes.POINT(0, 0)
        if not _u32.ClientToScreen(hwnd, ctypes.byref(pt)):
            return None
        w, h = rect.right - rect.left, rect.bottom - rect.top
        if w < 200 or h < 200 or w > 16000 or h > 16000:
            return None
        return pt.x, pt.y, w, h

    def _at(hwnd, x, y, me):
        """What the screen shows at (x, y): "roblox", "overlay" (an always-on-top see-through
        window such as TickTracker's badge, the Damage Counter or Discord's overlay - what is
        under it can't be told from here) or "other" (another app's window)."""
        top = _u32.WindowFromPoint(wintypes.POINT(int(x), int(y)))
        if not top:
            return "other"
        root = _u32.GetAncestor(top, _GA_ROOT) or top
        if root == hwnd:
            return "roblox"
        if (_u32.GetWindowLongW(root, -20) & _OVERLAY) == _OVERLAY:      # GWL_EXSTYLE
            return "overlay"
        pid = wintypes.DWORD()
        _u32.GetWindowThreadProcessId(root, ctypes.byref(pid))
        return "overlay" if pid.value == me else "other"

    def visibility(hwnd):
        """How much of Roblox can be seen on the screen right now:
        "corner" - the top-right corner (where the leave button is) is in view
        "hidden" - none of the game area is in view (covered, minimised or off every screen)
        "partly" - some is in view, but not the corner
        Found by asking Windows which window is at a grid of points - nothing is captured."""
        box = client_on_screen(hwnd)
        if box is None:
            return "hidden", None
        left, top, w, h = box
        me = os.getpid()
        cw, ch = int(w * REGION), int(h * REGION)
        cx0, cy0 = left + w - cw, top
        corner = [_at(hwnd, cx0 + cw * (i + 0.5) / 6, cy0 + ch * (j + 0.5) / 6, me)
                  for i in range(6) for j in range(6)]
        roblox = corner.count("roblox")
        if roblox and roblox + corner.count("overlay") >= 33:     # 33 of 36 points
            return "corner", box
        if roblox:
            return "partly", box
        for i in range(8):
            for j in range(8):
                if _at(hwnd, left + w * (i + 0.5) / 8, top + h * (j + 0.5) / 8, me) == "roblox":
                    return "partly", box
        return "hidden", box

    def copy_screen(box):
        """A plain copy of that part of the screen (BitBlt SRCCOPY) as an H x W x 3 RGB
        array, or None. It doesn't ask Roblox or any other window to do anything."""
        left, top, w, h = box
        screen = _u32.GetDC(None)
        if not screen:
            return None
        mem_dc = bmp = old = None
        try:
            mem_dc = _g32.CreateCompatibleDC(screen)
            bmp = _g32.CreateCompatibleBitmap(screen, w, h)
            if not mem_dc or not bmp:
                return None
            old = _g32.SelectObject(mem_dc, bmp)
            ok = _g32.BitBlt(mem_dc, 0, 0, w, h, screen, left, top, _SRCCOPY)
            _g32.SelectObject(mem_dc, old)
            old = None
            if not ok:
                return None
            head = _BITMAPINFOHEADER()
            head.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
            head.biWidth, head.biHeight = w, -h
            head.biPlanes, head.biBitCount, head.biCompression = 1, 32, 0
            buf = np.empty((h, w, 4), np.uint8)
            got = _g32.GetDIBits(mem_dc, bmp, 0, h, buf.ctypes.data_as(ctypes.c_void_p),
                                 ctypes.byref(head), 0)
            if got != h:
                return None
            return buf[:, :, 2::-1]
        finally:
            if old and mem_dc:
                _g32.SelectObject(mem_dc, old)
            if bmp:
                _g32.DeleteObject(bmp)
            if mem_dc:
                _g32.DeleteDC(mem_dc)
            _u32.ReleaseDC(None, screen)

    def capture_window(hwnd):
        """
        A picture of the window's contents as a height x width x 3 RGB array, even when
        another window covers it. None if it can't be taken (minimised, closed, or this
        PC returns nothing for it).
        """
        if not hwnd or _u32.IsIconic(hwnd):
            return None
        rect = wintypes.RECT()
        if not _u32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        w, h = rect.right - rect.left, rect.bottom - rect.top
        if w < 200 or h < 200 or w > 16000 or h > 16000:
            return None
        win_dc = _u32.GetDC(hwnd)
        if not win_dc:
            return None
        mem_dc = bmp = old = None
        try:
            mem_dc = _g32.CreateCompatibleDC(win_dc)
            bmp = _g32.CreateCompatibleBitmap(win_dc, w, h)
            if not mem_dc or not bmp:
                return None
            old = _g32.SelectObject(mem_dc, bmp)
            # 1 = just the game area, 2 = ask the window manager for the real rendered contents
            ok = _u32.PrintWindow(hwnd, mem_dc, 1 | 2)
            _g32.SelectObject(mem_dc, old)        # a bitmap must be out of the DC to be read
            old = None
            if not ok:
                return None
            head = _BITMAPINFOHEADER()
            head.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
            head.biWidth, head.biHeight = w, -h   # negative height = rows run top to bottom
            head.biPlanes, head.biBitCount, head.biCompression = 1, 32, 0
            buf = np.empty((h, w, 4), np.uint8)
            got = _g32.GetDIBits(mem_dc, bmp, 0, h, buf.ctypes.data_as(ctypes.c_void_p),
                                 ctypes.byref(head), 0)
            if got != h:
                return None
            return buf[:, :, 2::-1]               # Windows hands back blue-green-red: flip to RGB
        finally:
            if old and mem_dc:
                _g32.SelectObject(mem_dc, old)
            if bmp:
                _g32.DeleteObject(bmp)
            if mem_dc:
                _g32.DeleteDC(mem_dc)
            _u32.ReleaseDC(hwnd, win_dc)

    class _XINPUT_VIBRATION(ctypes.Structure):
        _fields_ = [("wLeftMotorSpeed", ctypes.c_ushort), ("wRightMotorSpeed", ctypes.c_ushort)]

    _xinput = None
    for _name in ("xinput1_4", "xinput1_3", "xinput9_1_0"):
        try:
            _xinput = ctypes.WinDLL(_name)
            _xinput.XInputSetState.argtypes = [ctypes.c_uint, ctypes.POINTER(_XINPUT_VIBRATION)]
            _xinput.XInputSetState.restype = ctypes.c_uint
            break
        except Exception:
            _xinput = None

    def _rumble_all(strength):
        """Sets the rumble on every connected Xbox-style controller. Returns how many answered."""
        if _xinput is None:
            return 0
        n = 0
        for pad in range(4):
            v = _XINPUT_VIBRATION(int(65535 * strength), int(65535 * strength))
            if _xinput.XInputSetState(pad, ctypes.byref(v)) == 0:
                n += 1
        return n
else:
    def find_roblox_window():
        return None

    def capture_window(hwnd):
        return None

    def visibility(hwnd):
        return "hidden", None

    def copy_screen(box):
        return None

    def _rumble_all(strength):
        return 0


def rumble(pulses=3, on=0.22, off=0.16):
    """Three short buzzes on any connected controller, on its own thread. Does nothing
    if there is no controller. The motors are always switched back off."""
    def run():
        try:
            for _ in range(pulses):
                if _rumble_all(0.9) == 0:
                    return
                time.sleep(on)
                _rumble_all(0.0)
                time.sleep(off)
        except Exception:
            pass
        finally:
            try:
                _rumble_all(0.0)
            except Exception:
                pass
    threading.Thread(target=run, daemon=True).start()


# --------------------------------------------------------------------------
# The watcher: its own thread, so it can never hold up the health bar reading
# --------------------------------------------------------------------------
class CombatWatcher(threading.Thread):
    """
    is_away()   -> True while another app is in front of Roblox
    is_enabled() -> the menu switch
    log(text)   -> TickTracker's log
    """

    def __init__(self, is_away, is_enabled, log=lambda text: None):
        super().__init__(daemon=True)
        self.is_away, self.is_enabled, self.log = is_away, is_enabled, log
        self.stop = False
        self.alerting = False          # combat started while tabbed out; cleared when you're back in Roblox
        self.test_until = 0.0
        self.status = "waiting for you to tab out"
        self.detail = ""
        self.last_corner = None        # the last corner picture looked at, for the debug report
        self.captures = 0
        self.method = "none yet"
        self._hits = 0
        self._seen_calm = False        # the timer has been seen NOT showing since you tabbed out
        self._said = set()

    def active(self):
        """True while the badge should be showing the alert."""
        return self.alerting or time.monotonic() < self.test_until

    def test(self, seconds=5.0):
        self.test_until = time.monotonic() + seconds
        rumble()

    def _once(self, text):
        if text not in self._said:
            self._said.add(text)
            self.log(text)

    def run(self):
        while not self.stop:
            time.sleep(CHECK_SECONDS)
            try:
                self.step()
            except Exception as e:
                self.status = f"error: {e!r}"
                self._once(f"combat alert problem: {e!r}")

    def step(self):
        if not self.is_enabled():
            self.alerting = False
            self._hits, self._seen_calm = 0, False
            self.status = "switched off in the menu"
            return
        if not self.is_away():
            if self.alerting:
                self.log("combat alert cleared - you're back in Roblox")
            self.alerting = False
            self._hits, self._seen_calm = 0, False
            self.status = "waiting for you to tab out"
            return
        if self.alerting:
            return                      # it stays on until you're back; nothing more to look for
        hwnd = find_roblox_window()
        if not hwnd:
            self.status = "tabbed out, but no Roblox window is open"
            return
        seen, box = visibility(hwnd)
        if seen == "corner":
            img = copy_screen(box)                # Roblox's corner is in view: just read the screen
            how = "reading the screen"
        elif seen == "hidden":
            img = capture_window(hwnd)            # can't be seen, so a redraw can't be seen either
            how = "picturing the hidden Roblox window"
        else:
            self.status = "tabbed out, Roblox partly covered - its top-right corner isn't in view"
            self.method = "skipped (corner covered)"
            return
        self.method = how
        if img is None:
            self.status = "tabbed out, but Roblox can't be pictured (minimised?)"
            return
        corner = top_right(img)
        if int(corner.max()) < 12:
            self.status = "tabbed out, but Windows gives a blank picture of Roblox"
            self._once("combat alert: Windows returned a blank picture of the Roblox window on this PC")
            return
        self.captures += 1
        self._once(f"combat alert: {how} works ({img.shape[1]}x{img.shape[0]})")
        found, self.detail = find_combat(img)
        self.last_corner = corner.copy()
        if not found:
            self._hits = 0
            self._seen_calm = True
            self.status = "tabbed out, watching for the combat timer"
            return
        if not self._seen_calm:
            # already fighting when you tabbed out: you know. Wait for it to end first.
            self.status = "tabbed out during a fight - will alert on the next one"
            return
        self._hits += 1
        if self._hits >= HITS_NEEDED:
            self.alerting = True
            self.status = "ALERT: combat started while you were tabbed out"
            self.log(f"combat alert: {self.detail}")
            rumble()

    def report(self):
        return (f"Combat alert: {self.status}\n"
                f"  last look: {self.detail or 'none yet'}\n"
                f"  last way of looking: {self.method}\n"
                f"  pictures taken of the Roblox window: {self.captures}")
