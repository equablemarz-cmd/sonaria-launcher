TICKTRACKER 4.3.0 - natural heal tick timer for Creatures of Sonaria
==================================================================
by Sonaria Software

A little round badge that sits on top of your screen and counts down to your next
natural heal tick. It reads your HEALTH bar off the screen, like you do.
It only LOOKS - it never touches Roblox.


FOLLOWS THE REAL RHYTHM (new in 4.3.0)
  Your natural regen is a fixed 15-second clock that never moves, but TickTracker
  used to count from whichever heal it last accepted. One stray heal near the
  countdown (Healing Pulse, mud, food, a healer) pulled the whole countdown over to
  itself, and the first heal after you spawned owned the countdown even when it
  wasn't a tick. Now it weighs up every rhythm your heals could belong to, side by
  side, and shows the one with the most ticks behind it:
    - a stray heal near the countdown no longer drags it: the time of your tick
      comes from the middle of your last several ticks, not the newest heal
    - a rhythm three ticks have landed on is only dropped for one that is clearly
      better backed up, never for a single heal
    - bleed (ticks that heal nothing), full health, a hit at the same moment: the
      countdown just carries on through them and is still right afterwards
    - if the first heal it counted from wasn't a tick, it switches to the real
      rhythm as soon as that heal's own tick fails to show
    - open a menu and come back to the same creature: the countdown carries on
      straight away instead of starting again
    - something passing over the health bar for a moment (mouse pointer, an
      effect) is no longer taken for a hit and a heal
    - the gap between ticks can't be bent by one far-off heal any more
  In simulated fights run through both versions (made-up ticks, stray heals and
  hits - not recorded gameplay), the old countdown was more than half a second out
  22% of the time; this one 0.4%. Through 90-second bleeds with stray heals: 25%
  before, under 1% now.


NO MORE FLASHING, PART 2 (new in 4.1.7)
  The combat alert looks at Roblox whenever another window is in front - even when
  Roblox is still in plain view (say you clicked into Discord on your other
  monitor, or onto the Damage Counter). It did that by asking Roblox to draw itself
  again, which can make the game flash white. Now:
    - if Roblox's top-right corner is in view, it just reads the screen there, the
      same plain copy TickTracker uses for the health bar
    - only if Roblox is completely hidden behind other windows does it ask Roblox
      for a picture (a flash you can't see doesn't matter)
    - if Roblox is partly covered and the corner is hidden, it skips that look


NO MORE FLASHING (new in 4.1.6)
  On some PCs the game, menus or overlays flickered while TickTracker was open. The
  way it copied the screen (60 times a second) also made Windows redraw every
  see-through window - its own badge, the Damage Counter, game overlays - on each
  copy. It now takes a plain copy of the screen's pixels, so Windows has nothing
  extra to redraw. Reading speed and timing are unchanged.


STAYS IN STEP (new in 4.1.5)
  The countdown could end up a second or more out and stay that way. TickTracker
  learns the gap between your ticks, and a few heals that weren't natural ticks
  (or a green menu button it took for a health bar) could teach it a gap the game
  never uses, such as 14.2 seconds. It then kept that gap, even after a restart.
  Now:
    - the gap can only be one the game can really produce (15 seconds, a little
      longer on a busy server), and a wrong one saved by an older version is
      thrown away
    - the gap is measured across every tick it has seen, not one at a time, so
      the countdown stays right through minutes at full health or tabbed out
    - if your ticks stop landing on the countdown, it corrects itself within a
      tick or two instead of staying wrong
    - reading a different bar than before (the creature menu's Play button looks
      like a health bar) is a fresh start, so a new creature never inherits the
      old one's countdown
  It also writes each heal it saw, and what it made of it, into its log, so a
  countdown that was out can be looked into afterwards.


WORKS WITH WINDOWS HDR (new in 4.1.4)
  With HDR switched on in Windows, the screen comes back much brighter than it
  looks, and TickTracker could no longer recognise the health bar: the badge
  just showed the heart. It now reads the bar with HDR on or off.


COMBAT ALERT (new in 4.1)
  Tabbed out to another window and something attacks you? The moment the game's
  combat timer appears (the leave button in the top-right turning red with its
  countdown), the badge shows an alert icon with a pulsing yellow glow, and stays that way until you
  click back into Roblox. A connected controller gives three short buzzes too.

  It only goes off for a fight that STARTS while you're tabbed out, and only while
  another window is in front. Right-click the badge to switch it off or to test it.

  If Roblox's top-right corner is in view, it reads the screen there. If Roblox is
  completely hidden behind another window, TickTracker asks Windows for a picture of
  the Roblox window - the same thing OBS's window capture and Discord's screen share
  do. It can't see a minimised game, so leave Roblox open behind your other window
  rather than minimising it. With Windows HDR on, it may miss a fight while Roblox's
  corner is in view (the screen comes back brighter) - you can see the timer then.


HOW TO START IT
  1. Unzip the whole TickTracker folder somewhere (Desktop, Documents, anywhere).
     Don't run it from inside the zip - it needs its files next to it.
  2. Open the folder and double-click  TickTracker.exe
  That's it. Nothing to install, no Python needed, no internet needed.
  Works on 64-bit Windows 10 and 11.

  Want it on your Desktop or taskbar with its own icon?
  Right-click the badge -> "Put a TickTracker shortcut on the Desktop".
  Then right-click that shortcut -> Show more options -> Pin to taskbar.


THE BADGE
  number       seconds until your next natural tick
  heart icon   not counting yet: no heal seen since you spawned, or it can't see
               a health bar

  drag          move it
  mouse wheel   bigger / smaller
  double-click  "I just ticked" - manual resync  (F6 does the same)
  right-click   menu: resync, reset size, combat alert on/off and test, window type,
                OBS link, debug report, files, shortcut, quit

  The badge is drawn with soft edges and a soft drop shadow, like the game's own
  buttons. If that ever looks wrong on your PC (black box, nothing showing), it
  switches itself to a plain hard-edged window - or pick it from the menu.

  While TickTracker is open, F6 belongs to it (in every app). If another program
  already uses F6, TickTracker leaves it alone - double-click the badge instead.


HOW IT WORKS
  It searches the screen for the green HEALTH bar (so it doesn't matter where the
  Roblox window is, or which monitor), then reads it 60 times a second. Each look
  is a plain copy of the screen's pixels, like a screenshot.
  It goes by TIMING only - tick size never matters, so mud, Healing Pulse, resting
  and so on can't confuse it:
    - the first heal it sees starts the countdown straight away
    - every heal is weighed against every rhythm it could belong to; the rhythm
      with the most ticks landing on it, 15 seconds apart, is the one shown
    - heals that are off that rhythm (healers, food...) are ignored
    - if the first heal wasn't a tick, it moves to the real rhythm once that heal's
      own tick fails to show; press F6 right as you tick to set it yourself
  If you're in Roblox and the bar is gone for 8 seconds (menu, new creature), or
  it finds itself reading a different bar than before, it starts fresh - unless the
  bar comes back reading what it read before (same creature), when it carries on.
  If you tab out to another app, it keeps counting from the rhythm it learned (it
  can't see ticks while you're away) and picks up when you're back.


IS IT SAFE?  WHAT IT DOES AND DOESN'T DO
  - TickTracker.exe is the official Python program from python.org (pythonw.exe),
    only renamed. Right-click it -> Properties -> Digital Signatures: it is signed
    by the Python Software Foundation. The other .dll/.pyd files are official
    Python, numpy and Pillow files.
  - TickTracker itself is plain text you can open in Notepad and read:
    app\ticktracker.py and app\ttcore.py.
  - It never touches Roblox: no reading game memory, no injecting, no clicking or
    typing for you. It takes pictures of the screen and looks for the health bar,
    and while you're tabbed out, pictures of the Roblox window to look for the
    combat timer.
  - It never uses the internet. Nothing is uploaded anywhere.
  - It does not watch your keyboard. F6 uses Windows' normal hotkey system.
  - What it saves, all in one folder on your own PC (right-click the badge ->
    "Open TickTracker's files"): your settings, a log of what it did, and two
    small pictures to help fix problems - the health bar it found, and (when it
    can't find a bar while Roblox is in front) the bottom half of your screen.
    Each new picture replaces the last one. Delete that folder any time.
  - For OBS it offers a copy of the badge at http://127.0.0.1:47615/overlay.
    Only your own PC can reach that address.

  Windows or your antivirus still complains?  Some are wary of anything new from
  a zip. Check the signature as above; if Windows shows "Windows protected your
  PC", click More info -> Run anyway. If your antivirus removed a file, unzip
  again after allowing the folder.


RECORDING WITH OBS
  See OBS\HOW TO SET UP OBS.txt.


IF SOMETHING'S WRONG
  Right-click the badge -> Save debug report, and send that file (plus
  capture_no_bar.png from "Open TickTracker's files" if it can't find your health
  bar) to the Sonaria Software channel on Discord.
  If it won't start at all, a message tells you why; the same text is saved as
  startup_error.txt in %LOCALAPPDATA%\TickTracker.

  To remove TickTracker: quit it, delete this folder, and delete
  %LOCALAPPDATA%\TickTracker (paste that into File Explorer's address bar).


Font: Source Sans 3 by Adobe (SIL Open Font License). Licences for everything bundled are in
app\licenses and app\site-packages.
