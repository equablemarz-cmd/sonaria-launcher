"""
Damage Counter - the Windows parts: finding the Roblox window, taking a picture of
its game area, and drawing the panel with soft see-through edges.

The picture is taken the way OBS's window capture does it (PrintWindow), so the
counter's own panel is never in it and it still works with Roblox partly covered.
If this PC hands back an empty picture, the screen itself is read instead (mss),
with the counter's own panel blanked out. Nothing here reads or changes Roblox's
memory, and nothing sends keys or clicks.
"""
from __future__ import annotations

import ctypes
import os
import sys

import numpy as np

IS_WIN = sys.platform == "win32"

if IS_WIN:
    from ctypes import wintypes as _wt

    _u32 = ctypes.WinDLL("user32", use_last_error=True)
    _g32 = ctypes.WinDLL("gdi32", use_last_error=True)
    _k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _H = ctypes.c_void_p

    _ENUM = ctypes.WINFUNCTYPE(_wt.BOOL, _H, _wt.LPARAM)
    _u32.EnumWindows.argtypes = [_ENUM, _wt.LPARAM]
    _u32.IsWindowVisible.argtypes = [_H]
    _u32.IsIconic.argtypes = [_H]
    _u32.IsWindow.argtypes = [_H]
    _u32.GetWindowTextW.argtypes = [_H, ctypes.c_wchar_p, ctypes.c_int]
    _u32.GetWindowThreadProcessId.argtypes = [_H, ctypes.POINTER(_wt.DWORD)]
    _u32.GetClientRect.argtypes = [_H, ctypes.POINTER(_wt.RECT)]
    _u32.ClientToScreen.argtypes = [_H, ctypes.POINTER(_wt.POINT)]
    _u32.GetForegroundWindow.restype = _H
    _u32.GetDC.argtypes = [_H]
    _u32.GetDC.restype = _H
    _u32.ReleaseDC.argtypes = [_H, _H]
    _u32.PrintWindow.argtypes = [_H, _H, ctypes.c_uint]
    _u32.PrintWindow.restype = _wt.BOOL
    _u32.GetParent.argtypes = [_wt.HWND]
    _u32.GetParent.restype = _wt.HWND
    _g32.CreateCompatibleDC.argtypes = [_H]
    _g32.CreateCompatibleDC.restype = _H
    _g32.CreateCompatibleBitmap.argtypes = [_H, ctypes.c_int, ctypes.c_int]
    _g32.CreateCompatibleBitmap.restype = _H
    _g32.SelectObject.argtypes = [_H, _H]
    _g32.SelectObject.restype = _H
    _g32.DeleteObject.argtypes = [_H]
    _g32.DeleteDC.argtypes = [_H]
    _g32.GetDIBits.argtypes = [_H, _H, ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p,
                               ctypes.c_uint]
    _g32.GetDIBits.restype = ctypes.c_int
    _k32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    _k32.CreateMutexW.restype = ctypes.c_void_p

    class _BMIH(ctypes.Structure):
        _fields_ = [("biSize", _wt.DWORD), ("biWidth", _wt.LONG), ("biHeight", _wt.LONG),
                    ("biPlanes", _wt.WORD), ("biBitCount", _wt.WORD), ("biCompression", _wt.DWORD),
                    ("biSizeImage", _wt.DWORD), ("biXPelsPerMeter", _wt.LONG),
                    ("biYPelsPerMeter", _wt.LONG), ("biClrUsed", _wt.DWORD), ("biClrImportant", _wt.DWORD)]

    class _BLEND(ctypes.Structure):
        _fields_ = [("BlendOp", ctypes.c_ubyte), ("BlendFlags", ctypes.c_ubyte),
                    ("SourceConstantAlpha", ctypes.c_ubyte), ("AlphaFormat", ctypes.c_ubyte)]

    _g32.CreateDIBSection.argtypes = [_wt.HDC, ctypes.POINTER(_BMIH), _wt.UINT,
                                      ctypes.POINTER(ctypes.c_void_p), _wt.HANDLE, _wt.DWORD]
    _g32.CreateDIBSection.restype = _wt.HBITMAP
    _u32.UpdateLayeredWindow.argtypes = [
        _wt.HWND, _wt.HDC, ctypes.POINTER(_wt.POINT), ctypes.POINTER(_wt.SIZE), _wt.HDC,
        ctypes.POINTER(_wt.POINT), _wt.COLORREF, ctypes.POINTER(_BLEND), _wt.DWORD]
    _u32.UpdateLayeredWindow.restype = _wt.BOOL
    _GetWL = getattr(_u32, "GetWindowLongPtrW", None) or _u32.GetWindowLongW
    _SetWL = getattr(_u32, "SetWindowLongPtrW", None) or _u32.SetWindowLongW
    _GetWL.argtypes = [_wt.HWND, ctypes.c_int]
    _GetWL.restype = ctypes.c_ssize_t
    _SetWL.argtypes = [_wt.HWND, ctypes.c_int, ctypes.c_ssize_t]
    _SetWL.restype = ctypes.c_ssize_t

    def find_roblox_window():
        """The Roblox game window (its title is exactly "Roblox"), or None."""
        found = []
        me = os.getpid()

        def each(hwnd, _):
            try:
                if not _u32.IsWindowVisible(hwnd):
                    return True
                buf = ctypes.create_unicode_buffer(64)
                _u32.GetWindowTextW(hwnd, buf, 64)
                if buf.value != "Roblox":
                    return True
                pid = _wt.DWORD()
                _u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                if pid.value != me:
                    found.append(hwnd)
                    return False
            except Exception:
                pass
            return True

        _u32.EnumWindows(_ENUM(each), 0)
        return found[0] if found else None

    def window_ok(hwnd):
        return bool(hwnd) and bool(_u32.IsWindow(hwnd)) and not _u32.IsIconic(hwnd)

    def client_rect_on_screen(hwnd):
        """(left, top, width, height) of the game area on the screen."""
        rect = _wt.RECT()
        if not _u32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        pt = _wt.POINT(0, 0)
        _u32.ClientToScreen(hwnd, ctypes.byref(pt))
        return pt.x, pt.y, rect.right - rect.left, rect.bottom - rect.top

    def capture_window(hwnd):
        """The game area as an H x W x 3 RGB array, or None."""
        if not window_ok(hwnd):
            return None
        rect = _wt.RECT()
        if not _u32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        w, h = rect.right - rect.left, rect.bottom - rect.top
        if w < 200 or h < 200 or w > 16000 or h > 16000:
            return None
        win_dc = _u32.GetDC(hwnd)
        if not win_dc:
            return None
        mem_dc = bmp = old = None
        try:
            mem_dc = _g32.CreateCompatibleDC(win_dc)
            bmp = _g32.CreateCompatibleBitmap(win_dc, w, h)
            if not mem_dc or not bmp:
                return None
            old = _g32.SelectObject(mem_dc, bmp)
            ok = _u32.PrintWindow(hwnd, mem_dc, 1 | 2)
            _g32.SelectObject(mem_dc, old)
            old = None
            if not ok:
                return None
            head = _BMIH()
            head.biSize = ctypes.sizeof(_BMIH)
            head.biWidth, head.biHeight = w, -h
            head.biPlanes, head.biBitCount, head.biCompression = 1, 32, 0
            buf = np.empty((h, w, 4), np.uint8)
            got = _g32.GetDIBits(mem_dc, bmp, 0, h, buf.ctypes.data_as(ctypes.c_void_p),
                                 ctypes.byref(head), 0)
            if got != h:
                return None
            return buf[:, :, 2::-1]
        finally:
            if old and mem_dc:
                _g32.SelectObject(mem_dc, old)
            if bmp:
                _g32.DeleteObject(bmp)
            if mem_dc:
                _g32.DeleteDC(mem_dc)
            _u32.ReleaseDC(hwnd, win_dc)

    def roblox_in_front():
        try:
            fg = _u32.GetForegroundWindow()
            if not fg:
                return None
            pid = _wt.DWORD()
            _u32.GetWindowThreadProcessId(fg, ctypes.byref(pid))
            if pid.value == os.getpid():
                return None
            buf = ctypes.create_unicode_buffer(64)
            _u32.GetWindowTextW(fg, buf, 64)
            return buf.value == "Roblox"
        except Exception:
            return None

    def already_running():
        already_running.handle = _k32.CreateMutexW(None, 0, "DamageCounter_single_instance")
        return ctypes.get_last_error() == 183

    def message_box(text):
        ctypes.windll.user32.MessageBoxW(None, text, "Damage Counter", 0x40 | 0x40000)

    def window_handle(root):
        try:
            h = int(root.wm_frame(), 16)
            if h:
                return h
        except Exception:
            pass
        return _u32.GetParent(root.winfo_id()) or root.winfo_id()

    def set_layered(hwnd, on):
        st = _GetWL(hwnd, -20)
        _SetWL(hwnd, -20, (st | 0x80000) if on else (st & ~0x80000))

    def draw_smooth(hwnd, img, x, y):
        """Show an RGBA picture as the window, soft edges and shadow included."""
        w, h = img.size
        a = np.asarray(img, dtype=np.uint16)
        alpha = a[..., 3:4]
        rgb = (a[..., :3] * alpha + 127) // 255
        bgra = np.ascontiguousarray(np.concatenate([rgb[..., ::-1], alpha], axis=2).astype(np.uint8))
        screen = _u32.GetDC(None)
        mem = _g32.CreateCompatibleDC(screen)
        bmi = _BMIH()
        bmi.biSize = ctypes.sizeof(_BMIH)
        bmi.biWidth, bmi.biHeight, bmi.biPlanes, bmi.biBitCount = w, -h, 1, 32
        bits = ctypes.c_void_p()
        bmp = _g32.CreateDIBSection(screen, ctypes.byref(bmi), 0, ctypes.byref(bits), None, 0)
        ok = False
        if bmp and bits.value:
            ctypes.memmove(bits.value, bgra.ctypes.data, w * h * 4)
            old = _g32.SelectObject(mem, bmp)
            blend = _BLEND(0, 0, 255, 1)
            ok = bool(_u32.UpdateLayeredWindow(
                hwnd, screen, ctypes.byref(_wt.POINT(int(x), int(y))), ctypes.byref(_wt.SIZE(w, h)),
                mem, ctypes.byref(_wt.POINT(0, 0)), 0, ctypes.byref(blend), 2))
            _g32.SelectObject(mem, old)
            _g32.DeleteObject(bmp)
        _g32.DeleteDC(mem)
        _u32.ReleaseDC(None, screen)
        return ok

    def timer_res(on):
        try:
            winmm = ctypes.WinDLL("winmm")
            (winmm.timeBeginPeriod if on else winmm.timeEndPeriod)(1)
        except Exception:
            pass
else:
    def find_roblox_window():
        return None

    def window_ok(hwnd):
        return False

    def client_rect_on_screen(hwnd):
        return None

    def capture_window(hwnd):
        return None

    def roblox_in_front():
        return None

    def already_running():
        return False

    def message_box(text):
        print(text)

    def window_handle(root):
        return None

    def set_layered(hwnd, on):
        raise OSError("Windows only")

    def draw_smooth(hwnd, img, x, y):
        return False

    def timer_res(on):
        pass
