"""
The damage counter's panel, drawn like Creatures of Sonaria's own currency panels
(the long slate widget the tikits and mushrooms sit on).

Measured pixel by pixel from the game at 1440p, where the panel is 383 x 113 px:
  - outline: a long slab with cut corners, edges very slightly uneven
  - a darker frame ~6px wide all round, itself shading from dark at the top to
    lighter at the bottom
  - the face inside it, shading from dark slate at the top to light slate at the bottom
  - a soft shadow underneath
The game's tikit/mushroom icon and the engraving in the top-right corner are left out:
the counter's own icon sits in the left slot instead, with the total beside it.

Everything is drawn 4x bigger and shrunk, like TickTracker's badge, so edges are smooth.
"""
from __future__ import annotations

import math
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_PATH = os.path.join(HERE, "SourceSans3-Bold.ttf")
FONT_SCALE = 1.12             # same as TickTracker: Source Sans digits run a little short
STROKE = 0.06                 # dark outline round the number, as a share of the font size

# ---- shape, in units of the panel's height (113 px at 1440p) -------------------------
REF_H = 113.0
ASPECT = 383.0 / REF_H        # width / height
# cut corners (across, down) in game pixels at 1440p
CUT_TL = (13.0, 14.0)
CUT_TR = (10.0, 15.0)
CUT_BR = (10.0, 11.0)
CUT_BL = (11.0, 11.0)
FRAME = 6.5                   # frame width, game pixels at 1440p

# ---- colours, measured from the game ------------------------------------------------
FRAME_TOP = (36, 42, 52)
FRAME_LOW = (77, 83, 92)
FACE_TOP = (49, 56, 68)
FACE_LOW = (96, 103, 115)
OUTLINE = (25, 27, 39)        # outline round the number (TickTracker's COS_OUTLINE)
WHITE = (255, 255, 255)
RIM_LIFT = 22                 # optional lighter rim inside the frame (TickTracker-style)

SS = 4                        # supersampling


def _outline(w, h, s):
    """Outer edge of the panel as a polygon, w x h in drawing pixels, s = px per game px.
    The straight runs get a very slight wobble like the game's hand-drawn edges."""
    tl, tr, br, bl = [(a * s, b * s) for a, b in (CUT_TL, CUT_TR, CUT_BR, CUT_BL)]
    corners = [(0, tl[1]), (tl[0], 0), (w - tr[0], 0), (w, tr[1]),
               (w, h - br[1]), (w - br[0], h), (bl[0], h), (0, h - bl[1])]
    pts = []
    amp = 0.45 * s            # under half a game pixel either way, as measured
    for i in range(8):
        (x0, y0), (x1, y1) = corners[i], corners[(i + 1) % 8]
        n = max(2, int(math.hypot(x1 - x0, y1 - y0) / (6 * s)))
        nx, ny = (y1 - y0), -(x1 - x0)
        ln = math.hypot(nx, ny) or 1.0
        nx, ny = nx / ln, ny / ln
        long_side = i in (1, 3, 5, 7)
        for k in range(n):
            u = k / n
            off = 0.0
            if long_side and 0 < k:
                off = amp * (math.sin(2 * math.pi * (1.3 * u + 0.17 * i)) * 0.6
                             + math.sin(2 * math.pi * (3.7 * u + 0.41 * i)) * 0.4) * math.sin(math.pi * u)
            pts.append((x0 + (x1 - x0) * u + nx * off, y0 + (y1 - y0) * u + ny * off))
    return pts


def _inset(poly, d):
    """Shrink a convex polygon by d (offset every edge inwards, intersect neighbours)."""
    n = len(poly)
    lines = []
    for i in range(n):
        (x0, y0), (x1, y1) = poly[i], poly[(i + 1) % n]
        ex, ey = x1 - x0, y1 - y0
        ln = math.hypot(ex, ey)
        if ln < 1e-6:
            continue
        nx, ny = ey / ln, -ex / ln          # outward normal for a clockwise-on-screen polygon
        lines.append((x0 - nx * d, y0 - ny * d, ex, ey))
    out = []
    m = len(lines)
    for i in range(m):
        ax, ay, adx, ady = lines[i - 1]
        bx, by, bdx, bdy = lines[i]
        den = adx * bdy - ady * bdx
        if abs(den) < 1e-9:
            out.append((bx, by))
            continue
        t = ((bx - ax) * bdy - (by - ay) * bdx) / den
        out.append((ax + adx * t, ay + ady * t))
    return out


def _vgrad(h_px, top, low, y_top, y_low, w_px):
    """An h x w x 3 vertical gradient, top colour at row y_top, low colour at y_low."""
    y = np.arange(h_px, dtype=np.float32)[:, None]
    u = np.clip((y - y_top) / max(1.0, (y_low - y_top)), 0.0, 1.0)
    g = np.empty((h_px, 1, 3), np.float32)
    for i in range(3):
        g[:, :, i] = top[i] + (low[i] - top[i]) * u
    return np.repeat(g, w_px, axis=1)


_font_cache = {}


def _font(px):
    px = max(6, int(px * FONT_SCALE))
    if px not in _font_cache:
        try:
            _font_cache[px] = ImageFont.truetype(FONT_PATH, px)
        except Exception:
            _font_cache[px] = ImageFont.load_default()
    return _font_cache[px]


_body_cache = {}


def _body(height, rim):
    """The empty panel (shadow, frame, face) at SS x size, cached per size."""
    key = (height, rim)
    hit = _body_cache.get(key)
    if hit is not None:
        return hit
    if len(_body_cache) > 8:
        _body_cache.clear()
    s = height / REF_H * SS                   # drawing px per game px
    h = height * SS
    w = int(round(ASPECT * h))
    pad = int(round(10 * s))                  # room for the shadow
    W, H = w + 2 * pad, h + 2 * pad
    outer = [(x + pad, y + pad) for x, y in _outline(w, h, s)]
    inner = _inset(outer, FRAME * s)

    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    # soft shadow, a little below the panel (the game darkens what's under it by ~25%)
    sh = Image.new("L", (W, H), 0)
    ImageDraw.Draw(sh).polygon([(x, y + 2.5 * s) for x, y in outer], fill=105)
    sh = sh.filter(ImageFilter.GaussianBlur(3.5 * s))
    img.paste(Image.new("RGBA", (W, H), (0, 0, 0, 255)), (0, 0), sh)

    top_y = pad
    frame = _vgrad(H, FRAME_TOP, FRAME_LOW, top_y + 3 * s, top_y + 109 * s, W)
    face = _vgrad(H, FACE_TOP, FACE_LOW, top_y + 7 * s, top_y + 105 * s, W)
    if rim:
        # TickTracker's uneven lighter stroke, just inside the frame
        rm = Image.new("L", (W, H), 0)
        d = ImageDraw.Draw(rm)
        d.polygon(inner, fill=255)
        d.polygon(_inset(inner, 3.0 * s), fill=0)
        band = np.asarray(rm.filter(ImageFilter.GaussianBlur(0.6 * s)), np.float32) / 255.0
        yy = np.arange(H, dtype=np.float32)[:, None]
        xx = np.arange(W, dtype=np.float32)[None, :]
        lumpy = 0.75 + 0.25 * np.sin(xx / (23 * s) + 1.3) * np.sin(yy / (9 * s) + 0.4)
        lift = RIM_LIFT * (0.55 + 0.45 * np.clip((yy - top_y) / h, 0, 1)) * lumpy
        face = face + (band * lift)[..., None]
    lay_rgb = frame.copy()
    fm = Image.new("L", (W, H), 0)
    ImageDraw.Draw(fm).polygon(inner, fill=255)
    fm = np.asarray(fm.filter(ImageFilter.GaussianBlur(0.5 * s)), np.float32)[..., None] / 255.0
    lay_rgb = lay_rgb * (1 - fm) + face * fm
    om = Image.new("L", (W, H), 0)
    ImageDraw.Draw(om).polygon(outer, fill=255)
    lay = np.dstack([np.clip(lay_rgb, 0, 255), np.asarray(om, np.float32)]).astype(np.uint8)
    img.alpha_composite(Image.fromarray(lay, "RGBA"))
    hit = _body_cache[key] = (img, dict(s=s, pad=pad, w=w, h=h))
    return hit


def _number(img, x, cy, text, fpx):
    f = _font(fpx)
    sw = max(SS * 2, int(round(fpx * STROKE)))
    d = ImageDraw.Draw(img)
    d.text((x, cy), text, font=f, anchor="lm", fill=WHITE + (255,), stroke_width=sw,
           stroke_fill=OUTLINE + (255,))


_icon_cache = {}


def _icon(path, px):
    key = (path, px)
    if key not in _icon_cache:
        try:
            im = Image.open(path).convert("RGBA")
            bb = im.getbbox() or (0, 0, im.width, im.height)
            im = im.crop(bb)
            k = px / max(im.width, im.height)
            _icon_cache[key] = im.resize((max(1, int(im.width * k)), max(1, int(im.height * k))), Image.LANCZOS)
        except Exception:
            _icon_cache[key] = None
    return _icon_cache[key]


def render_panel(height, text=None, icon_path=None, rim=True):
    """
    The counter at 'height' screen pixels tall (the game's own panel is 113 px at 1440p).
    text = the total to show (digits only, no commas) or None out of combat.
    Returns an RGBA image, shadow included, ready for a see-through window.
    """
    body, g = _body(int(height), rim)
    img = body.copy()
    s, pad, h = g["s"], g["pad"], g["h"]
    cy = pad + 56.5 * s                       # middle of the face
    slot_cx = pad + 62 * s                    # middle of the icon slot
    if icon_path:
        ic = _icon(icon_path, int(92 * s))
        if ic is not None:
            img.alpha_composite(ic, (int(slot_cx - ic.width / 2), int(cy - ic.height / 2)))
    if text is not None:
        fpx = 68 * s                          # digits ~50 game px tall, like the tikit count
        x = pad + 124 * s
        room = pad + g["w"] - 16 * s - x
        f = _font(fpx)
        tw = ImageDraw.Draw(img).textlength(text, font=f)
        if tw > room:                         # very long totals shrink to fit
            fpx *= room / tw
        _number(img, x, cy + 1.5 * s, text, fpx)
    W, H = img.size
    return img.resize((W // SS, H // SS), Image.LANCZOS)


def default_height(screen_h):
    """The game's panel is 113 px tall at 1440p and scales with the screen."""
    try:
        return int(max(40, min(260, round(REF_H * screen_h / 1440))))
    except Exception:
        return int(REF_H)
