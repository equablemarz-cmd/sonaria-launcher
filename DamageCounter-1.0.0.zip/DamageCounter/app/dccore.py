"""
Damage Counter - the part that reads the game.

Given a picture of the Roblox game area, it:
  1. checks for CoS's combat timer (the round top-right button turning red with a
     white 'NNs' countdown),
  2. finds the upright bright-red damage numbers you deal (the slanted dark-red ones
     are damage you take, green ones are heals - both are left out),
  3. reads them with digit pictures taken from real CoS fights,
  4. counts each number once, and adds it to the total for the current fight.

It only looks at pictures. Nothing here touches Roblox.
Only numpy and OpenCV are needed, so it can all be tested without Windows.
"""
from __future__ import annotations

import collections
import os

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DIGITS_PATH = os.path.join(HERE, "digits.npz")

# Everything below is tuned on the game area at 1028 px tall (a maximised 1440p
# window, scaled to 75%). Pictures are scaled to that height before reading.
WORK_H = 1028
GH = 28                       # digit pictures are compared at this height


# --------------------------------------------------------------------------
# Combat timer
# --------------------------------------------------------------------------
def find_combat(img):
    """True while the round button in the top-right is the red combat countdown."""
    H, W = img.shape[:2]
    x0 = int(W * 0.86)
    reg = img[: int(H * 0.42), x0:]
    r, g, b = (reg[..., i].astype(np.int16) for i in range(3))
    red = ((r > 110) & (g < 58) & (r - g > 80) & (r - b > 45)).astype(np.uint8)
    if red.sum() < 0.0004 * H * H:
        return False
    k = max(3, int(H * 0.012)) | 1
    m = cv2.morphologyEx(red, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
    n, _, st, _ = cv2.connectedComponentsWithStats(m)
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if not (0.035 * H <= h <= 0.13 * H and 0.7 <= w / h <= 1.45) or a < 0.5 * w * h:
            continue
        box = reg[y:y + h, x:x + w].astype(np.int16)
        white = ((box[..., 0] > 205) & (box[..., 1] > 205) & (box[..., 2] > 205)).mean()
        dark = ((box[..., 0] < 70) & (box[..., 1] < 70) & (box[..., 2] < 80)).mean()
        if white >= 0.04 and dark >= 0.02:
            return True
    return False


class CombatState:
    """Smooths the combat check: in after 2 sightings in a row, out after OUT_AFTER
    seconds without one (the button can be hidden for a moment by effects)."""
    OUT_AFTER = 2.5

    def __init__(self):
        self.on = False
        self.streak = 0
        self.last_seen = -1e9

    def update(self, t, seen):
        if seen:
            self.streak += 1
            self.last_seen = t
            if self.streak >= 2:
                self.on = True
        else:
            self.streak = 0
            if self.on and t - self.last_seen > self.OUT_AFTER:
                self.on = False
        return self.on


# --------------------------------------------------------------------------
# Finding red numbers
# --------------------------------------------------------------------------
def red_mask(a):
    r, g, b = (a[..., i].astype(np.int16) for i in range(3))
    return ((r >= 88) & (r <= 215) & (g <= 55) & (b <= 80) & (r - g >= 70) & (r >= 2 * b)).astype(np.uint8)


def in_hud(x, y, w, h, W, H):
    """Parts of the screen that are HUD, never damage numbers."""
    k = H / WORK_H
    cx, cy = x + w / 2, y + h / 2
    return ((W - cx < 420 * k and cy < 375 * k)                  # minimap, buttons, combat timer
            or (cx < 330 * k and cy < 305 * k)                   # chat
            or (H - cy < 173 * k and abs(cx - W / 2) < 360 * k)  # hotbar, health and stamina
            or (abs(cx - W / 2) < 360 * k and 35 * k < cy < 265 * k)   # red warning text
            or cy < 25 * k or H - cy < 13 * k)


def candidates(img, hmin=20, hmax=110):
    """Number-shaped groups of red blobs: (x, y, w, h, binary patch)."""
    m = red_mask(img)
    n, lab, st, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
    comps = [tuple(st[i][:4]) + (i,) for i in range(1, n)
             if 14 <= st[i][3] <= hmax and 0.2 * st[i][3] <= st[i][2] <= 4 * st[i][3]
             and st[i][4] >= 0.33 * st[i][2] * st[i][3]]
    comps.sort()
    used = [False] * len(comps)
    out = []
    H, W = img.shape[:2]
    for i, c in enumerate(comps):
        if used[i]:
            continue
        grp = [c]
        used[i] = True
        for j in range(i + 1, len(comps)):
            if used[j]:
                continue
            d, p = comps[j], grp[-1]
            if (abs(d[3] - p[3]) <= 0.25 * p[3] and abs((d[1] + d[3] / 2) - (p[1] + p[3] / 2)) <= 0.3 * p[3]
                    and -2 <= d[0] - (p[0] + p[2]) <= 0.4 * p[3]):
                grp.append(d)
                used[j] = True
        x0 = grp[0][0]
        x1 = max(q[0] + q[2] for q in grp)
        y0 = min(q[1] for q in grp)
        y1 = max(q[1] + q[3] for q in grp)
        w, h = x1 - x0, y1 - y0
        if h < hmin or not (0.85 * h <= w <= 3.4 * h) or in_hud(x0, y0, w, h, W, H):
            continue
        patch = np.isin(lab[y0:y1, x0:x1], [q[4] for q in grp]).astype(np.uint8)
        out.append((x0, y0, w, h, patch))
    return out


# --------------------------------------------------------------------------
# Reading the digits
# --------------------------------------------------------------------------
def _norm(p):
    H, W = p.shape
    w = max(4, int(round(W * GH / H)))
    return cv2.resize(p.astype(np.uint8) * 255, (w, GH), interpolation=cv2.INTER_AREA).astype(np.float32) / 255


def _dt(m):
    b = np.pad((m > 0.5).astype(np.uint8), 1)
    return cv2.distanceTransform(b, cv2.DIST_L2, 3)[1:-1, 1:-1]


class DigitReader:
    """Reads a number by fitting digit pictures (taken from real CoS hits) side by side
    across it, scoring each fit on overlap and on stroke shape."""

    def __init__(self, path=DIGITS_PATH, scales=(0.9, 1.0, 1.1)):
        z = np.load(path)
        by = collections.defaultdict(list)
        for key in z.files:
            d = key.split("_")[0]
            t = z[key].astype(np.float32) / 255
            for sc in scales:
                w = max(4, int(round(t.shape[1] * sc)))
                tt = cv2.resize(t, (w, GH), interpolation=cv2.INTER_AREA)
                by[w].append((d, tt, _dt(tt)))
        self.W = {}
        for w, lst in by.items():
            M = np.stack([x[1] for x in lst])
            Dm = np.stack([x[2] for x in lst])
            self.W[w] = ([x[0] for x in lst], M, M.sum((1, 2)), Dm, np.sqrt((Dm * Dm).sum((1, 2))))

    def read(self, patch):
        """(text, worst digit score, mean score) or None."""
        P = _norm(patch)
        W = P.shape[1]
        if W < 12 or W > 120:
            return None
        D = _dt(P)
        best = {0: (0.0, None)}
        cache = {}
        for st in range(0, W):
            if st not in best:
                continue
            for gap in ((0,) if st == 0 else range(-2, 6)):
                a = st + gap
                if a < 0 or a >= W:
                    continue
                for w, (ds, M, Ms, Dm, Dn) in self.W.items():
                    b = a + w
                    if b > W:
                        continue
                    hit = cache.get((a, w))
                    if hit is None:
                        seg = P[:, a:b]
                        mn = np.minimum(M, seg).sum((1, 2))
                        iou = mn / (Ms + seg.sum() - mn + 1e-6)
                        dseg = D[:, a:b]
                        cs = (Dm * dseg).sum((1, 2)) / (Dn * np.sqrt((dseg * dseg).sum()) + 1e-6)
                        sc = 0.5 * iou + 0.5 * cs
                        sc[iou < 0.5] = -1
                        k = int(np.argmax(sc))
                        hit = cache[(a, w)] = (float(sc[k]), ds[k])
                    if hit[0] < 0.6:
                        continue
                    val = best[st][0] + hit[0] * (b - st) - 0.15 * abs(gap)
                    if b not in best or val > best[b][0]:
                        best[b] = (val, (st, hit[1], hit[0]))
        ends = [e for e in best if e >= W - 3 and e > 0]
        if not ends:
            return None
        e = max(ends, key=lambda i: best[i][0])
        ds, sc = [], []
        while e > 0:
            st, d, v = best[e][1]
            ds.append(d)
            sc.append(v)
            e = st
        if not 2 <= len(ds) <= 4:
            return None
        return "".join(reversed(ds)), float(min(sc)), float(np.mean(sc))


# --------------------------------------------------------------------------
# Counting each hit once
# --------------------------------------------------------------------------
class HitCounter:
    """A hit number stays readable for about a second. A new hit of the same value is
    recognised when the old one has outlived that, when two are on screen together,
    or when the number suddenly pops bigger (new numbers spawn large)."""
    LIFE = 1.15
    GAP = 0.45
    CONFIRM = 3
    POP = 1.35

    def __init__(self):
        self.inst = []
        self.hits = []          # (time first seen, value)

    def feed(self, t, reads):
        """reads: [(text, centre x, centre y, height)]. Returns new hits [(t, value)]."""
        self.inst = [i for i in self.inst if t - i["last"] <= self.GAP]
        taken = set()
        new = []
        for v, x, y, h in sorted(reads, key=lambda r: r[3]):
            if v[0] == "0":
                continue
            best = None
            for k, i in enumerate(self.inst):
                if k in taken or i["v"] != v or t - i["birth"] > self.LIFE or t <= i["last"]:
                    continue
                if h > self.POP * i["h"] and t - i["birth"] > 0.25:
                    continue
                d = ((x - i["x"]) ** 2 + (y - i["y"]) ** 2) ** 0.5
                if best is None or d < best[0]:
                    best = (d, k)
            if best is None:
                self.inst.append(dict(v=v, birth=t, last=t, x=x, y=y, h=h, n=1, counted=False))
                taken.add(len(self.inst) - 1)
                continue
            i = self.inst[best[1]]
            taken.add(best[1])
            i.update(last=t, x=x, y=y, h=h)
            i["n"] += 1
            if not i["counted"] and i["n"] >= self.CONFIRM:
                i["counted"] = True
                hit = (i["birth"], int(v))
                self.hits.append(hit)
                new.append(hit)
        if len(self.hits) > 200:
            self.hits = self.hits[-100:]
        return new


# --------------------------------------------------------------------------
# All together
# --------------------------------------------------------------------------
class DamageCounter:
    """Feed it pictures of the game area with their times; read .total and .in_combat.

    The total only goes up while you are in combat, and goes back to 0 the moment
    combat ends. The first hit of a fight usually lands just before the combat timer
    shows, so hits from the last LOOKBACK seconds before combat starts are counted too.
    """
    MIN_SCORE = 0.80
    LOOKBACK = 1.5

    def __init__(self, reader=None):
        self.reader = reader or DigitReader()
        self.combat = CombatState()
        self.hits = HitCounter()
        self.total = 0
        self.in_combat = False
        self.fight_start = None
        self.last_reads = []

    @staticmethod
    def normalise(img):
        """Scale the game area to the height everything is tuned for."""
        h = img.shape[0]
        if h == WORK_H:
            return img
        k = WORK_H / h
        return cv2.resize(img, (max(1, int(round(img.shape[1] * k))), WORK_H),
                          interpolation=cv2.INTER_AREA if k < 1 else cv2.INTER_LINEAR)

    def step(self, t, img, check_combat=True):
        img = self.normalise(img)
        was = self.in_combat
        if check_combat:
            self.in_combat = self.combat.update(t, find_combat(img))
        reads = []
        for (x, y, w, h, p) in candidates(img):
            r = self.reader.read(p)
            if r and r[1] >= self.MIN_SCORE:
                reads.append((r[0], x + w // 2, y + h // 2, h))
        self.last_reads = reads
        new = self.hits.feed(t, reads)
        if self.in_combat and not was:                      # combat started
            self.fight_start = t
            self.total = sum(v for ht, v in self.hits.hits if ht >= t - self.LOOKBACK)
        elif was and not self.in_combat:                    # combat ended: back to 0
            self.total = 0
            self.fight_start = None
        elif self.in_combat:
            self.total += sum(v for ht, v in new)
        return self.total
