TICKTRACKER 4.1.3 - natural heal tick timer for Creatures of Sonaria
==================================================================
by Sonaria Software

A little round badge that sits on top of your screen and counts down to your next
natural heal tick. It reads your HEALTH bar off the screen, like you do.
It only LOOKS - it never touches Roblox.


COMBAT ALERT (new in 4.1)
  Tabbed out to another window and something attacks you? The moment the game's
  combat timer appears (the leave button in the top-right turning red with its
  countdown), the badge shows an alert icon with a pulsing yellow glow, and stays that way until you
  click back into Roblox. A connected controller gives three short buzzes too.

  It only goes off for a fight that STARTS while you're tabbed out, and only while
  another window is in front. Right-click the badge to switch it off or to test it.

  To see the game while it's hidden behind another window, TickTracker asks Windows
  for a picture of the Roblox window - the same thing OBS's window capture and
  Discord's screen share do. It can't see a minimised game, so leave Roblox open
  behind your other window rather than minimising it.


HOW TO START IT
  1. Unzip the whole TickTracker folder somewhere (Desktop, Documents, anywhere).
     Don't run it from inside the zip - it needs its files next to it.
  2. Open the folder and double-click  TickTracker.exe
  That's it. Nothing to install, no Python needed, no internet needed.
  Works on 64-bit Windows 10 and 11.

  Want it on your Desktop or taskbar with its own icon?
  Right-click the badge -> "Put a TickTracker shortcut on the Desktop".
  Then right-click that shortcut -> Show more options -> Pin to taskbar.


THE BADGE
  number       seconds until your next natural tick
  heart icon   not counting yet: no heal seen since you spawned, or it can't see
               a health bar

  drag          move it
  mouse wheel   bigger / smaller
  double-click  "I just ticked" - manual resync  (F6 does the same)
  right-click   menu: resync, reset size, combat alert on/off and test, window type,
                OBS link, debug report, files, shortcut, quit

  The badge is drawn with soft edges and a soft drop shadow, like the game's own
  buttons. If that ever looks wrong on your PC (black box, nothing showing), it
  switches itself to a plain hard-edged window - or pick it from the menu.

  While TickTracker is open, F6 belongs to it (in every app). If another program
  already uses F6, TickTracker leaves it alone - double-click the badge instead.


HOW IT WORKS
  It searches the screen for the green HEALTH bar (so it doesn't matter where the
  Roblox window is, or which monitor), then reads it 60 times a second.
  It goes by TIMING only - tick size never matters, so mud, Healing Pulse, resting
  and so on can't confuse it:
    - the first heal it sees starts the countdown straight away
    - every heal that lands on the countdown re-syncs it (and teaches it the exact
      gap between your ticks)
    - once a tick has landed on the countdown, heals that are off it (healers,
      food...) are ignored
    - until then, the newest heal restarts the countdown; press F6 right as you
      tick if it latched onto the wrong heal
  If you're in Roblox and the bar is gone for 8 seconds (menu, new creature) it
  starts fresh. If you tab out to another app, it keeps counting from the rhythm
  it learned (it can't see ticks while you're away) and picks up when you're back.


IS IT SAFE?  WHAT IT DOES AND DOESN'T DO
  - TickTracker.exe is the official Python program from python.org (pythonw.exe),
    only renamed. Right-click it -> Properties -> Digital Signatures: it is signed
    by the Python Software Foundation. The other .dll/.pyd files are official
    Python, numpy and Pillow files.
  - TickTracker itself is plain text you can open in Notepad and read:
    app\ticktracker.py and app\ttcore.py.
  - It never touches Roblox: no reading game memory, no injecting, no clicking or
    typing for you. It takes pictures of the screen and looks for the health bar,
    and while you're tabbed out, pictures of the Roblox window to look for the
    combat timer.
  - It never uses the internet. Nothing is uploaded anywhere.
  - It does not watch your keyboard. F6 uses Windows' normal hotkey system.
  - What it saves, all in one folder on your own PC (right-click the badge ->
    "Open TickTracker's files"): your settings, a log of what it did, and two
    small pictures to help fix problems - the health bar it found, and (when it
    can't find a bar while Roblox is in front) the bottom half of your screen.
    Each new picture replaces the last one. Delete that folder any time.
  - For OBS it offers a copy of the badge at http://127.0.0.1:47615/overlay.
    Only your own PC can reach that address.

  Windows or your antivirus still complains?  Some are wary of anything new from
  a zip. Check the signature as above; if Windows shows "Windows protected your
  PC", click More info -> Run anyway. If your antivirus removed a file, unzip
  again after allowing the folder.


RECORDING WITH OBS
  See OBS\HOW TO SET UP OBS.txt.


IF SOMETHING'S WRONG
  Right-click the badge -> Save debug report, and send that file (plus
  capture_no_bar.png from "Open TickTracker's files" if it can't find your health
  bar) to the Sonaria Software channel on Discord.
  If it won't start at all, a message tells you why; the same text is saved as
  startup_error.txt in %LOCALAPPDATA%\TickTracker.

  To remove TickTracker: quit it, delete this folder, and delete
  %LOCALAPPDATA%\TickTracker (paste that into File Explorer's address bar).


Font: Source Sans 3 by Adobe (SIL Open Font License). Licences for everything bundled are in
app\licenses and app\site-packages.
