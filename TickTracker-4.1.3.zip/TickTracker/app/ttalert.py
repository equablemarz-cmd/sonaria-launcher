"""
TickTracker combat alert.

While you are tabbed out of Roblox, this looks for Creatures of Sonaria's combat timer -
the top-right leave button turning red with a countdown on it - and tells the badge to
show its alert until you are back in the game.

How it looks: Roblox is usually hidden behind the window you tabbed to, so the screen
itself shows nothing useful. Instead this asks Windows for a picture of the Roblox
window, the same way OBS's window capture and Discord's screen share do. It never reads
or changes the game's memory, never sends keys or clicks, and the picture stays in this
program (one small crop is kept on this PC for the debug report, nothing is uploaded).

Only numpy is needed, so everything here can be tried without Windows (see find_combat).
"""
from __future__ import annotations

import sys
import threading
import time

import numpy as np

IS_WIN = sys.platform == "win32"

CHECK_SECONDS = 0.5           # how often the Roblox window is looked at while tabbed out
HITS_NEEDED = 2               # the combat timer must show on this many looks in a row
REGION = 0.36                 # the leave button lives in the top-right corner: this share of the window


# --------------------------------------------------------------------------
# Spotting the combat timer in a picture of the Roblox window
# --------------------------------------------------------------------------
def top_right(img):
    """The top-right corner of the window picture, where the leave button sits."""
    h, w = img.shape[:2]
    return img[: max(1, int(h * REGION)), w - max(1, int(w * REGION)):]


def find_combat(img):
    """
    True if the leave button is showing its combat state: a flat red door
    (CoS draws it in exactly one red, 244/13/52) with the white, black-outlined
    countdown over it, sitting on a slate button.

    img = the whole Roblox window as a height x width x 3 array of RGB bytes.
    Returns (found, details) - details is a short text for the log / debug report.
    """
    h, w = img.shape[:2]
    if h < 200 or w < 200:
        return False, "window too small"
    reg = top_right(img)
    r = reg[..., 0].astype(np.int16)
    g = reg[..., 1].astype(np.int16)
    b = reg[..., 2].astype(np.int16)
    red = (r > 205) & (g < 55) & (b > 15) & (b < 95)
    total = int(red.sum())
    if total < 40:
        return False, f"no red ({total}px)"

    # Group the red into blobs on a coarse grid and keep the biggest one, so a stray
    # red pixel somewhere else in the corner can't stretch the box.
    cell = max(4, h // 160)
    gh, gw = red.shape[0] // cell, red.shape[1] // cell
    if gh < 2 or gw < 2:
        return False, "corner too small"
    grid = red[: gh * cell, : gw * cell].reshape(gh, cell, gw, cell).sum(axis=(1, 3))
    filled = grid >= max(2, cell * cell // 8)
    seen = np.zeros_like(filled)
    best, best_px = None, 0
    for sy, sx in zip(*np.nonzero(filled)):
        if seen[sy, sx]:
            continue
        stack, cells, px = [(sy, sx)], [], 0
        seen[sy, sx] = True
        while stack:
            y, x = stack.pop()
            cells.append((y, x))
            px += int(grid[y, x])
            for ny, nx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1),
                           (y - 1, x - 1), (y - 1, x + 1), (y + 1, x - 1), (y + 1, x + 1)):
                if 0 <= ny < gh and 0 <= nx < gw and filled[ny, nx] and not seen[ny, nx]:
                    seen[ny, nx] = True
                    stack.append((ny, nx))
        if px > best_px:
            best, best_px = cells, px
    if best is None:
        return False, "red is scattered"
    ys = [c[0] for c in best]
    xs = [c[1] for c in best]
    cy0, cy1, cx0, cx1 = min(ys), max(ys), min(xs), max(xs)
    # The countdown is drawn across the middle of the door, which can cut its red into a
    # top piece and a bottom piece. Take in any red directly above or below the biggest piece.
    reach = int(np.ceil(1.3 * (cx1 - cx0 + 1)))
    ya, yb = max(0, cy0 - reach), min(gh, cy1 + reach + 1)
    xa, xb = max(0, cx0 - 1), min(gw, cx1 + 2)
    near_y, near_x = np.nonzero(filled[ya:yb, xa:xb])
    if len(near_y):
        cy0, cy1 = min(cy0, ya + int(near_y.min())), max(cy1, ya + int(near_y.max()))
        cx0, cx1 = min(cx0, xa + int(near_x.min())), max(cx1, xa + int(near_x.max()))
    y0, y1 = cy0 * cell, (cy1 + 1) * cell
    x0, x1 = cx0 * cell, (cx1 + 1) * cell
    bh, bw = y1 - y0, x1 - x0
    box_red = red[y0:y1, x0:x1]
    n_red = int(box_red.sum())
    info = f"red blob {bw}x{bh}px at {x0},{y0} of corner, {n_red}px red"

    # the door is a little taller than wide and a few percent of the window's height
    if not 0.012 * h <= bh <= 0.14 * h:
        return False, info + " - wrong size"
    if not 0.35 <= bw / bh <= 1.25:
        return False, info + " - wrong shape"
    if n_red < 0.12 * bw * bh:
        return False, info + " - too thin"

    # the countdown sits on top of it: pure white digits with a near-black outline
    rr, gg, bb = r[y0:y1, x0:x1], g[y0:y1, x0:x1], b[y0:y1, x0:x1]
    white = (rr > 225) & (gg > 225) & (bb > 225)
    black = (rr < 50) & (gg < 50) & (bb < 55)
    if white.sum() < 0.05 * bw * bh or black.sum() < 0.04 * bw * bh:
        return False, info + " - no countdown on it"

    # and it is on a slate button, not something red out in the world
    py, px_ = bh // 2, bw
    Y0, Y1 = max(0, y0 - py), min(reg.shape[0], y1 + py)
    X0, X1 = max(0, x0 - px_), min(reg.shape[1], x1 + px_)
    R2, G2, B2 = r[Y0:Y1, X0:X1], g[Y0:Y1, X0:X1], b[Y0:Y1, X0:X1]
    slate = (np.abs(R2 - G2) < 22) & (B2 - G2 > 2) & (B2 - G2 < 30) & (G2 > 40) & (G2 < 125)
    if slate.mean() < 0.12:
        return False, info + " - not on a button"
    return True, info + " - combat timer"


# --------------------------------------------------------------------------
# Windows: finding the Roblox window and taking its picture
# --------------------------------------------------------------------------
if IS_WIN:
    import ctypes
    import os
    from ctypes import wintypes

    _u32 = ctypes.WinDLL("user32", use_last_error=True)
    _g32 = ctypes.WinDLL("gdi32", use_last_error=True)
    _H = ctypes.c_void_p

    _ENUM = ctypes.WINFUNCTYPE(wintypes.BOOL, _H, wintypes.LPARAM)
    _u32.EnumWindows.argtypes = [_ENUM, wintypes.LPARAM]
    _u32.EnumWindows.restype = wintypes.BOOL
    _u32.IsWindowVisible.argtypes = [_H]
    _u32.IsWindowVisible.restype = wintypes.BOOL
    _u32.IsIconic.argtypes = [_H]
    _u32.IsIconic.restype = wintypes.BOOL
    _u32.GetWindowTextW.argtypes = [_H, ctypes.c_wchar_p, ctypes.c_int]
    _u32.GetWindowTextW.restype = ctypes.c_int
    _u32.GetWindowThreadProcessId.argtypes = [_H, ctypes.POINTER(wintypes.DWORD)]
    _u32.GetWindowThreadProcessId.restype = wintypes.DWORD
    _u32.GetClientRect.argtypes = [_H, ctypes.POINTER(wintypes.RECT)]
    _u32.GetClientRect.restype = wintypes.BOOL
    _u32.GetDC.argtypes = [_H]
    _u32.GetDC.restype = _H
    _u32.ReleaseDC.argtypes = [_H, _H]
    _u32.ReleaseDC.restype = ctypes.c_int
    _u32.PrintWindow.argtypes = [_H, _H, ctypes.c_uint]
    _u32.PrintWindow.restype = wintypes.BOOL
    _g32.CreateCompatibleDC.argtypes = [_H]
    _g32.CreateCompatibleDC.restype = _H
    _g32.CreateCompatibleBitmap.argtypes = [_H, ctypes.c_int, ctypes.c_int]
    _g32.CreateCompatibleBitmap.restype = _H
    _g32.SelectObject.argtypes = [_H, _H]
    _g32.SelectObject.restype = _H
    _g32.DeleteObject.argtypes = [_H]
    _g32.DeleteObject.restype = wintypes.BOOL
    _g32.DeleteDC.argtypes = [_H]
    _g32.DeleteDC.restype = wintypes.BOOL
    _g32.GetDIBits.argtypes = [_H, _H, ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p,
                               ctypes.c_uint]
    _g32.GetDIBits.restype = ctypes.c_int

    class _BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
                    ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD),
                    ("biCompression", wintypes.DWORD), ("biSizeImage", wintypes.DWORD),
                    ("biXPelsPerMeter", wintypes.LONG), ("biYPelsPerMeter", wintypes.LONG),
                    ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD)]

    def find_roblox_window():
        """The Roblox game window (its title is exactly "Roblox"), or None. Only the
        window's title and whether it is visible are read."""
        found = []
        me = os.getpid()

        def each(hwnd, _):
            try:
                if not _u32.IsWindowVisible(hwnd):
                    return True
                buf = ctypes.create_unicode_buffer(64)
                _u32.GetWindowTextW(hwnd, buf, 64)
                if buf.value != "Roblox":
                    return True
                pid = wintypes.DWORD()
                _u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                if pid.value != me:
                    found.append(hwnd)
                    return False                  # first match is enough
            except Exception:
                pass
            return True

        _u32.EnumWindows(_ENUM(each), 0)
        return found[0] if found else None

    def capture_window(hwnd):
        """
        A picture of the window's contents as a height x width x 3 RGB array, even when
        another window covers it. None if it can't be taken (minimised, closed, or this
        PC returns nothing for it).
        """
        if not hwnd or _u32.IsIconic(hwnd):
            return None
        rect = wintypes.RECT()
        if not _u32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        w, h = rect.right - rect.left, rect.bottom - rect.top
        if w < 200 or h < 200 or w > 16000 or h > 16000:
            return None
        win_dc = _u32.GetDC(hwnd)
        if not win_dc:
            return None
        mem_dc = bmp = old = None
        try:
            mem_dc = _g32.CreateCompatibleDC(win_dc)
            bmp = _g32.CreateCompatibleBitmap(win_dc, w, h)
            if not mem_dc or not bmp:
                return None
            old = _g32.SelectObject(mem_dc, bmp)
            # 1 = just the game area, 2 = ask the window manager for the real rendered contents
            ok = _u32.PrintWindow(hwnd, mem_dc, 1 | 2)
            _g32.SelectObject(mem_dc, old)        # a bitmap must be out of the DC to be read
            old = None
            if not ok:
                return None
            head = _BITMAPINFOHEADER()
            head.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
            head.biWidth, head.biHeight = w, -h   # negative height = rows run top to bottom
            head.biPlanes, head.biBitCount, head.biCompression = 1, 32, 0
            buf = np.empty((h, w, 4), np.uint8)
            got = _g32.GetDIBits(mem_dc, bmp, 0, h, buf.ctypes.data_as(ctypes.c_void_p),
                                 ctypes.byref(head), 0)
            if got != h:
                return None
            return buf[:, :, 2::-1]               # Windows hands back blue-green-red: flip to RGB
        finally:
            if old and mem_dc:
                _g32.SelectObject(mem_dc, old)
            if bmp:
                _g32.DeleteObject(bmp)
            if mem_dc:
                _g32.DeleteDC(mem_dc)
            _u32.ReleaseDC(hwnd, win_dc)

    class _XINPUT_VIBRATION(ctypes.Structure):
        _fields_ = [("wLeftMotorSpeed", ctypes.c_ushort), ("wRightMotorSpeed", ctypes.c_ushort)]

    _xinput = None
    for _name in ("xinput1_4", "xinput1_3", "xinput9_1_0"):
        try:
            _xinput = ctypes.WinDLL(_name)
            _xinput.XInputSetState.argtypes = [ctypes.c_uint, ctypes.POINTER(_XINPUT_VIBRATION)]
            _xinput.XInputSetState.restype = ctypes.c_uint
            break
        except Exception:
            _xinput = None

    def _rumble_all(strength):
        """Sets the rumble on every connected Xbox-style controller. Returns how many answered."""
        if _xinput is None:
            return 0
        n = 0
        for pad in range(4):
            v = _XINPUT_VIBRATION(int(65535 * strength), int(65535 * strength))
            if _xinput.XInputSetState(pad, ctypes.byref(v)) == 0:
                n += 1
        return n
else:
    def find_roblox_window():
        return None

    def capture_window(hwnd):
        return None

    def _rumble_all(strength):
        return 0


def rumble(pulses=3, on=0.22, off=0.16):
    """Three short buzzes on any connected controller, on its own thread. Does nothing
    if there is no controller. The motors are always switched back off."""
    def run():
        try:
            for _ in range(pulses):
                if _rumble_all(0.9) == 0:
                    return
                time.sleep(on)
                _rumble_all(0.0)
                time.sleep(off)
        except Exception:
            pass
        finally:
            try:
                _rumble_all(0.0)
            except Exception:
                pass
    threading.Thread(target=run, daemon=True).start()


# --------------------------------------------------------------------------
# The watcher: its own thread, so it can never hold up the health bar reading
# --------------------------------------------------------------------------
class CombatWatcher(threading.Thread):
    """
    is_away()   -> True while another app is in front of Roblox
    is_enabled() -> the menu switch
    log(text)   -> TickTracker's log
    """

    def __init__(self, is_away, is_enabled, log=lambda text: None):
        super().__init__(daemon=True)
        self.is_away, self.is_enabled, self.log = is_away, is_enabled, log
        self.stop = False
        self.alerting = False          # combat started while tabbed out; cleared when you're back in Roblox
        self.test_until = 0.0
        self.status = "waiting for you to tab out"
        self.detail = ""
        self.last_corner = None        # the last corner picture looked at, for the debug report
        self.captures = 0
        self._hits = 0
        self._seen_calm = False        # the timer has been seen NOT showing since you tabbed out
        self._said = set()

    def active(self):
        """True while the badge should be showing the alert."""
        return self.alerting or time.monotonic() < self.test_until

    def test(self, seconds=5.0):
        self.test_until = time.monotonic() + seconds
        rumble()

    def _once(self, text):
        if text not in self._said:
            self._said.add(text)
            self.log(text)

    def run(self):
        while not self.stop:
            time.sleep(CHECK_SECONDS)
            try:
                self.step()
            except Exception as e:
                self.status = f"error: {e!r}"
                self._once(f"combat alert problem: {e!r}")

    def step(self):
        if not self.is_enabled():
            self.alerting = False
            self._hits, self._seen_calm = 0, False
            self.status = "switched off in the menu"
            return
        if not self.is_away():
            if self.alerting:
                self.log("combat alert cleared - you're back in Roblox")
            self.alerting = False
            self._hits, self._seen_calm = 0, False
            self.status = "waiting for you to tab out"
            return
        if self.alerting:
            return                      # it stays on until you're back; nothing more to look for
        hwnd = find_roblox_window()
        if not hwnd:
            self.status = "tabbed out, but no Roblox window is open"
            return
        img = capture_window(hwnd)
        if img is None:
            self.status = "tabbed out, but Roblox can't be pictured (minimised?)"
            return
        corner = top_right(img)
        if int(corner.max()) < 12:
            self.status = "tabbed out, but Windows gives a blank picture of Roblox"
            self._once("combat alert: Windows returned a blank picture of the Roblox window on this PC")
            return
        self.captures += 1
        self._once(f"combat alert: picturing the Roblox window works ({img.shape[1]}x{img.shape[0]})")
        found, self.detail = find_combat(img)
        self.last_corner = corner.copy()
        if not found:
            self._hits = 0
            self._seen_calm = True
            self.status = "tabbed out, watching for the combat timer"
            return
        if not self._seen_calm:
            # already fighting when you tabbed out: you know. Wait for it to end first.
            self.status = "tabbed out during a fight - will alert on the next one"
            return
        self._hits += 1
        if self._hits >= HITS_NEEDED:
            self.alerting = True
            self.status = "ALERT: combat started while you were tabbed out"
            self.log(f"combat alert: {self.detail}")
            rumble()

    def report(self):
        return (f"Combat alert: {self.status}\n"
                f"  last look: {self.detail or 'none yet'}\n"
                f"  pictures taken of the Roblox window: {self.captures}")
