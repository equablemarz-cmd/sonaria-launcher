"""
TickTracker start-up file.

TickTracker.exe (one folder up) is the official Python program from python.org -
"pythonw.exe", renamed and otherwise untouched, still carrying the Python Software
Foundation's digital signature. Python looks for a file with this name every time it
starts. When TickTracker.exe is opened on its own (double-click, shortcut, taskbar),
this file starts the TickTracker app, which is the plain readable code next to it:
ticktracker.py and ttcore.py.

Nothing here downloads, installs or changes anything on the PC.
"""
import os
import sys


HERE = os.path.dirname(os.path.abspath(__file__))


def _setup():
    """True if this is TickTracker.exe - the Python program sitting one folder up from
    here, whatever it has been renamed to - and not some other Python on the PC that
    happened to pick this file up."""
    try:
        exe_dir = os.path.normcase(os.path.dirname(os.path.abspath(sys.executable)))
        if exe_dir != os.path.normcase(os.path.dirname(HERE)):
            return False
    except Exception:
        return False
    sys._tt_packaged = True               # ticktracker.py reads this (settings go in AppData)
    sys.dont_write_bytecode = True        # don't scatter __pycache__ folders through the app
    # the window toolkit's own files travel in this folder; point it at them, so a
    # different copy installed on the PC can never get mixed in
    tcl = os.path.join(HERE, "tcl")
    if os.path.isdir(os.path.join(tcl, "tcl8.6")):
        os.environ["TCL_LIBRARY"] = os.path.join(tcl, "tcl8.6")
        os.environ["TK_LIBRARY"] = os.path.join(tcl, "tk8.6")
    return True


def _tell(text):
    """Start-up failed before the app could say so itself: say it here and keep a copy."""
    try:
        folder = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TickTracker")
        os.makedirs(folder, exist_ok=True)
        with open(os.path.join(folder, "startup_error.txt"), "w", encoding="utf-8") as f:
            f.write(text)
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, text[-1500:], "TickTracker", 0x10 | 0x40000)
    except Exception:
        pass


def _start():
    code = 0
    try:
        sys.argv[:] = [os.path.join(HERE, "ticktracker.py")]
        import ticktracker
        ticktracker.main()
    except SystemExit as e:
        code = e.code if isinstance(e.code, int) else 0
    except BaseException:
        import traceback
        code = 1
        _tell("TickTracker couldn't start.\n\n"
              "Things to try:\n"
              " - unzip the WHOLE TickTracker folder first (don't run it from inside the zip)\n"
              " - keep TickTracker.exe together with the files and the 'app' folder it came with\n"
              " - it needs 64-bit Windows 10 or 11\n\n" + traceback.format_exc())
    # The app has finished (Quit was chosen). Close down here rather than handing back
    # to Python, which would otherwise sit waiting for typed commands.
    try:
        import atexit
        atexit._run_exitfuncs()
    except Exception:
        pass
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.flush()
        except Exception:
            pass
    os._exit(code)


# Opened with nothing after the exe's name (double-click, shortcut, taskbar)? Start the app.
# (If a script was named, Python simply runs that instead.)
if _setup() and len(getattr(sys, "orig_argv", sys.argv)) <= 1:
    _start()
