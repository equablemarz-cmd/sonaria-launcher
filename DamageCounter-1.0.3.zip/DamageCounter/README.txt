DAMAGE COUNTER 1.0.3 - Creatures of Sonaria
=========================================
by Sonaria Software

A panel drawn like CoS's own currency panels that adds up the damage you deal in the
current fight.

  - It only counts while the game's combat timer is up (the round top-right button
    turned red with its countdown).
  - It goes back to 0 the moment the fight ends.
  - It adds up your own hits only: the upright bright-red numbers. The slanted
    dark-red numbers (damage you take) and green numbers are left out.
  - The total counts up smoothly, no commas.
  - It looks at the game 20 times a second, and drops to 10 by itself if your PC
    is taking too long over each look, so it never weighs on a slower computer.

It only LOOKS. While Roblox is the window in front, it reads the game area off the
screen (like a screenshot), finds your red damage numbers and reads them. While
you're tabbed out it pauses. It never reads or changes Roblox's
memory and never sends keys or clicks.


USING IT
  Start DamageCounter.exe (unzip the WHOLE folder first).
  Drag the panel to move it, mouse wheel to resize it, right-click for the menu.
  Your position and size are remembered.


KNOWN LIMITS (FIRST VERSION)
  - It was trained on the top 5 fliers video, not on live play, so expect some misses.
  - Very fast hits of the same number that overlap can be counted as one.
  - Hits that land over a red creature are often missed.
  - Numbers containing a 6 are the weakest (few examples to learn from).
  - The icon is a stand-in until the real one is ready.

If something's off: right-click the panel, "Save debug report". It saves a report and
the last picture of the game it read (with what it read boxed in yellow) in
%LOCALAPPDATA%\DamageCounter. Nothing is uploaded anywhere.


WHAT'S IN THE FOLDER
  DamageCounter.exe     The official Python 3.13 program from python.org (pythonw.exe),
                        renamed and otherwise untouched, so it keeps its signature.
  app\damagecounter.py  THE APP - panel window and menu. Plain text.
  app\dccore.py         THE APP - combat timer check, number finder and reader. Plain text.
  app\dcpanel.py        THE APP - draws the panel. Plain text.
  app\dcwin.py          THE APP - finds and pictures the Roblox window. Plain text.
  app\digits.npz        The digit pictures the reader compares against (taken from real hits).
  app\site-packages\    numpy, Pillow, mss and OpenCV from their official PyPI wheels.
  Everything else is Python's own runtime, as in TickTracker.

  It comes with the Sonaria Software Launcher, which downloads it, checks it and
  starts it when you join Creatures of Sonaria (switch it off on the launcher's
  Creatures of Sonaria settings page).
