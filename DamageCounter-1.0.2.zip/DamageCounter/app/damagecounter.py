"""
Damage Counter for Creatures of Sonaria - by Sonaria Software.

A panel drawn like CoS's own currency panels that adds up the damage you deal in the
current fight. It counts only while the game's combat timer is up, and goes back to 0
the moment the fight ends.

It works by looking: while Roblox is in front it reads the game area off the screen
(like a screenshot), finds your upright red damage numbers and reads them. It never reads
or changes Roblox's memory and never sends keys or clicks.

Mouse: drag to move, wheel to resize, right-click for the menu.
"""
from __future__ import annotations

import faulthandler
import json
import os
import sys
import threading
import time
import traceback
from collections import deque

import numpy as np
from PIL import Image

import dccore
import dcpanel
import dcwin as W

VERSION = "1.0.2"
# Pictures of the game per second. It looks 20 times a second, and drops to 10 by itself
# if this PC takes too long over each look, so it never weighs on a slower computer.
FAST_HZ = 20
SLOW_HZ = 10
SLOW_DOWN_MS = 40             # a look taking longer than this on average -> 10 a second
SPEED_UP_MS = 22              # ...and back to 20 once looks are this quick again
IS_WIN = sys.platform == "win32"
DEBUG = "--debug" in sys.argv
PACKAGED = bool(getattr(sys, "_dc_packaged", False))
APP_DIR = os.path.dirname(os.path.abspath(__file__))
ICON_PATH = os.path.join(APP_DIR, "counter_icon.png")
SIZE_MIN, SIZE_MAX = 36, 200


def _pick_data_dir():
    for base in ((os.environ.get("LOCALAPPDATA") if PACKAGED else None), None,
                 os.environ.get("LOCALAPPDATA"), os.path.expanduser("~"), os.environ.get("TEMP")):
        try:
            d = APP_DIR if base is None else os.path.join(base, "DamageCounter")
            os.makedirs(d, exist_ok=True)
            probe = os.path.join(d, ".dc_write_test")
            with open(probe, "w") as f:
                f.write("ok")
            os.remove(probe)
            return d
        except Exception:
            continue
    return APP_DIR


DATA_DIR = _pick_data_dir()
SETTINGS_PATH = os.path.join(DATA_DIR, "damagecounter_settings.json")
RUN_LOG = os.path.join(DATA_DIR, "run.log")


def log(msg):
    try:
        with open(RUN_LOG, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {msg}\n")
    except Exception:
        pass
    if DEBUG:
        print(msg, flush=True)


def start_logging():
    try:
        if os.path.exists(RUN_LOG) and os.path.getsize(RUN_LOG) > 2_000_000:
            os.replace(RUN_LOG, RUN_LOG + ".old")
    except Exception:
        pass


def load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            s = json.load(f)
    except Exception:
        return {}
    keep = {}
    if isinstance(s, dict):
        for key, lo, hi in (("x", -100000, 100000), ("y", -100000, 100000), ("size", SIZE_MIN, SIZE_MAX)):
            v = s.get(key)
            if isinstance(v, (int, float)) and not isinstance(v, bool) and lo <= v <= hi:
                keep[key] = int(v)
        if s.get("window") in ("smooth", "plain"):
            keep["window"] = s["window"]
    return keep


def save_settings(s):
    try:
        tmp = SETTINGS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(s, f, indent=1)
        os.replace(tmp, SETTINGS_PATH)
    except Exception:
        pass


# --------------------------------------------------------------------------
# The reader: pictures of the game in, fight total out
# --------------------------------------------------------------------------
class Reader(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True, name="DamageReader")
        self.stop = False
        self.total = 0
        self.in_combat = False
        self.status = "starting"
        self.fatal = None
        self.errors = deque(maxlen=10)
        self.beat = time.monotonic()
        self.source = "-"
        self.frame_ms = 0.0
        self.hz = FAST_HZ
        self.last_img = None
        self.last_reads = []
        self.hits_log = deque(maxlen=40)
        self.own_rect = None          # the counter's own window on the screen (for the fall-back)
        self.lock = threading.Lock()

    def run(self):
        try:
            self._run()
        except Exception:
            self.fatal = traceback.format_exc()
            log("screen reader stopped:\n" + self.fatal)

    def _run(self):
        dc = dccore.DamageCounter()
        dc.set_rate(self.hz)
        log(f"digit pictures loaded: {sum(len(v[0]) for v in dc.reader.W.values())}")
        sct = None
        hwnd = None
        next_find = 0.0
        away_since = None
        nxt = time.monotonic()
        while not self.stop:
            now = time.monotonic()
            self.beat = now
            if now < nxt:
                time.sleep(min(0.05, nxt - now))
                continue
            nxt = max(nxt + 1.0 / self.hz, now)
            if not W.window_ok(hwnd) and now >= next_find:
                hwnd = W.find_roblox_window()
                next_find = now + 1.0
                if hwnd:
                    log("found the Roblox window")
            if not W.window_ok(hwnd):
                self.status = "waiting for Roblox"
                self._set(0, False)
                dc = dccore.DamageCounter(dc.reader)
                dc.set_rate(self.hz)
                continue
            t0 = time.perf_counter()
            if W.roblox_in_front() is False:
                # Roblox isn't the window in front, so there's nothing of it on the screen to
                # read. The fight total is kept, but a fight can't outlast its 20 second timer.
                if away_since is None:
                    away_since = now
                    self.status = "paused - Roblox isn't the window in front"
                if dc.in_combat and now - away_since > 22:
                    dc = dccore.DamageCounter(dc.reader)
                    dc.set_rate(self.hz)
                    self._set(0, False)
                continue
            away_since = None
            if sct is None:
                import mss
                sct = mss.mss()
            img = W.grab_game_area(sct, hwnd, self.own_rect)
            if img is None:
                self.status = "Roblox's game area can't be found right now"
                continue
            self.source = "screen"
            before = len(dc.hits.hits)
            dc.step(now, img)
            for ht, v in dc.hits.hits[before:]:
                self.hits_log.append((time.strftime("%H:%M:%S"), v, "counted" if dc.in_combat else "before combat"))
            self._set(dc.total, dc.in_combat)
            self.frame_ms = 0.9 * self.frame_ms + 0.1 * (time.perf_counter() - t0) * 1000
            self._pick_speed(now)
            if dc.hz != self.hz:
                dc.set_rate(self.hz)
            self.status = "in combat" if dc.in_combat else "out of combat"
            with self.lock:
                self.last_img = img
                self.last_reads = list(dc.last_reads)

    def _pick_speed(self, now):
        """20 looks a second normally; 10 if this PC is taking too long over each look."""
        if self.hz == FAST_HZ and self.frame_ms > SLOW_DOWN_MS:
            self.hz = SLOW_HZ
            log(f"looks are taking {self.frame_ms:.0f} ms - slowing to {SLOW_HZ} a second to go easy on this PC")
        elif self.hz == SLOW_HZ and self.frame_ms < SPEED_UP_MS:
            self.hz = FAST_HZ
            log(f"looks are quick again ({self.frame_ms:.0f} ms) - back to {FAST_HZ} a second")

    def _set(self, total, in_combat):
        if in_combat != self.in_combat:
            log(f"combat {'started' if in_combat else 'ended'} (total was {self.total})")
        self.total, self.in_combat = total, in_combat

    def report(self):
        lines = [f"Damage Counter {VERSION} report  {time.strftime('%Y-%m-%d %H:%M:%S')}",
                 f"Status: {self.status}  (reading the {self.source}, {self.hz} a second, {self.frame_ms:.0f} ms a picture)",
                 f"In combat: {self.in_combat}   total: {self.total}",
                 "", "Last hits it read:"]
        lines += [f"  {a}  {v}  ({c})" for a, v, c in self.hits_log]
        if self.fatal:
            lines += ["", "READER STOPPED:", self.fatal]
        lines += ["", "Errors:"] + list(self.errors)
        return "\n".join(lines)


# --------------------------------------------------------------------------
# The panel window
# --------------------------------------------------------------------------
class App:
    KEY = "#ff00fe"

    def __init__(self):
        import tkinter as tk
        from PIL import ImageTk
        self.tk, self.ImageTk = tk, ImageTk
        self.settings = load_settings()
        self.root = tk.Tk()
        self.root.title("Damage Counter")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=self.KEY)
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        # starts at two-thirds of the size of the game's own panel
        self.default_size = max(SIZE_MIN, min(SIZE_MAX, int(round(dcpanel.default_height(sh) * 2 / 3))))
        self.size = int(self.settings.get("size", self.default_size))
        self.x = min(max(int(self.settings.get("x", 40)), -200), sw - 80)
        self.y = min(max(int(self.settings.get("y", sh // 2)), 0), sh - 40)
        self.root.geometry(f"+{self.x}+{self.y}")
        self.label = tk.Label(self.root, bd=0, bg=self.KEY)
        self.label.pack()
        self.hwnd = None
        self.smooth = IS_WIN and self.settings.get("window", "smooth") == "smooth"
        if self.smooth:
            try:
                self.root.update_idletasks()
                self.hwnd = W.window_handle(self.root)
                W.set_layered(self.hwnd, True)
            except Exception:
                log("smooth window could not be set up:\n" + traceback.format_exc())
                self.smooth = False
        if not self.smooth:
            self._go_plain(first=True)
        self.draw_fails = 0
        self.images = {}
        self.photos = {}
        self.last_key = None
        self.shown = 0.0              # the number on the panel, easing towards the real total
        self.errors = deque(maxlen=20)
        self.root.report_callback_exception = lambda *a: self._error("".join(traceback.format_exception(*a)))
        for w in (self.root, self.label):
            w.bind("<ButtonPress-1>", self._press)
            w.bind("<B1-Motion>", self._drag)
            w.bind("<ButtonRelease-1>", lambda e: self._save())
            w.bind("<MouseWheel>", self._wheel)
            w.bind("<Button-3>", self._menu)
        self.menu = tk.Menu(self.root, tearoff=0)
        self.menu.add_command(label="Reset size", command=self._reset_size)
        self.menu.add_command(label="Switch to plain window (if the panel looks wrong)" if self.smooth
                              else "Switch to smooth window (soft edges)", command=self._switch_window)
        self.menu.add_command(label="Save debug report", command=self._debug)
        self.menu.add_command(label="Open Damage Counter's files (logs, settings)", command=self._open_folder)
        self.menu.add_separator()
        self.menu.add_command(label="Quit Damage Counter", command=self.quit)
        self.reader = Reader()
        W.timer_res(True)
        self.reader.start()
        self.ticks = 0
        self.last_t = time.monotonic()
        log(f"panel open at {self.x},{self.y}, size {self.size}")
        self.root.after(30, self._ui)

    def _go_plain(self, first=False):
        self.smooth = False
        try:
            if self.hwnd and not first:
                W.set_layered(self.hwnd, False)
            self.root.attributes("-transparentcolor", self.KEY)
        except Exception:
            log("plain window setup problem:\n" + traceback.format_exc())
        self.last_key = None

    def _error(self, err):
        if err != getattr(self, "_last_err", None):
            self._last_err = err
            log("panel error:\n" + err)
        self.errors.append(err)

    def _render(self, key):
        size, text = key
        return dcpanel.render_panel(size, text, ICON_PATH, rim=True)

    def _image(self, key):
        img = self.images.get(key)
        if img is None:
            if len(self.images) > 200:
                self.images.clear()
            img = self.images[key] = self._render(key)
        return img

    def _photo(self, key):
        ph = self.photos.get(key)
        if ph is None:
            img = self._render(key)
            bg = Image.new("RGBA", img.size, (255, 0, 254, 255))
            flat = img.copy()
            flat.putalpha(img.split()[3].point(lambda v: 255 if v >= 150 else 0))
            bg.alpha_composite(flat)
            if len(self.photos) > 200:
                self.photos.clear()
            ph = self.photos[key] = self.ImageTk.PhotoImage(bg.convert("RGB"))
        return ph

    def _ui(self):
        try:
            self.ticks += 1
            now = time.monotonic()
            dt, self.last_t = now - self.last_t, now
            target = float(self.reader.total)
            if target <= 0 or target < self.shown:
                self.shown = target                              # back to 0 at once when the fight ends
            else:
                # count up smoothly but quickly: most of the way in about a sixth of a second
                self.shown += (target - self.shown) * min(1.0, dt * 16.0)
                if target - self.shown < 1:
                    self.shown = target
            key = (self.size, str(int(round(self.shown))))
            if key != self.last_key:
                self.last_key = key
                if self.smooth:
                    img = self._image(key)
                    self.root.geometry(f"{img.width}x{img.height}+{self.x}+{self.y}")
                    if W.draw_smooth(self.hwnd, img, self.x, self.y):
                        self.draw_fails = 0
                    else:
                        self.draw_fails += 1
                        self.last_key = None
                        if self.draw_fails >= 5:
                            log("smooth drawing keeps failing - switching to the plain window")
                            self._go_plain()
                else:
                    self.label.configure(image=self._photo(key))
                img_w, img_h = self._image(key).size if self.smooth else (0, 0)
                self.reader.own_rect = (self.x, self.y, img_w or 400, img_h or 150)
            if self.ticks % 60 == 0:
                if self.root.state() != "normal":
                    self.root.deiconify()
                self.root.attributes("-topmost", True)
            if self.ticks % 150 == 0:
                self._status()
        except Exception:
            self._error(traceback.format_exc())
        self.root.after(33, self._ui)

    def _status(self):
        try:
            with open(os.path.join(DATA_DIR, "status.txt"), "w", encoding="utf-8") as f:
                f.write(self.reader.report() + "\n")
            if time.monotonic() - self.reader.beat > 5 and not self.reader.fatal:
                log("screen reader seems stuck")
        except Exception:
            pass

    def _press(self, e):
        self._dx, self._dy = e.x_root - self.x, e.y_root - self.y

    def _drag(self, e):
        self.x, self.y = e.x_root - self._dx, e.y_root - self._dy
        self.root.geometry(f"+{self.x}+{self.y}")
        rect = self.reader.own_rect
        if rect:
            self.reader.own_rect = (self.x, self.y) + tuple(rect[2:])

    def _wheel(self, e):
        self.size = max(SIZE_MIN, min(SIZE_MAX, self.size + (3 if e.delta > 0 else -3)))
        self.last_key = None
        self._save()

    def _reset_size(self):
        self.size = self.default_size
        self.last_key = None
        self._save()

    def _switch_window(self):
        self.settings["window"] = "plain" if self.smooth else "smooth"
        self._save()
        W.message_box("Saved. Damage Counter will now close - start it again to use the "
                      f"{self.settings['window']} window.")
        self.quit()

    def _menu(self, e):
        try:
            self.menu.tk_popup(e.x_root, e.y_root)
        finally:
            self.menu.grab_release()

    def _debug(self):
        path = os.path.join(DATA_DIR, "debug_report.txt")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.reader.report())
                f.write("\n\n---- panel errors ----\n" + "\n".join(self.errors))
            with self.reader.lock:
                img, reads = self.reader.last_img, self.reader.last_reads
            if img is not None:
                # the last picture of the game it read, with what it read, kept on this PC only
                from PIL import ImageDraw
                im = Image.fromarray(np.ascontiguousarray(dccore.DamageCounter.normalise(img)))
                d = ImageDraw.Draw(im)
                for v, x, y, h in reads:
                    d.rectangle([x - h, y - h // 2 - 3, x + h, y + h // 2 + 3], outline=(255, 255, 0), width=2)
                    d.text((x - h, y - h // 2 - 16), v, fill=(255, 255, 0))
                im.save(os.path.join(DATA_DIR, "last_picture.png"))
            if IS_WIN:
                os.startfile(path)
        except Exception:
            self._error(traceback.format_exc())

    def _open_folder(self):
        try:
            if IS_WIN:
                os.startfile(DATA_DIR)
        except Exception:
            self._error(traceback.format_exc())

    def _save(self):
        self.settings.update(x=self.x, y=self.y, size=self.size)
        save_settings(dict(self.settings))

    def quit(self):
        log("quit chosen from the menu")
        self.reader.stop = True
        self._save()
        W.timer_res(False)
        self.root.destroy()


def main():
    start_logging()
    libs = []
    for name in ("PIL", "numpy", "cv2", "mss"):
        try:
            libs.append(f"{name} {getattr(__import__(name), '__version__', '?')}")
        except Exception as e:
            libs.append(f"{name} MISSING ({e})")
    log(f"Damage Counter {VERSION} starting - {'packaged app' if PACKAGED else 'run from source'}, "
        f"Python {sys.version.split()[0]}, {', '.join(libs)}, folder {DATA_DIR}")
    if W.already_running():
        log("another Damage Counter is already running - this one is stopping")
        W.message_box("Damage Counter is already running.\n\nTo restart it, right-click the panel and choose "
                      "Quit Damage Counter, then start it again.")
        return
    try:
        App().root.mainloop()
    except Exception:
        err = traceback.format_exc()
        log("CRASH:\n" + err)
        W.message_box("Damage Counter hit an error and had to close.\n\nPlease send this file to whoever "
                      f"gave you Damage Counter:\n{RUN_LOG}\n\n" + err[-600:])


if __name__ == "__main__":
    main()
