"""
TickTracker 4.1.0 (basic) - natural heal tick timer for Creatures of Sonaria.

Stripped back to the essentials:
  1. read the HEALTH bar off the screen (it only LOOKS - it never touches Roblox),
  2. spot natural heal ticks and count down to the next one,
  3. while you're tabbed out, watch for the game's combat timer and show an alert on
     the badge until you're back (ttalert.py - it takes a picture of the Roblox
     window the way OBS's window capture does; still looking only).

The badge shows:
  number    seconds until your next natural tick
  heart icon   not counting yet: no heal seen since you spawned, or it can't see a
               health bar on screen (status.txt says which)

F6 (or double-click the badge) = "I just ticked" manual resync.
Right-click the badge for the menu. Drag to move, mouse wheel to resize.
"""
from __future__ import annotations

import atexit
import faulthandler
import io
import json
import math
import os
import sys
import threading
import time
import traceback
from collections import deque

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

import ttcore as C

try:
    import ttalert
    _alert_import_error = None
except Exception:                 # the alert is an extra: the tick timer must still start without it
    ttalert = None
    _alert_import_error = traceback.format_exc()

VERSION = "4.1.0"
SAMPLE_HZ = 60
OVERLAY_PORT = 47615          # OBS Browser Source: http://127.0.0.1:47615/overlay
LOST_RESET_SECONDS = 8.0      # in Roblox with no health bar this long = menu / new creature -> start fresh
AWAY_RESET_SECONDS = 900.0    # tabbed out longer than this: the old rhythm isn't worth keeping
IS_WIN = sys.platform == "win32"
DEBUG = "--debug" in sys.argv

# PACKAGED = running as the shareable TickTracker folder (TickTracker.exe + app\). The
# start-up file (app\sitecustomize.py) sets the flag. Otherwise it's being run straight
# from the .py file with an installed Python, which is how it's developed.
PACKAGED = bool(getattr(sys, "_tt_packaged", False))
APP_DIR = RES_DIR = os.path.dirname(os.path.abspath(__file__))


def _pick_data_dir():
    if PACKAGED:
        # the app keeps its settings and logs in one fixed place, wherever its folder is
        # moved to - so a newer TickTracker unzipped somewhere else keeps your settings,
        # and it still works from a folder it isn't allowed to write in
        try:
            d = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TickTracker")
            os.makedirs(d, exist_ok=True)
            return d
        except Exception:
            pass                       # no usable AppData (very unusual): fall through
    try:
        probe = os.path.join(APP_DIR, ".tt_write_test")
        with open(probe, "w") as f:
            f.write("ok")
        os.remove(probe)
        return APP_DIR
    except Exception:
        pass
    for base in (os.environ.get("LOCALAPPDATA"), os.path.expanduser("~"), os.environ.get("TEMP")):
        try:
            d = os.path.join(base, "TickTracker")
            os.makedirs(d, exist_ok=True)
            return d
        except Exception:
            continue
    return APP_DIR                     # nowhere to write: logs and settings just won't save


DATA_DIR = _pick_data_dir()
SETTINGS_PATH = os.path.join(DATA_DIR, "ticktracker_settings.json")
# Source Sans Bold: the font Creatures of Sonaria's own HUD labels and timers use
FONT_PATH = os.path.join(RES_DIR, "SourceSans3-Bold.ttf")
FONT_SCALE = 1.12             # its digits are a little shorter than the old font's, so draw them a touch bigger
ICON_PATH = os.path.join(RES_DIR, "icon.png")
ALERT_ICON_PATH = os.path.join(RES_DIR, "alert.png")
ALERT_FRAMES = 12             # pictures in one pulse of the combat alert
ALERT_PERIOD = 0.9            # seconds per pulse
ICO_PATH = os.path.join(RES_DIR, "icon.ico")
RUN_LOG = os.path.join(DATA_DIR, "run.log")
_crash_file = None


def log(msg):
    try:
        with open(RUN_LOG, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {msg}\n")
    except Exception:
        pass


def start_logging():
    """run.log = what happened; crash_hard.txt = crashes and freezes Python can't catch."""
    global _crash_file
    try:
        if os.path.exists(RUN_LOG) and os.path.getsize(RUN_LOG) > 300_000:
            os.remove(RUN_LOG)
    except Exception:
        pass
    try:
        crash_path = os.path.join(DATA_DIR, "crash_hard.txt")
        if os.path.exists(crash_path) and os.path.getsize(crash_path) > 300_000:
            os.remove(crash_path)
        _crash_file = open(crash_path, "a", encoding="utf-8")
        _crash_file.write(f"\n--- TickTracker {VERSION} started {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
        _crash_file.flush()
        faulthandler.enable(file=_crash_file, all_threads=True)
    except Exception:
        _crash_file = None
    sys.excepthook = lambda *a: log("UNCAUGHT ERROR:\n" + "".join(traceback.format_exception(*a)))
    threading.excepthook = lambda a: log("UNCAUGHT ERROR in thread:\n" + "".join(
        traceback.format_exception(a.exc_type, a.exc_value, a.exc_traceback)))
    atexit.register(lambda: log("process exiting"))


# --------------------------------------------------------------------------
# The few Windows calls it needs. Each is small and none talks to Roblox.
# --------------------------------------------------------------------------
if IS_WIN:
    import ctypes
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)     # work in real screen pixels
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass
    _user32 = ctypes.WinDLL("user32")
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    _kernel32.CreateMutexW.restype = ctypes.c_void_p

    # F6 = "I just ticked". Uses Windows' normal hotkey system (RegisterHotKey): Windows
    # tells TickTracker when F6 is pressed - it never watches the rest of the keyboard.
    _f6_event = threading.Event()
    _f6_started = False

    def _f6_loop():
        from ctypes import wintypes
        u32 = ctypes.WinDLL("user32")
        u32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
        if not u32.RegisterHotKey(None, 1, 0x4000, 0x75):     # MOD_NOREPEAT, VK_F6
            log("F6 is taken by another app - double-click the badge to resync instead")
            return
        msg = wintypes.MSG()
        while u32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            if msg.message == 0x0312:                         # WM_HOTKEY
                _f6_event.set()

    def f6_pressed():
        global _f6_started
        if not _f6_started:
            _f6_started = True
            threading.Thread(target=_f6_loop, daemon=True, name="F6Hotkey").start()
        if _f6_event.is_set():
            _f6_event.clear()
            return True
        return False

    _user32.GetForegroundWindow.restype = ctypes.c_void_p
    _user32.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
    _user32.GetWindowTextW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_int]

    def roblox_in_front():
        """True if the window you're using is Roblox, False if it's another app,
        None if it can't tell (then nothing changes). It only reads the front
        window's title from Windows - it never asks or touches the window itself."""
        try:
            fg = _user32.GetForegroundWindow()
            if not fg:
                return None
            pid = ctypes.c_ulong()
            _user32.GetWindowThreadProcessId(fg, ctypes.byref(pid))
            if pid.value == os.getpid():
                return None                       # you're clicking the badge itself
            buf = ctypes.create_unicode_buffer(64)
            _user32.GetWindowTextW(fg, buf, 64)
            return buf.value == "Roblox"
        except Exception:
            return None

    def already_running():
        already_running.handle = _kernel32.CreateMutexW(None, 0, "TickTracker_single_instance")
        return ctypes.get_last_error() == 183

    def message_box(text):
        ctypes.windll.user32.MessageBoxW(None, text, "TickTracker", 0x40 | 0x40000)

    # --- smooth badge: hand Windows a picture with real transparency for the badge's
    # own (ordinary tkinter) window. Plain drawing calls only - nothing here waits on
    # another program, and Windows never calls back into TickTracker.
    from ctypes import wintypes as _wt

    class _BMIH(ctypes.Structure):
        _fields_ = [("biSize", _wt.DWORD), ("biWidth", _wt.LONG), ("biHeight", _wt.LONG),
                    ("biPlanes", _wt.WORD), ("biBitCount", _wt.WORD), ("biCompression", _wt.DWORD),
                    ("biSizeImage", _wt.DWORD), ("biXPelsPerMeter", _wt.LONG),
                    ("biYPelsPerMeter", _wt.LONG), ("biClrUsed", _wt.DWORD), ("biClrImportant", _wt.DWORD)]

    class _BLEND(ctypes.Structure):
        _fields_ = [("BlendOp", ctypes.c_ubyte), ("BlendFlags", ctypes.c_ubyte),
                    ("SourceConstantAlpha", ctypes.c_ubyte), ("AlphaFormat", ctypes.c_ubyte)]

    _gdi32 = ctypes.WinDLL("gdi32")
    _user32.GetDC.argtypes = [_wt.HWND]
    _user32.GetDC.restype = _wt.HDC
    _user32.ReleaseDC.argtypes = [_wt.HWND, _wt.HDC]
    _user32.GetParent.argtypes = [_wt.HWND]
    _user32.GetParent.restype = _wt.HWND
    _user32.UpdateLayeredWindow.argtypes = [
        _wt.HWND, _wt.HDC, ctypes.POINTER(_wt.POINT), ctypes.POINTER(_wt.SIZE), _wt.HDC,
        ctypes.POINTER(_wt.POINT), _wt.COLORREF, ctypes.POINTER(_BLEND), _wt.DWORD]
    _user32.UpdateLayeredWindow.restype = _wt.BOOL
    _gdi32.CreateCompatibleDC.argtypes = [_wt.HDC]
    _gdi32.CreateCompatibleDC.restype = _wt.HDC
    _gdi32.CreateDIBSection.argtypes = [_wt.HDC, ctypes.POINTER(_BMIH), _wt.UINT,
                                        ctypes.POINTER(ctypes.c_void_p), _wt.HANDLE, _wt.DWORD]
    _gdi32.CreateDIBSection.restype = _wt.HBITMAP
    _gdi32.SelectObject.argtypes = [_wt.HDC, _wt.HGDIOBJ]
    _gdi32.SelectObject.restype = _wt.HGDIOBJ
    _gdi32.DeleteObject.argtypes = [_wt.HGDIOBJ]
    _gdi32.DeleteDC.argtypes = [_wt.HDC]
    _GetWL = getattr(_user32, "GetWindowLongPtrW", None) or _user32.GetWindowLongW
    _SetWL = getattr(_user32, "SetWindowLongPtrW", None) or _user32.SetWindowLongW
    _GetWL.argtypes = [_wt.HWND, ctypes.c_int]
    _GetWL.restype = ctypes.c_ssize_t
    _SetWL.argtypes = [_wt.HWND, ctypes.c_int, ctypes.c_ssize_t]
    _SetWL.restype = ctypes.c_ssize_t

    def window_handle(root):
        """Windows' handle for a tkinter window's outer frame."""
        try:
            h = int(root.wm_frame(), 16)
            if h:
                return h
        except Exception:
            pass
        return _user32.GetParent(root.winfo_id()) or root.winfo_id()

    def set_layered(hwnd, on):
        st = _GetWL(hwnd, -20)                               # GWL_EXSTYLE
        _SetWL(hwnd, -20, (st | 0x80000) if on else (st & ~0x80000))   # WS_EX_LAYERED

    def draw_smooth(hwnd, img, x, y):
        """Show an RGBA picture as the window, soft edges and shadow included.
        Returns False if Windows refuses, so the caller can fall back."""
        w, h = img.size
        a = np.asarray(img, dtype=np.uint16)
        alpha = a[..., 3:4]
        rgb = (a[..., :3] * alpha + 127) // 255             # premultiplied alpha
        bgra = np.ascontiguousarray(np.concatenate([rgb[..., ::-1], alpha], axis=2).astype(np.uint8))
        screen = _user32.GetDC(None)
        mem = _gdi32.CreateCompatibleDC(screen)
        bmi = _BMIH()
        bmi.biSize = ctypes.sizeof(_BMIH)
        bmi.biWidth, bmi.biHeight, bmi.biPlanes, bmi.biBitCount = w, -h, 1, 32
        bits = ctypes.c_void_p()
        bmp = _gdi32.CreateDIBSection(screen, ctypes.byref(bmi), 0, ctypes.byref(bits), None, 0)
        ok = False
        if bmp and bits.value:
            ctypes.memmove(bits.value, bgra.ctypes.data, w * h * 4)
            old = _gdi32.SelectObject(mem, bmp)
            blend = _BLEND(0, 0, 255, 1)                      # use the picture's own alpha
            ok = bool(_user32.UpdateLayeredWindow(
                hwnd, screen, ctypes.byref(_wt.POINT(int(x), int(y))), ctypes.byref(_wt.SIZE(w, h)),
                mem, ctypes.byref(_wt.POINT(0, 0)), 0, ctypes.byref(blend), 2))
            _gdi32.SelectObject(mem, old)
            _gdi32.DeleteObject(bmp)
        _gdi32.DeleteDC(mem)
        _user32.ReleaseDC(None, screen)
        return ok

    def timer_res(on):
        try:
            winmm = ctypes.WinDLL("winmm")
            (winmm.timeBeginPeriod if on else winmm.timeEndPeriod)(1)
        except Exception:
            pass

    def virtual_screen():
        """(left, top, width, height) of every monitor together, in real pixels - or None."""
        try:
            g = _user32.GetSystemMetrics
            box = (int(g(76)), int(g(77)), int(g(78)), int(g(79)))
            return box if box[2] > 0 and box[3] > 0 else None
        except Exception:
            return None

    # --- Desktop shortcut. TickTracker.exe is the official Python program, so on its own
    # it shows Python's icon; a shortcut can carry TickTracker's own icon (and be pinned
    # to the taskbar). This asks Windows' normal shortcut maker to write one .lnk file.
    # It only runs when you pick it from the badge's menu.
    class _GUID(ctypes.Structure):
        _fields_ = [("a", _wt.DWORD), ("b", _wt.WORD), ("c", _wt.WORD), ("d", ctypes.c_ubyte * 8)]

    def _guid(text):
        g = _GUID()
        ctypes.OleDLL("ole32").CLSIDFromString(ctypes.c_wchar_p(text), ctypes.byref(g))
        return g

    def _com(obj, index, *args, argtypes=(), restype=ctypes.HRESULT):
        """Call method number `index` of a Windows COM object."""
        vtbl = ctypes.cast(obj, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        return ctypes.WINFUNCTYPE(restype, ctypes.c_void_p, *argtypes)(vtbl[index])(obj, *args)

    def make_desktop_shortcut(target, icon):
        """Write 'TickTracker.lnk' on the Desktop pointing at `target`. Returns its path."""
        ole32, shell32 = ctypes.OleDLL("ole32"), ctypes.OleDLL("shell32")
        ole32.CoCreateInstance.argtypes = [ctypes.POINTER(_GUID), ctypes.c_void_p, _wt.DWORD,
                                           ctypes.POINTER(_GUID), ctypes.POINTER(ctypes.c_void_p)]
        shell32.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(_GUID), _wt.DWORD, _wt.HANDLE,
                                                 ctypes.POINTER(ctypes.c_void_p)]
        ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
        ole32.CoTaskMemFree.restype = None
        try:
            ole32.CoInitialize(None)
        except OSError:
            pass                                          # already set up on this thread - fine
        raw = ctypes.c_void_p()                           # the real Desktop (it may live in OneDrive)
        shell32.SHGetKnownFolderPath(ctypes.byref(_guid("{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}")),
                                     0, None, ctypes.byref(raw))
        desktop = ctypes.wstring_at(raw.value)
        ole32.CoTaskMemFree(raw)
        path = os.path.join(desktop, "TickTracker.lnk")
        W = ctypes.c_wchar_p
        link, pfile = ctypes.c_void_p(), ctypes.c_void_p()
        ole32.CoCreateInstance(ctypes.byref(_guid("{00021401-0000-0000-C000-000000000046}")), None, 1,
                               ctypes.byref(_guid("{000214F9-0000-0000-C000-000000000046}")),
                               ctypes.byref(link))                            # a blank shortcut
        try:
            _com(link, 20, target, argtypes=(W,))                             # SetPath
            _com(link, 9, os.path.dirname(target), argtypes=(W,))             # SetWorkingDirectory
            _com(link, 7, "TickTracker - heal tick timer for Creatures of Sonaria", argtypes=(W,))
            if os.path.exists(icon):
                _com(link, 17, icon, 0, argtypes=(W, ctypes.c_int))           # SetIconLocation
            _com(link, 0, ctypes.byref(_guid("{0000010B-0000-0000-C000-000000000046}")),
                 ctypes.byref(pfile), argtypes=(ctypes.POINTER(_GUID), ctypes.POINTER(ctypes.c_void_p)))
            try:
                _com(pfile, 6, path, 1, argtypes=(W, _wt.BOOL))               # save it as a file
            finally:
                _com(pfile, 2, restype=ctypes.c_ulong)                        # Release
        finally:
            _com(link, 2, restype=ctypes.c_ulong)                             # Release
        return path
else:
    def f6_pressed():
        return False

    def roblox_in_front():
        return None

    def already_running():
        return False

    def message_box(text):
        print("TickTracker: " + text)

    def timer_res(on):
        pass

    def virtual_screen():
        return None

    def make_desktop_shortcut(target, icon):
        raise OSError("shortcuts are a Windows thing")


def grab(sct, region):
    shot = sct.grab(region)
    arr = np.frombuffer(shot.bgra, dtype=np.uint8).reshape(shot.height, shot.width, 4)
    return arr[..., 2::-1].copy()      # BGRA -> RGB


# --------------------------------------------------------------------------
# Badge drawing
# --------------------------------------------------------------------------
_font_cache = {}


def _font(px):
    px = max(6, int(px * FONT_SCALE))
    if px not in _font_cache:
        try:
            _font_cache[px] = ImageFont.truetype(FONT_PATH, px)
        except Exception:
            _font_cache[px] = ImageFont.load_default()
    return _font_cache[px]


# Outline of CoS's round HUD buttons, traced from the game: radius every 4 degrees
# (0 = right, 90 = down), as a fraction of half the button's width.
COS_SHAPE = [0.9819, 0.9713, 0.9587, 0.9491, 0.9448, 0.9439, 0.9442, 0.9439, 0.9418, 0.9377, 0.9308, 0.9246, 0.9211, 0.9234, 0.9305, 0.9393, 0.9471, 0.951, 0.9532, 0.9548, 0.9564, 0.9539, 0.9474, 0.9377, 0.9298, 0.9241, 0.9224, 0.9232, 0.9254, 0.9267, 0.9272, 0.9271, 0.927, 0.9268, 0.9285, 0.9337, 0.9427, 0.9525, 0.9602, 0.9647, 0.9676, 0.9705, 0.9755, 0.9816, 0.9875, 0.9895, 0.9875, 0.981, 0.9728, 0.9634, 0.9555, 0.9509, 0.9526, 0.9621, 0.9768, 0.9922, 1.0007, 0.9999, 0.9894, 0.9766, 0.9648, 0.959, 0.9578, 0.9603, 0.9619, 0.9612, 0.9578, 0.9523, 0.945, 0.9366, 0.9294, 0.9259, 0.9257, 0.9283, 0.9306, 0.9344, 0.9383, 0.9443, 0.9497, 0.9539, 0.9559, 0.956, 0.9543, 0.9534, 0.954, 0.9584, 0.9641, 0.9721, 0.98, 0.9847]
COS_EDGE = 0.0714     # stone edge under the face, fraction of width


def _stone(cx, cy, rx, ry=None, n=180):
    """The face of a CoS button: the traced outline, scaled to rx (half width)."""
    ry = rx if ry is None else ry
    m = len(COS_SHAPE)
    pts = []
    for i in range(n):
        deg = 360.0 * i / n
        f = deg / 4.0
        j = int(f) % m
        u = f - int(f)
        k = COS_SHAPE[j] * (1 - u) + COS_SHAPE[(j + 1) % m] * u
        t = math.radians(deg)
        pts.append((cx + rx * k * math.cos(t), cy + ry * k * math.sin(t)))
    return pts


def _gradient_text(img, xy, text, font, top, bottom, alpha, stroke, stroke_fill):
    """Text in the game's font with its dark outline and a top-to-bottom colour gradient."""
    d = ImageDraw.Draw(img)
    d.text(xy, text, font=font, anchor="mm", fill=stroke_fill, stroke_width=stroke, stroke_fill=stroke_fill)
    if top == bottom:
        d.text(xy, text, font=font, anchor="mm", fill=top + (alpha,))
        return
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).text(xy, text, font=font, anchor="mm", fill=alpha)
    bb = mask.getbbox()
    if not bb:
        return
    grad = Image.new("RGBA", img.size)
    gd = ImageDraw.Draw(grad)
    y0, y1 = bb[1], bb[3]
    for y in range(y0, y1 + 1):
        u = (y - y0) / max(1, y1 - y0)
        gd.line([(bb[0], y), (bb[2], y)], fill=tuple(int(top[i] + (bottom[i] - top[i]) * u) for i in range(3)) + (255,))
    img.paste(grad, (0, 0), mask)


# CoS GUI palette, measured pixel by pixel from the game's round HUD buttons
COS_OUTLINE = (25, 27, 39)
FACE_TOP = (52, 58, 69)       # upper face, in the shade
FACE_MID = (76, 83, 95)
FACE_LOW = (86, 93, 104)      # lower face catches the light
RIM_LIFT = 18                 # the uneven rim stroke is this much lighter than the face under it
LIP = (98, 105, 117)          # bright lip just above the bottom edge
EDGE_TOP = (65, 70, 78)       # stone thickness under the face, lighter at the top...
EDGE_LOW = (44, 47, 55)       # ...darker at the bottom (no black outline in CoS)
COS_GREEN = (84, 255, 131)
# coloured numbers fade top -> bottom; white stays plain white like the game's labels
GRADIENTS = {
    C.BLEED_RED: ((172, 22, 34), (255, 72, 72)),       # dark red -> red
    C.BURN_ORANGE: ((255, 118, 18), (255, 206, 70)),   # orange -> yellowy orange
    COS_GREEN: ((30, 190, 90), (120, 255, 150)),       # tick flash
}
# The countdown number: coral red at the top fading to pink at the bottom. Both are
# sampled straight from the heart icon - its heart (251,90,108) and its ring (255,187,248).
HEART_CORAL = (251, 90, 108)
HEART_PINK = (255, 187, 248)
GRADIENTS[HEART_CORAL] = (HEART_CORAL, HEART_PINK)


def shadow_shapes(size):
    """
    The badge's drop shadow as three flat black shapes, each a little bigger and a
    little lower than the last. Shown as three see-through windows stacked under the
    badge, they add up to a soft shadow like the one under CoS's own buttons (which
    darken what's below them by about 30%, fading out over ~10px).
    Returns [(image with the see-through key colour around the shape), ...],
    all the same size and alignment as the badge image.
    """
    ss = 4
    D = size * ss
    r = D / 2
    edge = D * COS_EDGE
    pad = int(D * 0.16)
    W, H = int(D + 2 * pad), int(D + edge + 2 * pad)
    cx, cy = W / 2, pad + r
    out = []
    for grow, drop in ((0.010, 0.030), (0.035, 0.050), (0.065, 0.070)):
        m = Image.new("L", (W, H), 0)
        d = ImageDraw.Draw(m)
        g = D * grow
        d.polygon(_stone(cx, cy + D * drop, r + g, r + g), fill=255)
        d.polygon(_stone(cx, cy + edge + D * drop, r + g, r + g), fill=255)
        m = m.resize((W // ss, H // ss), Image.LANCZOS).point(lambda v: 255 if v >= 128 else 0)
        img = Image.new("RGB", m.size, (255, 0, 254))
        img.paste((0, 0, 0), (0, 0), m)
        out.append(img)
    return out


SHADOW_ALPHA = 0.11          # each of the three layers; together ~30% like the game's

# The people button in CoS's HUD is 98px wide at the resolution it was measured at
# (a maximised window on a 1440px-tall screen)
DEFAULT_SIZE = 98


def default_size(screen_h):
    """Badge size to start with on this screen: CoS's HUD grows and shrinks with the
    screen, so the badge does too (74px on a 1080p laptop, 98px at 1440p, 148px at 4K)
    until you resize it yourself with the mouse wheel."""
    try:
        return int(max(48, min(240, 2 * round(DEFAULT_SIZE * screen_h / 1440 / 2))))
    except Exception:
        return DEFAULT_SIZE


_stone_cache = {}


def _stone_layer(size, state, has_heal, ss=4):
    """The button itself at 4x size (no text). Drawn once per size/state and reused,
    so a new number each second only costs drawing the number."""
    key = (size, state, has_heal)
    hit = _stone_cache.get(key)
    if hit is None:
        if len(_stone_cache) > 12:
            _stone_cache.clear()
        hit = _stone_cache[key] = _draw_stone(size, state, has_heal, ss)
    return hit


def _draw_stone(size, state, heal, ss):
    D = size * ss
    r = D / 2
    edge = D * COS_EDGE                 # visible stone thickness at the bottom
    pad = int(D * 0.16)                 # room for the drop shadow
    heal_h = int(D * 0.30) if heal else 0
    W = int(D + 2 * pad)
    H = int(D + edge + 2 * pad + heal_h)
    cx, cy = W / 2, pad + r
    ow = 0                              # CoS buttons have no outline - the face meets the world

    a = {"locked": 255, "tentative": 240, "searching": 235}.get(state, 150)

    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    # soft drop shadow, a little below the button like the game's
    sh = Image.new("L", (W, H), 0)
    ImageDraw.Draw(sh).polygon(_stone(cx, cy + edge * 0.9 + D * 0.03, r * 1.0, r * 1.0 + edge * 0.5),
                               fill=int(a * 0.42))
    sh = sh.filter(ImageFilter.GaussianBlur(D * 0.050))
    img.paste(Image.new("RGBA", (W, H), (0, 0, 0, 255)), (0, 0), sh)

    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    # stone edge below the face: a vertical gradient, light under the lip to dark at the base
    eg = Image.new("RGBA", (W, H))
    egd = ImageDraw.Draw(eg)
    e0, e1 = cy, cy + r + edge
    for y in range(int(e0), int(e1) + 1):
        u = min(1.0, max(0.0, (y - (cy + r * 0.75)) / (r * 0.25 + edge)))
        col = tuple(int(EDGE_TOP[i] + (EDGE_LOW[i] - EDGE_TOP[i]) * u) for i in range(3))
        egd.line([(0, y), (W, y)], fill=col + (a,))
    em = Image.new("L", (W, H), 0)
    ImageDraw.Draw(em).polygon(_stone(cx, cy + edge, r, r), fill=255)
    lay.paste(eg, (0, 0), em)

    # face: shaded top fading to a lighter bottom
    fr = r - ow
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    dx, dy = xx + 0.5 - cx, yy + 0.5 - cy
    ang = np.degrees(np.arctan2(dy, dx)) % 360.0
    shape = np.array(COS_SHAPE, np.float32)
    fi = ang / 4.0
    j = fi.astype(np.int32) % len(shape)
    u = fi - np.floor(fi)
    edge_r = (shape[j] * (1 - u) + shape[(j + 1) % len(shape)] * u) * fr
    f = np.hypot(dx, dy) / np.maximum(edge_r, 1.0)           # 0 centre -> 1 at the rim
    t = np.clip((yy - (cy - fr)) / (2 * fr), 0.0, 1.0)        # 0 top -> 1 bottom
    base = np.empty((H, W, 3), np.float32)
    for i in range(3):
        upper = FACE_TOP[i] + (FACE_MID[i] - FACE_TOP[i]) * np.clip(t / 0.5, 0, 1)
        base[..., i] = np.where(t < 0.5, upper,
                                FACE_MID[i] + (FACE_LOW[i] - FACE_MID[i]) * np.clip((t - 0.5) / 0.5, 0, 1))
    # uneven lighter-grey stroke round the rim, like the raised edge of the game's
    # buttons: thin across the top, wider down the sides, widest along the bottom,
    # with a lumpy inner edge
    th = np.radians(ang)
    inset = (0.11 + 0.055 * np.sin(th)
             + 0.020 * np.sin(5 * th + 1.0) + 0.015 * np.sin(9 * th + 2.5) + 0.010 * np.sin(13 * th + 0.4))
    soft = 1.2 * ss / max(fr, 1.0)                               # ~1px soft inner edge
    band = np.clip((f - (1.0 - inset)) / soft + 0.5, 0.0, 1.0)
    lift = RIM_LIFT * (0.45 + 0.55 * (0.5 + 0.5 * np.sin(th)))   # a little subtler on top
    col = base + (band * lift)[..., None]
    face = np.dstack([np.clip(col, 0, 255), np.full((H, W), a, np.float32)]).astype(np.uint8)
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).polygon(_stone(cx, cy, fr, fr), fill=255)
    lay.paste(Image.fromarray(face), (0, 0), mask)

    # bright lip along the lower rim
    lip = Image.new("L", (W, H), 0)
    ld = ImageDraw.Draw(lip)
    ld.polygon(_stone(cx, cy, fr, fr), fill=255)
    ld.polygon(_stone(cx, cy - D * 0.022, fr, fr), fill=0)
    lay.paste(Image.new("RGBA", (W, H), LIP + (a,)), (0, 0), lip)

    return Image.alpha_composite(img, lay), (D, pad, edge, heal_h, cx, cy)



_icon_src = []


def _icon():
    """TickTracker's heart icon (icon.png), or None if the file is missing."""
    if not _icon_src:
        try:
            _icon_src.append(Image.open(ICON_PATH).convert("RGBA"))
        except Exception:
            _icon_src.append(None)
    return _icon_src[0]


class _NoAlert:
    """Stands in for the combat alert if it couldn't be loaded, so the badge carries on as before."""
    stop = False
    last_corner = None

    def active(self):
        return False

    def test(self, seconds=5.0):
        pass

    def report(self):
        return "Combat alert: unavailable on this PC (see run.log)"


_alert_src = []


def _alert_icon():
    """The combat alert's emblem (alert.png), or None if the file is missing."""
    if not _alert_src:
        try:
            _alert_src.append(Image.open(ALERT_ICON_PATH).convert("RGBA"))
        except Exception:
            _alert_src.append(None)
    return _alert_src[0]


def render_alert(size, phase):
    """
    The badge while the combat alert is on: the alert emblem on the stone, swelling a
    little with a warm glow behind it. phase runs 0..1 through one pulse. Drawn on the
    same canvas as the ordinary badge, so the window never changes size.
    """
    ss = 4
    base, (D, pad, edge, heal_h, cx, cy) = _stone_layer(size, "locked", False, ss)
    W, H = base.size
    k = 0.5 - 0.5 * math.cos(2 * math.pi * phase)          # 0 -> 1 -> 0
    glow = Image.new("L", (W, H), 0)
    gr = D * (0.50 + 0.07 * k)
    gy = cy + edge * 0.5
    ImageDraw.Draw(glow).ellipse([cx - gr, gy - gr, cx + gr, gy + gr], fill=int(60 + 170 * k))
    glow = glow.filter(ImageFilter.GaussianBlur(D * 0.045))
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    img.paste(Image.new("RGBA", (W, H), (255, 198, 70, 255)), (0, 0), glow)
    img.alpha_composite(base)
    ic = _alert_icon()
    if ic is not None:
        d_icon = int(D * (0.84 + 0.08 * k))
        ic = ic.resize((d_icon, d_icon), Image.LANCZOS)
        img.alpha_composite(ic, (int(cx - d_icon / 2), int(cy - d_icon / 2)))
    else:
        fpx = D * (0.56 + 0.06 * k)
        _gradient_text(img, (cx, cy), "!", _font(fpx), (255, 232, 108), (241, 149, 70), 255,
                       max(ss * 2, int(fpx * 0.09)), COS_OUTLINE + (255,))
    return img.resize((W // ss, H // ss), Image.LANCZOS)


def render_badge(size, text, state, colour, heal, flash, icon=False):
    """
    Badge drawn like CoS's round HUD buttons: a slate disc (outline traced from the
    game) with a shaded top, lighter lower face, an uneven lighter rim, a stone edge
    underneath and a soft drop shadow. Numbers in Source Sans Bold with a dark outline.
    'heal' (e.g. '+4.7%') sits underneath in the same style.
    size = button width in screen pixels. state: nobar | searching | tentative | locked
    """
    ss = 4
    base, (D, pad, edge, heal_h, cx, cy) = _stone_layer(size, state, bool(heal), ss)
    img = base.copy()
    W, H = img.size
    lit = flash and state in ("locked", "tentative")
    if icon and _icon() is not None:
        # the heart icon sits on the stone whenever there's no number to show
        d_icon = int(D * 0.70)
        ic = _icon().resize((d_icon, d_icon), Image.LANCZOS)
        img.alpha_composite(ic, (int(cx - d_icon / 2), int(cy - d_icon / 2)))
        text = ""
    ta = 255 if state != "tentative" else 170
    tc = COS_GREEN if (lit and colour == C.WHITE) else colour
    top, bottom = GRADIENTS.get(tc, (tc, tc))
    if text:
        fpx = D * (0.50 if len(text) <= 2 else 0.40)
        f = _font(fpx)
        sw = max(ss * 2, int(fpx * 0.09))
        ty = cy + D * 0.01
        _gradient_text(img, (cx, ty), text, f, top, bottom, ta, sw, COS_OUTLINE + (ta,))
    if heal:
        fpx = D * 0.22
        f = _font(fpx)
        sw = max(ss * 2, int(fpx * 0.13))
        hy = pad + D + edge + heal_h * 0.36
        htop, hbot = GRADIENTS.get(colour, (colour, colour))
        _gradient_text(img, (cx, hy), heal, f, htop, hbot, ta, sw, COS_OUTLINE + (ta,))
    return img.resize((W // ss, H // ss), Image.LANCZOS)


# --------------------------------------------------------------------------
# Screen reader: finds and reads the health bar 60x a second on its own thread
# --------------------------------------------------------------------------
class Reader(threading.Thread):
    def __init__(self, settings):
        super().__init__(daemon=True)
        self.settings = settings
        self.lock = threading.Lock()
        self.stop = False
        # Timing-only clock: the first heal starts the countdown and tick SIZE never
        # matters (mud, Healing Pulse etc. change it all the time).
        self.model = C.SimpleClock(period=settings.get("period", C.TICK_PERIOD))
        self.detector = C.StepDetector()
        self.state = "nobar"            # nobar | searching | tentative | locked
        self.flash_until = 0.0
        self.last_bar_seen = 0.0
        self.fill = None
        self.bar = None                 # (left, top, width, height) of the bar on screen
        self.screen = None              # the area being searched
        self.searches = 0
        self.fatal = None
        self.errors = deque(maxlen=50)
        self.beat = time.monotonic()
        self.resync = False
        self.away = False               # another app is in front (tabbed out)
        self.away_since = None
        self.nobar_since = None         # in Roblox with no health bar, since when
        self.dirty = False
        self._snap = {"state": "nobar", "left": None, "flash": False}

    def run(self):
        try:
            self._run()
        except Exception:
            self.fatal = traceback.format_exc()
            log("SCREEN READER STOPPED:\n" + self.fatal)

    def _run(self):
        import mss
        new_grabber = getattr(mss, "MSS", None) or mss.mss     # (mss is renaming mss.mss to mss.MSS)
        sct = new_grabber()
        mon = dict(sct.monitors[0])                 # every monitor, as one big area
        self.screen = mon
        layout = virtual_screen()
        stale = False                   # a grab failed: look at the screens afresh before the next search
        log(f"screen reader started: searching {mon['width']}x{mon['height']} at {mon['left']},{mon['top']}")
        step = 1.0 / SAMPLE_HZ
        next_t = time.perf_counter()
        band = band_geo = None
        last_search = 0.0
        last_capture = -100.0
        f6 = False
        front_t = 0.0
        while not self.stop:
            now = time.perf_counter()
            if now - front_t > 0.25:
                front_t = now
                front = roblox_in_front()
                if front is not None:
                    away = not front
                    if away != self.away:
                        log("tabbed out of Roblox - countdown keeps running" if away else "back in Roblox")
                    self.away = away
            if f6_pressed():                        # F6
                self.resync = True
            fill = None
            try:
                if band is not None:
                    fill = C.read_fill(grab(sct, band), band_geo)
                    if fill is None and now - self.last_bar_seen > 1.0:
                        band = None                 # really gone - search for it again
                # while another app is in front there's no point searching its window for a bar
                if band is None and not self.away and now - last_search > 0.7:
                    last_search = now
                    self.searches += 1
                    # Screens can change while TickTracker runs (laptop docked or undocked,
                    # a monitor plugged in, resolution or scaling changed). When they do,
                    # or after a failed grab, take a fresh look at what there is to search.
                    cur = virtual_screen()
                    if stale or cur != layout:
                        changed = cur != layout
                        layout, stale = cur, False
                        try:
                            sct.close()
                        except Exception:
                            pass
                        sct = new_grabber()
                        mon = dict(sct.monitors[0])
                        self.screen = mon
                        if changed:
                            log(f"screens changed: now searching {mon['width']}x{mon['height']} "
                                f"at {mon['left']},{mon['top']}")
                    img = grab(sct, mon)
                    geo = C.locate_bar(img)
                    if geo is not None and C.read_fill(img, geo) is not None:
                        y0, y1, x0, x1 = geo
                        key = f"{mon['width']}x{mon['height']}"
                        with self.lock:             # the badge saves these settings from its own thread
                            pool = self.settings.setdefault("bar_w", {}).setdefault(key, [])
                            pool.append(int(x1 - x0 + 1))
                            del pool[:-9]
                            usual = int(np.median(pool))
                        x1 = min(img.shape[1] - 1, x0 + usual - 1)
                        m = 2
                        mr = max(0, min(6, img.shape[1] - 1 - x1))
                        band = {"left": mon["left"] + x0 - m, "top": mon["top"] + y0 - m,
                                "width": x1 - x0 + 1 + m + mr, "height": y1 - y0 + 1 + 2 * m}
                        band_geo = (m, m + y1 - y0, m, m + x1 - x0)
                        fill = C.read_fill(img, (y0, y1, x0, x1))
                        with self.lock:
                            self.bar = (mon["left"] + x0, mon["top"] + y0, x1 - x0 + 1, y1 - y0 + 1)
                            self.model.px = 1.0 / max(20, x1 - x0 - 1)
                            self.detector.eps = 0.35 * self.model.px
                            self.dirty = True
                        log(f"health bar found at x={self.bar[0]} y={self.bar[1]}, "
                            f"{self.bar[2]}px wide, {self.bar[3]}px tall, reading {fill * 100:.1f}%")
                        self._save_picture(img[max(0, y0 - 40):y1 + 40, max(0, x0 - 60):x1 + 60], "bar_found.png")
                    elif now - last_capture > 20.0:
                        # can't find it: keep a picture of what was searched, for diagnosis
                        last_capture = now
                        h = img.shape[0]
                        self._save_picture(img[h // 2:], "capture_no_bar.png")
                        log("no health bar found on screen (saved capture_no_bar.png)")
            except Exception as e:
                self.errors.append(f"{time.strftime('%H:%M:%S')} {e!r}")
                band = None
                stale = True
            self.beat = time.monotonic()
            with self.lock:
                self._process(now, fill)
            next_t += step
            delay = next_t - time.perf_counter()
            if delay > 0:
                time.sleep(delay)
            else:
                next_t = time.perf_counter()

    def _save_picture(self, arr, name):
        try:
            Image.fromarray(arr).save(os.path.join(DATA_DIR, name))
        except Exception:
            pass

    def _process(self, now, fill):
        m = self.model
        self.fill = fill
        if self.resync:
            self.resync = False
            m.manual_sync(now)
            self.flash_until = now + 0.35
        if fill is None:
            if self.away:
                # Tabbed out: the bar is simply covered. Keep the rhythm and keep counting.
                self.nobar_since = None
                if self.away_since is None:
                    self.away_since = now
                gone = now - self.away_since > AWAY_RESET_SECONDS
                why = "tabbed out for a long time -> fresh start"
            else:
                # In Roblox with no bar: the menu or a creature swap, once it lasts a while
                self.away_since = None
                if self.nobar_since is None:
                    self.nobar_since = now
                gone = now - self.nobar_since > LOST_RESET_SECONDS
                why = "health bar gone (menu / new creature) -> fresh start"
            if gone:
                if m.anchor is not None or m.base is not None:
                    m.note(now, why)
                    self.dirty = True
                    m.full_reset()
                    self.detector.reset()
                self.state = "nobar"
            return
        self.nobar_since = self.away_since = None
        if now - self.last_bar_seen > 1.0:
            self.detector.reset()       # bar was hidden a while: start measuring afresh
        self.last_bar_seen = now
        for (t0, d, before, after) in self.detector.feed(now, fill):
            if d > 0:
                res = m.on_rise(t0, d, before, after)
                if res in ("natural", "relocked", "locked", "tentative"):
                    self.flash_until = now + 0.35
            else:
                m.on_hurt(t0, -d)
        m.on_sample(now, fill)
        self.state = "locked" if m.anchor is not None else "searching"

    # ---- for the badge: never waits on the reader for more than a moment ----
    def snapshot(self):
        if self.lock.acquire(timeout=0.02):
            try:
                now = time.perf_counter()
                self._snap = {"state": self.state, "left": self.model.seconds_left(now),
                              "flash": now < self.flash_until}
            finally:
                self.lock.release()
        return self._snap

    def report(self):
        got = self.lock.acquire(timeout=1.0)
        try:
            m = self.model
            lines = [
                f"TickTracker {VERSION} (basic) debug report  {time.strftime('%Y-%m-%d %H:%M:%S')}",
                f"screen searched: {self.screen}   searches so far: {self.searches}",
                f"health bar: {self.bar}   reading: {self.fill}   state: {self.state}   tabbed out: {self.away}",
                f"tick gap: {m.period:.3f}s  measured gaps: {[round(i, 2) for i in m.intervals]}",
                f"rhythm confirmed by a tick: {m.confirmed}   expected ticks that never came: {m.misses}",
                "", "---- health changes seen (newest last) ----", *m.log,
                "", "---- errors ----", *self.errors, self.fatal or "",
            ]
        finally:
            if got:
                self.lock.release()
        return "\n".join(str(x) for x in lines)


def badge_content(reader):
    """(text, state) the badge shows right now. Used by the window and by OBS."""
    snap = reader.snapshot()
    st = snap["state"]
    if reader.fatal:
        return "!", "searching"
    if st in ("nobar", "searching") or snap["left"] is None:
        return "icon", "searching"
    return str(max(0, math.ceil(snap["left"] - 0.05))), st


OVERLAY_HTML = b"""<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;padding:0;background:transparent;overflow:hidden}
img{display:block}</style></head><body><img id="b" alt=""><script>
const q = new URLSearchParams(location.search), size = q.get('size') || '';
const el = document.getElementById('b');
let last = '';
async function tick() {
  try {
    const r = await fetch('/state?size=' + size, {cache: 'no-store'});
    const j = await r.json();
    if (j.key !== last) {
      const im = new Image();
      im.onload = () => { el.src = im.src; };
      im.src = '/badge.png?size=' + size + '&k=' + encodeURIComponent(j.key);
      last = j.key;
    }
  } catch (e) { el.removeAttribute('src'); last = ''; }   // TickTracker closed: show nothing
  setTimeout(tick, 50);
}
tick();
</script></body></html>"""


class OverlayServer(threading.Thread):
    """
    Serves a see-through copy of the badge for OBS's Browser Source, so recordings
    get the same soft edges and shadow as the screen. Only reachable from this PC
    (127.0.0.1) - nothing on the network can see it - and it only ever hands out
    the badge picture and the current countdown.
    """

    def __init__(self, reader, default_size):
        super().__init__(daemon=True)
        self.reader, self.default_size = reader, default_size
        self.cache, self.cache_lock = {}, threading.Lock()
        self.httpd = None

    def _size(self, query):
        try:
            v = int(query.get("size", [""])[0])
            return v if 48 <= v <= 240 else self.default_size
        except Exception:
            return self.default_size

    def _png(self, size, text, st):
        key = (size, text, st)
        with self.cache_lock:
            data = self.cache.get(key)
        if data is None:
            img = render_badge(size, text, st, HEART_CORAL, "", False, icon=(text == "icon"))
            buf = io.BytesIO()
            img.save(buf, "PNG")
            data = buf.getvalue()
            with self.cache_lock:
                if len(self.cache) > 150:
                    self.cache.clear()
                self.cache[key] = data
        return data

    def run(self):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        from urllib.parse import urlparse, parse_qs
        srv = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, ctype, body):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):
                try:
                    u = urlparse(self.path)
                    q = parse_qs(u.query)
                    if u.path in ("/", "/overlay"):
                        self._send(200, "text/html; charset=utf-8", OVERLAY_HTML)
                    elif u.path == "/state":
                        text, st = badge_content(srv.reader)
                        self._send(200, "application/json",
                                   json.dumps({"key": f"{text}|{st}"}).encode())
                    elif u.path == "/badge.png":
                        text, st = badge_content(srv.reader)
                        self._send(200, "image/png", srv._png(srv._size(q), text, st))
                    else:
                        self._send(404, "text/plain", b"not found")
                except Exception:
                    try:
                        self._send(500, "text/plain", b"error")
                    except Exception:
                        pass

        try:
            self.httpd = ThreadingHTTPServer(("127.0.0.1", OVERLAY_PORT), Handler)
            self.httpd.daemon_threads = True
            log(f"OBS overlay ready at http://127.0.0.1:{OVERLAY_PORT}/overlay")
            self.httpd.serve_forever(poll_interval=0.5)
        except Exception as e:
            log(f"OBS overlay not available (port {OVERLAY_PORT} busy?): {e!r}")


# --------------------------------------------------------------------------
# The badge: one ordinary always-on-top window
# --------------------------------------------------------------------------
def load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            s = json.load(f)
    except Exception:
        return {}
    if not isinstance(s, dict):
        return {}
    keep = {}
    for key, lo, hi, cast in (("x", -100000, 100000, int), ("y", -100000, 100000, int),
                              ("size", 48, 240, int), ("period", 14.0, 17.5, float)):
        v = s.get(key)
        if isinstance(v, (int, float)) and not isinstance(v, bool) and lo <= v <= hi:
            keep[key] = cast(v)
    if s.get("window") in ("smooth", "plain"):
        keep["window"] = s["window"]
    if isinstance(s.get("combat_alert"), bool):
        keep["combat_alert"] = s["combat_alert"]
    if isinstance(s.get("known_sizes"), list):
        keep["known_sizes"] = [k for k in s["known_sizes"] if isinstance(k, (int, float))]
    bw = s.get("bar_w")
    if isinstance(bw, dict) and all(isinstance(v, list) and all(
            isinstance(n, int) and 20 <= n <= 8000 for n in v) for v in bw.values()):
        keep["bar_w"] = bw
    return keep


def save_settings(s):
    try:
        tmp = SETTINGS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(s, f, indent=1)
        os.replace(tmp, SETTINGS_PATH)
    except Exception:
        pass


class App:
    KEY = "#ff00fe"                      # this colour is made see-through by Windows

    def __init__(self):
        import tkinter as tk
        from PIL import ImageTk
        self.tk, self.ImageTk = tk, ImageTk
        self.settings = load_settings()
        self.root = tk.Tk()
        self.root.title("TickTracker")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=self.KEY)
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        self.default_size = default_size(sh)
        self.size = int(self.settings.get("size", self.default_size))
        # keep the badge somewhere visible - on ANY monitor, so one parked on a second
        # screen is still there next time (and comes back if that screen is unplugged)
        vx, vy, vw, vh = virtual_screen() or (0, 0, sw, sh)
        self.x = min(max(int(self.settings.get("x", sw - 180)), vx - 50), vx + vw - 60)
        self.y = min(max(int(self.settings.get("y", 60)), vy), vy + vh - 60)
        self.root.geometry(f"+{self.x}+{self.y}")
        self.label = tk.Label(self.root, bd=0, bg=self.KEY)
        self.label.pack()
        self.shadows = []                # (window, label) x3 - plain mode's drop shadow
        self.images = {}
        self.hwnd = None
        self.draw_fails = 0
        # "smooth" = soft edges and a real soft drop shadow, like the game's widgets.
        # "plain"  = the fall-back: hard edges, layered-window shadow. Used automatically
        #            if smooth drawing doesn't work on this PC, or chosen from the menu.
        self.smooth = IS_WIN and self.settings.get("window", "smooth") == "smooth"
        if self.smooth:
            try:
                self.root.update_idletasks()
                self.hwnd = window_handle(self.root)
                set_layered(self.hwnd, True)
            except Exception:
                log("smooth window could not be set up:\n" + traceback.format_exc())
                self.smooth = False
        if not self.smooth:
            self._go_plain(first=True)
        log(f"badge mode: {'smooth' if self.smooth else 'plain'}")
        self.photos = {}
        self.last_key = None
        self.errors = deque(maxlen=20)
        self.root.report_callback_exception = lambda *a: self._error("".join(traceback.format_exception(*a)))
        for w in (self.root, self.label):
            w.bind("<ButtonPress-1>", self._press)
            w.bind("<B1-Motion>", self._drag)
            w.bind("<ButtonRelease-1>", lambda e: self._save())
            w.bind("<Double-Button-1>", lambda e: self._resync())
            w.bind("<MouseWheel>", self._wheel)
            w.bind("<Button-3>", self._menu)
        self.menu = tk.Menu(self.root, tearoff=0)
        self.menu.add_command(label="Resync now - I just ticked  (F6)", command=self._resync)
        self.menu.add_command(label="Reset size", command=self._reset_size)
        # combat alert: on unless switched off here. The watcher thread reads the plain
        # True/False below, never the menu's own variable.
        self._alert_enabled = bool(self.settings.get("combat_alert", True))
        self._alert_var = tk.BooleanVar(value=self._alert_enabled)
        self._alert_shown = False
        self.menu.add_checkbutton(label="Combat alert when tabbed out", variable=self._alert_var,
                                  command=self._toggle_alert)
        self.menu.add_command(label="Test the combat alert (5 seconds)", command=self._test_alert)
        self.menu.add_command(label="Switch to plain window (if the badge looks wrong)" if self.smooth
                              else "Switch to smooth window (soft edges)", command=self._switch_window)
        self.menu.add_command(label="Copy OBS overlay link", command=self._copy_overlay)
        self.menu.add_command(label="Save debug report", command=self._debug)
        self.menu.add_command(label="Open TickTracker's files (logs, settings)", command=self._open_folder)
        if PACKAGED and IS_WIN:
            self.menu.add_command(label="Put a TickTracker shortcut on the Desktop (with its icon)",
                                  command=self._shortcut)
        self.menu.add_separator()
        self.menu.add_command(label="Quit TickTracker", command=self.quit)

        self.reader = Reader(self.settings)
        timer_res(True)
        self.reader.start()
        if ttalert is not None:
            self.alert = ttalert.CombatWatcher(lambda: self.reader.away, lambda: self._alert_enabled, log)
            self.alert.start()
        else:
            log("combat alert unavailable on this PC:\n" + str(_alert_import_error))
            self.alert = _NoAlert()
        self.overlay = OverlayServer(self.reader, DEFAULT_SIZE)
        self.overlay.start()
        self.ticks = 0
        log(f"badge window open at {self.x},{self.y}, size {self.size}")
        self.root.after(30, self._ui)

    def _go_plain(self, first=False):
        """Fall back to the plain window: hard edges, shadow made of see-through layers."""
        self.smooth = False
        try:
            if self.hwnd and not first:
                set_layered(self.hwnd, False)          # let tkinter manage transparency again
            self.root.attributes("-transparentcolor", self.KEY)
        except Exception:
            log("plain window setup problem:\n" + traceback.format_exc())
        self.last_key = None
        self._make_shadows()

    # ---- plain mode's drop shadow: three see-through black shapes under the badge ----
    def _make_shadows(self):
        try:
            for _ in range(3):
                win = self.tk.Toplevel(self.root)
                win.overrideredirect(True)
                win.configure(bg=self.KEY)
                win.attributes("-topmost", True)
                win.attributes("-transparentcolor", self.KEY)
                win.attributes("-alpha", SHADOW_ALPHA)
                lab = self.tk.Label(win, bd=0, bg=self.KEY)
                lab.pack()
                for w in (win, lab):                      # a click on the shadow acts like the badge
                    w.bind("<ButtonPress-1>", self._press)
                    w.bind("<B1-Motion>", self._drag)
                    w.bind("<ButtonRelease-1>", lambda e: self._save())
                    w.bind("<Button-3>", self._menu)
                self.shadows.append((win, lab))
            self._draw_shadows()
            self.root.lift()                              # badge on top of its shadow
            log("drop shadow on")
        except Exception:
            log("drop shadow unavailable on this PC (badge still works):\n" + traceback.format_exc())
            for win, _ in self.shadows:
                try:
                    win.destroy()
                except Exception:
                    pass
            self.shadows = []

    def _draw_shadows(self):
        self.last_key = None
        if not self.shadows:
            return
        self._shadow_photos = [self.ImageTk.PhotoImage(im) for im in shadow_shapes(self.size)]
        for (win, lab), ph in zip(self.shadows, self._shadow_photos):
            lab.configure(image=ph)
            win.geometry(f"+{self.x}+{self.y}")

    def _move_shadows(self):
        for win, _ in self.shadows:
            win.geometry(f"+{self.x}+{self.y}")

    def _error(self, err):
        if err != getattr(self, "_last_err", None):
            self._last_err = err
            log("badge error:\n" + err)
        self.errors.append(err)

    def _image(self, key):
        img = self.images.get(key)
        if img is None:
            size, text, state, note, flash = key
            if len(self.images) > 120:
                self.images.clear()
            if text == "alert":                       # 'state' carries which picture of the pulse
                img = render_alert(size, state / ALERT_FRAMES)
            else:
                img = render_badge(size, text, state, HEART_CORAL, note, flash, icon=(text == "icon"))
            self.images[key] = img
        return img

    def _photo(self, key):
        ph = self.photos.get(key)
        if ph is None:
            size, text, state, note, flash = key
            if text == "alert":
                img = render_alert(size, state / ALERT_FRAMES)
            else:
                img = render_badge(size, text, state, HEART_CORAL, note, flash, icon=(text == "icon"))
            bg = Image.new("RGBA", img.size, (255, 0, 254, 255))
            flat = img.copy()
            # keep the solid stone and text only; the soft shadow is drawn by the
            # separate see-through shadow windows instead
            flat.putalpha(img.split()[3].point(lambda v: 255 if v >= 150 else 0))
            bg.alpha_composite(flat)
            if len(self.photos) > 120:
                self.photos.clear()
            ph = self.photos[key] = self.ImageTk.PhotoImage(bg.convert("RGB"))
        return ph

    def _ui(self):
        try:
            self.ticks += 1
            if _crash_file is not None and self.ticks % 30 == 1:
                # if the badge stops ticking for 6s, Python writes where it is stuck
                faulthandler.dump_traceback_later(6, repeat=False, file=_crash_file)
            text, st = badge_content(self.reader)
            note = "ERROR" if text == "!" else ""
            key = (self.size, text, st, note, False)      # no green flash - the number stays white
            if self.alert.active():
                # combat started while tabbed out: pulse the alert emblem until you're back in Roblox
                frame = int(time.monotonic() / ALERT_PERIOD * ALERT_FRAMES) % ALERT_FRAMES
                key = (self.size, "alert", frame, "", False)
                if not self._alert_shown:
                    self._alert_shown = True
                    self.root.attributes("-topmost", True)
                    self.root.lift()
            else:
                self._alert_shown = False
            if key != self.last_key:
                self.last_key = key
                if self.smooth:
                    img = self._image(key)
                    self.root.geometry(f"{img.width}x{img.height}+{self.x}+{self.y}")
                    if draw_smooth(self.hwnd, img, self.x, self.y):
                        self.draw_fails = 0
                    else:
                        self.draw_fails += 1
                        self.last_key = None                     # try again next tick
                        if self.draw_fails >= 5:
                            log("smooth drawing keeps failing on this PC - switching to the plain window")
                            self._go_plain()
                else:
                    self.label.configure(image=self._photo(key))
                if not getattr(self, "_drawn", False):
                    self._drawn = True
                    log("badge drawn for the first time")
            if self.ticks % 60 == 0:
                if self.root.state() != "normal":
                    self.root.deiconify()
                for win, _ in self.shadows:
                    win.attributes("-topmost", True)
                self.root.attributes("-topmost", True)
                if self.shadows:
                    self.root.lift()
            if self.ticks % 150 == 0:
                self._status()
            if self.reader.dirty:
                self.reader.dirty = False
                self._save()
        except Exception:
            self._error(traceback.format_exc())
        self.root.after(33, self._ui)

    def _status(self):
        r = self.reader
        left = r._snap.get("left")
        lines = [f"TickTracker {VERSION} (basic) status  {time.strftime('%H:%M:%S')}",
                 f"Health bar:  {'found at ' + str(r.bar) + ', reading ' + format(r.fill * 100, '.1f') + '%' if r.fill is not None else 'NOT FOUND (searched ' + str(r.searches) + ' times)'}",
                 f"Timer:       {r.state}" + (f", next tick in {left:.1f}s" if left is not None else "")
                 + ("  (tabbed out - counting from the learned rhythm)" if r.away else ""),
                 f"Screen:      {r.screen}"]
        if r.fatal:
            lines += ["", "SCREEN READER STOPPED:", r.fatal]
        if time.monotonic() - r.beat > 5 and not r.fatal:
            lines += ["", "SCREEN READER IS STUCK (see crash_hard.txt)"]
            if _crash_file is not None and not getattr(self, "_stuck_dumped", False):
                self._stuck_dumped = True
                log("screen reader stuck - where is in crash_hard.txt")
                faulthandler.dump_traceback(file=_crash_file, all_threads=True)
        lines += list(r.errors)[-3:] + list(self.errors)[-2:]
        txt = "\n".join(lines)
        try:
            with open(os.path.join(DATA_DIR, "status.txt"), "w", encoding="utf-8") as f:
                f.write(txt + "\n")
            if DEBUG:
                print("\n" + txt, flush=True)
        except Exception:
            pass

    # ---- mouse ----
    def _press(self, e):
        self._dx, self._dy = e.x_root - self.x, e.y_root - self.y

    def _drag(self, e):
        self.x, self.y = e.x_root - self._dx, e.y_root - self._dy
        self.root.geometry(f"+{self.x}+{self.y}")
        self._move_shadows()

    def _wheel(self, e):
        self.size = max(48, min(240, self.size + (4 if e.delta > 0 else -4)))
        self._draw_shadows()
        self._save()

    def _reset_size(self):
        self.size = self.default_size
        self._draw_shadows()
        self._save()

    def _switch_window(self):
        self.settings["window"] = "plain" if self.smooth else "smooth"
        self._save()
        log(f"window mode set to {self.settings['window']} - restarting needed")
        self._say("Saved. TickTracker will now close - start it again to use the "
                  f"{self.settings['window']} window.")
        self.quit()

    def _say(self, text):
        faulthandler.cancel_dump_traceback_later()     # a message box pauses the badge on purpose
        message_box(text)

    def _shortcut(self):
        try:
            path = make_desktop_shortcut(sys.executable, ICO_PATH)
            log(f"desktop shortcut made: {path}")
            self._say("Done - there's now a TickTracker shortcut on your Desktop, with its own icon.\n\n"
                      "To keep it on the taskbar: right-click that shortcut, Show more options, "
                      "Pin to taskbar.\n\n(If you ever move the TickTracker folder, make the shortcut again.)")
        except Exception:
            self._error(traceback.format_exc())
            self._say("Windows wouldn't let TickTracker make the shortcut.\n\nYou can make one yourself: "
                      "right-click TickTracker.exe, Show more options, Send to, Desktop (create shortcut).")

    def _open_folder(self):
        try:
            if IS_WIN:
                os.startfile(DATA_DIR)
        except Exception:
            self._error(traceback.format_exc())

    def _copy_overlay(self):
        link = f"http://127.0.0.1:{OVERLAY_PORT}/overlay?size={self.size}"
        self.root.clipboard_clear()
        self.root.clipboard_append(link)
        log(f"overlay link copied: {link}")

    def _resync(self):
        self.reader.resync = True

    def _menu(self, e):
        faulthandler.cancel_dump_traceback_later()     # the open menu pauses the badge on purpose
        try:
            self.menu.tk_popup(e.x_root, e.y_root)
        finally:
            self.menu.grab_release()

    def _debug(self):
        path = os.path.join(DATA_DIR, "debug_report.txt")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.reader.report())
                f.write("\n\n---- badge errors ----\n" + "\n".join(self.errors))
                f.write("\n\n---- combat alert ----\n" + self.alert.report())
            corner = self.alert.last_corner
            if corner is not None:
                # the corner of the Roblox window it last looked at, kept on this PC only
                Image.fromarray(corner).save(os.path.join(DATA_DIR, "combat_corner.png"))
            if IS_WIN:
                os.startfile(path)
        except Exception:
            self._error(traceback.format_exc())

    def _toggle_alert(self):
        self._alert_enabled = bool(self._alert_var.get())
        self.settings["combat_alert"] = self._alert_enabled
        log(f"combat alert switched {'on' if self._alert_enabled else 'off'}")
        self._save()

    def _test_alert(self):
        log("combat alert test from the menu")
        self.alert.test(5.0)

    def _save(self):
        r = self.reader
        if not r.lock.acquire(timeout=0.25):
            return
        try:
            self.settings.update(x=self.x, y=self.y, size=self.size)
            self.settings["known_sizes"] = [round(k, 5) for k in r.model.known]
            if len(r.model.intervals) >= 3:
                self.settings["period"] = round(r.model.period, 3)
            snap = json.loads(json.dumps(self.settings))
        finally:
            r.lock.release()
        save_settings(snap)

    def quit(self):
        log("quit chosen from the menu")
        self.reader.stop = True
        self.alert.stop = True
        try:
            if self.overlay.httpd is not None:
                self.overlay.httpd.shutdown()
        except Exception:
            pass
        self._save()
        timer_res(False)
        self.root.destroy()


def main():
    start_logging()
    libs = []
    for name in ("PIL", "numpy", "mss"):
        try:
            libs.append(f"{name} {getattr(__import__(name), '__version__', '?')}")
        except Exception as e:
            libs.append(f"{name} MISSING ({e})")
    log(f"TickTracker {VERSION} (basic) starting - {'packaged app' if PACKAGED else 'run from source'}, "
        f"Python {sys.version.split()[0]}, {', '.join(libs)}, folder {DATA_DIR}")
    if DEBUG:
        print(f"TickTracker {VERSION} debug mode - status prints every 5 seconds. Close this window to stop.\n", flush=True)
    if already_running():
        log("another TickTracker is already running - this one is stopping")
        message_box("TickTracker is already running.\n\nTo restart it, right-click the badge and choose "
                    "Quit TickTracker (or end 'Python' in Task Manager), then start it again.")
        return
    try:
        App().root.mainloop()
        log("window loop ended")
    except Exception:
        err = traceback.format_exc()
        log("CRASH:\n" + err)
        try:
            with open(os.path.join(DATA_DIR, "crash.txt"), "w", encoding="utf-8") as f:
                f.write(err)
        except Exception:
            pass
        message_box("TickTracker hit an error and had to close.\n\nPlease send this file to whoever "
                    f"gave you TickTracker:\n{RUN_LOG}\n\n" + err[-600:])


if __name__ == "__main__":
    main()
